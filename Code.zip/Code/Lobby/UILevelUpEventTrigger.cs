using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UILevelUpEventTrigger : UILevelUpButtonEventTrigger
{
    public override IEnumerator OnHoldButton()
    {
        float interval = 0.1f;
        float timer = 0f;

        // ��ư�� ������ �ִ� ���� ����.
        while (IsButtonHold)
        {
            yield return null;

            timer += Time.deltaTime;
            if (timer >= interval)
            {
                if (LevelUPButton.enabled)
                {
                    LevelUPButton.onClick.Invoke();
                }

                timer = 0f;
            }
        }
    }
}
