using DLL_Datatables;
using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;

public class StudyItem : StudySpecUp
{
    public Image iconImage;
    public Text studyLv;
    public Text studyTitle;
    public Text studyDescription;
    public Text studySpecValue;
    public Image costImage;
    public Text costText;
    public Button LvUpButton;
    public GameObject LvMax;

    private Popup_SplashMessage splashPopuup;
    private bool isFree = false;

    public void SetStudyData(cStudy data)
    {
        GameManager.Instance.InGameStudy[data.StudyID].OnValueChanged +=
            studydata => LevelUpButtonCallback(data);

        LvUpButton.onClick.AddListener(() =>
        {
            //Debug.Log("OnClick");
            OnClickLevelUp(data);
        });

        GameManager.Instance.Lobby.LobbyUI.OnLanguageEvent += () => SetLanguageReload(data);
        splashPopuup = GameManager.Instance.Lobby.PopupManager.SplashMessagePopup;

        object[] spec = new object[] { data.MaxLv, data.SpecValue * GameManager.Instance.InGameStudy[data.StudyID].Value };
        iconImage.sprite = GameManager.Instance.Lobby.LobbyUI.GetSprite(GameManager.Instance.Lobby.LobbyUI.BilinearIcon, data.StudyID.ToString());
        studyLv.text = string.Format("Lv.{0}", GameManager.Instance.InGameStudy[data.StudyID].Value);
        studyTitle.text = CleLocalization.Format("Localization", data.StudyID.ToString(), spec[0]);
        studyDescription.text = CleLocalization.Format("Localization", data.Description.ToString(), spec[1]);
        studySpecValue.text = data.SpecValue.ToString();
        costImage.sprite = GameManager.Instance.Lobby.LobbyUI.GetSprite(GameManager.Instance.Lobby.LobbyUI.BilinearIcon, data.UseItemID.ToString());
        costText.text = GameManager.Instance.PropertyNotation.FormatGameNumber(GetItemValue(data));
        if (GameManager.Instance.InGameStudy[data.StudyID].Value >= data.MaxLv)
        {
            LvMax.SetActive(true);
            LvUpButton.enabled = false;
        }

        if (data.StudyID == (int)eStudyID.BattleSlot) LvUpButton.gameObject.SetActive(false);
        else if (data.StudyID == (int)eStudyID.CoinMeatLevel)
        {
            if (GameManager.Instance.InGameStudy[data.StudyID].Value > 0) return;

            isFree = true;
            costText.text = CleLocalization.Format("Localization", "114", null);
        }

        //GameManager.Instance.InGameGold.Value = 1000000000;
        //GameManager.Instance.InGameCoin.Value = 1000000000;
        //GameManager.Instance.InGameDia.Value = 1000000000;
    }

    private void SetLanguageReload(cStudy data)
    {
        object[] spec = new object[] { data.MaxLv, data.SpecValue * GameManager.Instance.InGameStudy[data.StudyID].Value };
        studyTitle.text = CleLocalization.Format("Localization", data.StudyID.ToString(), spec[0]);
        studyDescription.text = CleLocalization.Format("Localization", data.Description.ToString(), spec[1]);
    }

    private void OnClickLevelUp(cStudy data)
    {
        var useCost = GetItemValue(data);
        if (UseItemCheck(data.UseItemID, useCost) || isFree)
        {
            BeastSpecUp(data.StudyID);
        }
        else if (!UseItemCheck(data.UseItemID, useCost) && !splashPopuup.gameObject.activeSelf)
        {
            splashPopuup.ShowPopup((int)eSplashMessageType.Proterty);
        }

        if (GameManager.Instance.InGameStudy[data.StudyID].Value >= data.MaxLv)
        {
            LvMax.SetActive(true);
            LvUpButton.enabled = false;
        }
    }

    public void LevelUpButtonCallback(cStudy data)
    {
        object[] spec = new object[] { data.SpecValue * GameManager.Instance.InGameStudy[data.StudyID].Value };
        studyLv.text = string.Format("Lv.{0}", GameManager.Instance.InGameStudy[data.StudyID].Value);
        studyDescription.text = CleLocalization.Format("Localization", data.Description.ToString(), spec);
        costText.text = GameManager.Instance.PropertyNotation.FormatGameNumber(GetItemValue(data));
    }

    private double GetItemValue(cStudy data)
    {
        int studyID = data.StudyID;
        double sum = 0;

        switch (studyID)
        {
            case 1060020:
            case 1060040:
                sum = data.ItemValue * Math.Pow(1.2, GameManager.Instance.InGameStudy[data.StudyID].Value);
                break;
            case 1060030:
            case 1060050:
            case 1060060:
            case 1061050:
                sum = data.ItemValue * Math.Pow(2, GameManager.Instance.InGameStudy[data.StudyID].Value);
                break;
            case 1060070:
            case 1060080:
            case 1060090:
            case 1061060:
            case 1061070:
                sum = data.ItemValue;
                break;
            case 1060100:
            case 1060110:
            case 1061010:
            case 1061020:
            case 1061030:
                sum = data.ItemValue + (data.ItemValue * GameManager.Instance.InGameStudy[data.StudyID].Value);
                break;
            case 1061040:
                sum = data.ItemValue * GameManager.Instance.InGameStudy[data.StudyID].Value;
                break;
            default:
                sum = 0;
                break;
        }

        return sum;
    }

    private void BeastSpecUp(int studyID)
    {
        switch (studyID)
        {
            case 1060020:
                BeastAtkUp(studyID);
                break;
            case 1060030:
                BeastCriRateUp(studyID);
                break;
            case 1060040:
                BeastCriDamageUp(studyID);
                break;
            case 1060050:
                BeastMaxHPUp(studyID);
                break;
            case 1060060:
                HealHpOnWaveChange(studyID);
                break;
            case 1060070:
                AmountOfGoldUp(studyID);
                break;
            case 1060080:
                DoubleGoldReward(studyID);
                break;
            case 1060090:
                IdleRewardUp(studyID);
                break;
            case 1060100:
                ThunderDamageUp(studyID);
                break;
            case 1060110:
                ThunderAutoSpeed(studyID);
                break;
            case 1061010:
                MeatChargeSpeedUP(studyID);
                break;
            case 1061020:
                MeatCreateMaxUp(studyID);
                break;
            case 1061030:
                LobbyMeatSlotAdd(studyID);
                break;
            case 1061040:
                if (isFree) isFree = false;
                CreateMeatLevelCoin(studyID);
                break;
            case 1061050:
                CreateMeatLevelDia(studyID);
                break;
            case 1061060:
                AutoCreateTime(studyID);
                break;
            case 1061070:
                AutoMergeTime(studyID);
                break;
            default:
                break;
        }

        InGameData.SaveData();
    }

    private bool UseItemCheck(int useItem, double cost)
    {
        var isCheck = false;
        switch (useItem)
        {
            case 1009001:
                if (GameManager.Instance.InGameCoin.Value < cost) isCheck = false;
                else
                {
                    isCheck = true;
                    GameManager.Instance.InGameCoin.Value -= cost;
                }
                break;
            case 1009002:
                if (GameManager.Instance.InGameGold.Value < cost) isCheck = false;
                else
                {
                    isCheck = true;
                    GameManager.Instance.InGameGold.Value -= cost;
                }
                break;
            case 1000003:
                if (GameManager.Instance.InGameDia.Value < cost) isCheck = false;
                else
                {
                    isCheck = true;
                    GameManager.Instance.InGameDia.Value -= cost;
                }
                break;
        }

        return isCheck;
    }
}
