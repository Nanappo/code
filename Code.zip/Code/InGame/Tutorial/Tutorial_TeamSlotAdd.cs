using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tutorial_TeamSlotAdd : UITutorial
{
    private Popup_TeamSetting Popup;
    private Popup_UITeamSetting PopupUI;

    public override void Ready(Tutorial master)
    {
        base.Ready(master);

        Popup = GameManager.Instance.Lobby.PopupManager.TeamSettingPopup;
        PopupUI = Popup.InventorySlot[0].GetComponent<Popup_UITeamSetting>();

        if (Popup.InventorySlot.Count > 0) Target = PopupUI.useButton.gameObject;
        if (Target != null)
        {
            Master.Guide.transform.position = Target.transform.position;
        }

        Master.LockScreen[11].SetActive(true);
        NextScenario = eTutorial.End;
    }

    public override IEnumerator Scenario()
    {
        Master.Guide.SetActive(true);
        Master.Guide.GetComponent<Animation>().Play("UI_Tuto_Idle");

        while (!isClear)
        {
            yield return null;
            if (Popup.selectBeast!=null)
            {
                isClear = true;
            }
        }

        End();
    }

    public override void End()
    {
        base.End();
        Master.LockScreen[11].SetActive(false);
        Master.LogEvent();
        Master.NextTutorial(NextScenario);
    }
}
