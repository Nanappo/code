using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class Beast : MonoBehaviour
{
    public Dictionary<eBeastState, BeastState> StateList = new Dictionary<eBeastState, BeastState>();
    public eBeastState currentState;
    public GameObject Target;

    public BeastData SelfData { get; set; }
    public BeastState_Attack BeastAttack { get; set; }
    public BeastState_Skill BeastSkill { get; set; }
    public Animator animator { get; set; }
    public GameObject Pivot { get; set; }
    public GameObject Shadow { get; set; }
    public float BasicRadius { get; set; }
    public float SkillRadius { get; set; }
    public bool isDoing { get; set; }
    public bool isSkill { get; set; }
    public bool isAni { get; set; }
    public int mySlotID { get; private set; }
    public bool isDie => BeastAttack.isDied;
    public Vector3 startPos { get; set; }

    private Action stateDoing = () => { };

    public void Initialize(BeastData beast, int slotID)
    {
        animator = GetComponent<Animator>();
        BeastAttack = GetComponent<BeastState_Attack>();
        BeastSkill = gameObject.GetComponent<BeastState_Skill>();
        Pivot = transform.Find("Pivot").gameObject;
        Shadow = transform.Find("BottomShadow").gameObject;
        SelfData = beast;
        mySlotID = slotID;
        StateListInitialize();
        SetCurrentStage(eBeastState.Battle_Idle);
        BeastAttack.Init();
        BeastSkill.Init();

        var posX = GameManager.Instance.GameScreen.BattleScreenWidthLeftX;
        startPos = new Vector3(posX - 1f, GameManager.Instance.Battle.BeastYPos[mySlotID], 0f);
        if (SelfData.isfirst) SelfData.HP = SelfData.MaxHP;
    }

    private void StateListInitialize()
    {
        StateList.Add(eBeastState.Battle_Idle, new BeastState_Idle(this));
        StateList.Add(eBeastState.Battle_Move, new BeastState_Move(this));
        StateList.Add(eBeastState.Battle_Skill, BeastSkill);
        StateList.Add(eBeastState.Battle_Attack, BeastAttack);
        StateList.Add(eBeastState.Battle_Die, new BeastState_Die(this));
    }

    public void SetChangeStageData()
    {
        isSkill = false;
        HealHpOnWaveChange();
        BeastAttack.ResetDataToWave();
        BeastSkill.ResetDataToWave();
        SetStartPos();
        SetCurrentStage(eBeastState.Battle_Idle);
    }

    public void SetCurrentStage(eBeastState state)
    {
        StateList[currentState].Exit();

        currentState = state;
        StateList[currentState].Enter();
        stateDoing = StateList[currentState].Doing;
    }

    public void SetStartPos()
    {
        transform.localPosition = startPos;

        if (SelfData.Type == 3)
        {
            transform.position += new Vector3(0f, 1.3f, 0f);
            Shadow.transform.localPosition -= new Vector3(0f, 0.7f, 0f);
        }
    }

    public void SetEnableAutoFaceMotion(bool autoBlink = true, bool autoMouth = true)
    {
        if (autoBlink)
        {
            float next = 0.5f + UnityEngine.Random.value * 3f;
            Invoke("SetFaceBlink", next);
        }
        if (autoMouth)
        {
            float next = 5f + UnityEngine.Random.value * 10f;
            Invoke("SetFaceOpenMouth", next);
        }
    }

    public void SetFaceBlink()
    {
        if (animator.isActiveAndEnabled)
        {
            animator.SetTrigger("Blink");
        }
    }

    public void SetFaceOpenMouth()
    {
        if (animator.isActiveAndEnabled)
        {
            animator.SetTrigger("OpenMouth");
        }
    }

    private void HealHpOnWaveChange()
    {
        if (isDie) return;

        var spec = TableManager.Instance.Beast2_DataTableTable.GetStudyAttribute((int)eStudyID.WaveHp).SpecValue;
        SelfData.HP += SelfData.MaxHP * (spec * GameManager.Instance.InGameStudy[(int)eStudyID.WaveHp].Value) / 100;
        BeastAttack.GuageBar.SetGuage(SelfData, SelfData.HP);
    }

    private void Update()
    {
        if (isDoing)
        {
            stateDoing();
        }
    }
}
