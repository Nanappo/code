using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BottomButtonControl : MonoBehaviour
{
    public List<UIBottomButton> BottomButton;
    public UIBottomButton currentButton { get; set; }

    public void Initialize()
    {
        for (int i = 0; i < BottomButton.Count; i++)
        {
            BottomButton[i].Initialize(this, i);
        }
    }

    public void ButtonControl(UIBottomButton button)
    {
        if (currentButton != null)
        {
            currentButton.SetClickButton(true);
        }

        currentButton = button;
    }
}
