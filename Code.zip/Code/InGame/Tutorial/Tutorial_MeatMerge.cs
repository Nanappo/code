using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tutorial_MeatMerge : UITutorial
{
    private LobbyMeat LobbyMeat;
    private float speed = 0.7f;

    public override void Ready(Tutorial master)
    {
        base.Ready(master);

        LobbyMeat = GameManager.Instance.Lobby.LobbyMeat;

        Master.Guide.transform.position = LobbyMeat.MeatLaneSlots[0].transform.position;
        Target = LobbyMeat.MeatLaneSlots[1].gameObject;
        Master.LockScreen[1].SetActive(true);
        NextScenario = eTutorial.MeatClosePopup;
    }

    public override IEnumerator Scenario()
    {
        Master.Guide.SetActive(true);
        Master.Guide.GetComponent<Animation>().Play("UI_Tuto_Drag");

        while (!isClear)
        {
            yield return null;
            yield return MoveToGuide();
        }

        End();
    }

    public override void End()
    {
        base.End();
        Master.LockScreen[1].SetActive(false);
        Master.LogEvent();
        Master.NextTutorial(NextScenario);
    }

    private IEnumerator MoveToGuide()
    {
        var originPos = Master.Guide.transform.position;
        while (Vector2.Distance(Master.Guide.transform.position, Target.transform.position) > 0.01f)
        {
            Master.Guide.transform.position = Vector2.MoveTowards(Master.Guide.transform.position, Target.transform.position, speed * Time.deltaTime);
            yield return null;

            if (LobbyMeat.MeatLaneSlots.Count == 1)
            {
                isClear = true;
                yield break;
            }
        }

        Master.Guide.transform.position = originPos;
    }
}
