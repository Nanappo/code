using DLL_Datatables;
using MiniJSON;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public partial class InGameData
{
    public enum LoadType
    {
        None,
        NewPlayer,
        Player,
    }

    public static void LoadLocalData()
    {
        var serializedData = PlayerPrefs.GetString(SAVE_KEY, string.Empty);
        if (string.IsNullOrEmpty(serializedData))
        {
            Debug.Log("PlayerPref���� �����͸� ������ ���� ���� �����ߴٴ� ���� �ǹ�. ������ ã.��.��.��!");
            return;
        }

        string decryptedData = getDecryptData(serializedData);
        var deserialized = Json.Deserialize(decryptedData);
        //var deserialized = JsonUtility.FromJson<object>(decryptedData);
        var dataDic = (Dictionary<string, object>)deserialized;

        Load(dataDic);
    }

    private static string getDecryptData(string encStr)
    {
        // �Ϲ� �ؽ�Ʈ ���.
        string nonEncStr = encStr;
        int last = nonEncStr.Length - 1;
        if ((nonEncStr[0] == '{' || nonEncStr[0] == '[')
            && (nonEncStr[last] == '}' || nonEncStr[last] == ']'))
        {
            // json �̴�.
            //Debug.Log("\t�� ��ȣȭ�� ������");
            //Debug.Log(nonEncStr.ToString());
            return nonEncStr;
        }

        Debug.LogError("[���� ���� �ε�] �ҷ����� ����");
        return null;
    }

    private static void Load(Dictionary<string, object> wholeLoadData)
    {
        UserProperty(wholeLoadData);
        LoadLobbySlot(wholeLoadData);
        LoadLobbyMeat(wholeLoadData);
        LoadTime(wholeLoadData);
        LoadBattleData(wholeLoadData);
        LoadStudyData(wholeLoadData);
        LoadInGameData(wholeLoadData);
        LoadOption(wholeLoadData);
    }

    private static void UserProperty(Dictionary<string, object> dataDic)
    {
        var userCoin = Convert.ToDouble(dataDic[eDataKey.User_Coin.ToString()]);
        var userGold = Convert.ToDouble(dataDic[eDataKey.User_Gold.ToString()]);
        var userDia = Convert.ToDouble(dataDic[eDataKey.User_Dia.ToString()]);
        var userReview = Convert.ToBoolean(dataDic[eDataKey.User_IsReview.ToString()]);
        var userPlayTimeReview = Convert.ToBoolean(dataDic[eDataKey.User_IsPlayTimeReview.ToString()]);
        var userReviewTime = Convert.ToDouble(dataDic[eDataKey.User_ReviewOpenTime.ToString()]);
        var userLastTime = DateTime.UtcNow;

        Coin = userCoin;
        Gold = userGold;
        Dia = userDia;
        IsReview = userReview;
        IsPlayTimeReview = userPlayTimeReview;
        ReviewRewardTime = userReviewTime;

        if (DateTime.TryParse(dataDic[eDataKey.User_RewardStartTime.ToString()].ToString(), out DateTime dt))
        {
            userLastTime = dt;
        }
        RewardStartTime = userLastTime;
    }

    private static void LoadLobbySlot(Dictionary<string, object> dataDic)
    {
        var meatMeatLobbyDic = (Dictionary<string, object>)dataDic[eDataKey.Lobby_MeatSlot.ToString()];
        var meatBattleSlotsDic = (Dictionary<string, object>)dataDic[eDataKey.Lobby_BattleSlotMeat.ToString()];
        var beastBattleSlotsDic = (Dictionary<string, object>)dataDic[eDataKey.Lobby_BattleSlotBeast.ToString()];

        foreach (var kvSlotInfo in meatMeatLobbyDic)
        {
            var meatLobbyOneDataDic = (Dictionary<string, object>)kvSlotInfo.Value;

            var meatData = new MeatData(
                Convert.ToInt32(meatLobbyOneDataDic[eMeat.Level.ToString()])
            );

            var slotNumber = Convert.ToInt32(kvSlotInfo.Key);
            MeatInLobby.Add(slotNumber, meatData);
        }

        foreach (var kvSlotInfo in meatBattleSlotsDic)
        {
            var meatBattleOneDataDic = (Dictionary<string, object>)kvSlotInfo.Value;

            var meatData = new MeatData(
                Convert.ToInt32(meatBattleOneDataDic[eMeat.Level.ToString()])
            );

            var slotNumber = Convert.ToInt32(kvSlotInfo.Key);
            MeatInBattle.Add(slotNumber, meatData);
        }

        foreach (var kvSlotInfo in beastBattleSlotsDic)
        {
            var beastBattleOneDataDic = (Dictionary<string, object>)kvSlotInfo.Value;

            var beastData = new BeastData().SetSaveBeastData(
                Convert.ToInt32(beastBattleOneDataDic[eBeast.BeastID.ToString()]),
                Convert.ToInt32(beastBattleOneDataDic[eBeast.Class.ToString()]),
                Convert.ToInt32(beastBattleOneDataDic[eBeast.Type.ToString()]),
                Convert.ToSingle(beastBattleOneDataDic[eBeast.MoveSpeed.ToString()]),
                Convert.ToInt32(beastBattleOneDataDic[eBeast.Atk.ToString()]),
                Convert.ToInt32(beastBattleOneDataDic[eBeast.HP.ToString()]),
                Convert.ToSingle(beastBattleOneDataDic[eBeast.AtkSpeed.ToString()]),
                Convert.ToSingle(beastBattleOneDataDic[eBeast.CriRate.ToString()]),
                Convert.ToSingle(beastBattleOneDataDic[eBeast.CriDamage.ToString()]),
                Convert.ToInt32(beastBattleOneDataDic[eBeast.BonusLevel.ToString()]),
                Convert.ToInt32(beastBattleOneDataDic[eBeast.SkillCoolTime.ToString()])
                );

            var slotNumber = Convert.ToInt32(kvSlotInfo.Key);
            BeastInBattle.Add(slotNumber, beastData);
        }
    }

    private static void LoadLobbyMeat(Dictionary<string, object> dataDic)
    {
        var meatCoin = Convert.ToInt32(dataDic[eDataKey.Lobby_MeatCharge.ToString()]);
        var meatCreate = Convert.ToInt32(dataDic[eDataKey.Lobby_MeatCreate.ToString()]);
        var meatLevel = Convert.ToInt32(dataDic[eDataKey.Lobby_MeatLevel.ToString()]);
        var meatBonusLevel = Convert.ToInt32(dataDic[eDataKey.Lobby_MeatBonusLevel.ToString()]);
        var meatAutoCreate = Convert.ToBoolean(dataDic[eDataKey.Lobby_MeatAutoCreate.ToString()]);
        var meatSlotcount = Convert.ToInt32(dataDic[eDataKey.Lobby_MeatSlotCount.ToString()]);
        var meatBattleCount = Convert.ToInt32(dataDic[eDataKey.Lobby_BattleSlotCount.ToString()]);
        var meatHighLevel = Convert.ToInt32(dataDic[eDataKey.Lobby_MeatCurrentHighLevel.ToString()]);

        MeatCoin = meatCoin;
        MeatCreate = meatCreate;
        CreateMeatLevel = meatLevel;
        CreateMeatBonusLevel = meatBonusLevel;
        IsAutoCreate = meatAutoCreate;
        MeatSlotCount = meatSlotcount;
        BattleSlotCount = meatBattleCount;
        CurrentMeatHighLevel = meatHighLevel;
    }

    private static void LoadTime(Dictionary<string, object> dataDic)
    {
        var meatTimeAutoCreate = Convert.ToSingle(dataDic[eDataKey.Lobby_MeatAutoCreateTime.ToString()]);
        var meatTimeAutoMerge = Convert.ToSingle(dataDic[eDataKey.Lobby_MeatAutoMergeTime.ToString()]);
        var timeAutoCreate = Convert.ToSingle(dataDic[eDataKey.Lobby_MeatAutoCreate_SaveTime.ToString()]);

        AutoCreateTime = timeAutoCreate;
        MeatAutoCreateTime = meatTimeAutoCreate;
        MeatAutoMergeTime = meatTimeAutoMerge;
    }

    private static void LoadOption(Dictionary<string, object> dataDic)
    {
        var bgmvolume = Convert.ToSingle(dataDic[eDataKey.Option_BgmVolume.ToString()]);
        var sfxvolume = Convert.ToSingle(dataDic[eDataKey.Option_SfxVolume.ToString()]);
        var autosleep = Convert.ToBoolean(dataDic[eDataKey.Option_AutoSleep.ToString()]);
        var language = Convert.ToInt32(dataDic[eDataKey.Option_Language.ToString()]);

        bgmVolume = bgmvolume;
        sfxVolume = sfxvolume;
        IsAutoSleep = autosleep;
        languageType = (eLanguageType)language;
    }

    private static void LoadBattleData(Dictionary<string, object> dataDic)
    {
        var lastwave = Convert.ToInt32(dataDic[eDataKey.Battle_LastWave.ToString()]);
        var currentwave = Convert.ToInt32(dataDic[eDataKey.Battle_CurrentWave.ToString()]);
        var highestarea = Convert.ToInt32(dataDic[eDataKey.Battle_HighestArea.ToString()]);
        var currentarea = Convert.ToInt32(dataDic[eDataKey.Battle_CurrentArea.ToString()]);
        var iscoinreward = Convert.ToBoolean(dataDic[eDataKey.Battle_IsCoinReward.ToString()]);

        LastWave = lastwave;
        CurrentWave = currentwave;
        HighestArea = highestarea;
        CurrentArea = currentarea;
        IsCoinReward = iscoinreward;
    }

    private static void LoadStudyData(Dictionary<string, object> dataDic)
    {
        var studyDic = (Dictionary<string, object>)dataDic[eDataKey.Study_Level.ToString()];

        foreach (var kvStudyInfo in studyDic)
        {
            var studyID = Convert.ToInt32(kvStudyInfo.Key);
            var studyData = Convert.ToInt32(kvStudyInfo.Value);
            StudyData.Add(studyID, studyData);
        }
    }

    private static void LoadInGameData(Dictionary<string, object> dataDic)
    {
        var inGameBeastDic = (Dictionary<string, object>)dataDic[eDataKey.InGame_Beast.ToString()];
        var inGameBeastAbilityDic = (Dictionary<string, object>)dataDic[eDataKey.InGame_BeastAbility.ToString()];
        var tutorial = Convert.ToInt32(dataDic[eDataKey.InGame_Tutorial.ToString()]);

        foreach (var kvInGameInfo in inGameBeastDic)
        {
            var inGameBeastOneDataDic = (Dictionary<string, object>)kvInGameInfo.Value;
            var hasBeastKey = Convert.ToInt32(kvInGameInfo.Key);

            var hasBeastValue = new HasBeast
            {
                beastLevel = Convert.ToInt32(inGameBeastOneDataDic[eHasBeast.Level.ToString()]),
                beastCount = Convert.ToInt32(inGameBeastOneDataDic[eHasBeast.Count.ToString()])
            };

            BeastInGame.Add(hasBeastKey, hasBeastValue);
        }

        foreach (var kvBeast in inGameBeastAbilityDic) // kvBeast.Key = BeastID(string)
        {
            int beastID = Convert.ToInt32(kvBeast.Key);
            var abilityDic = (Dictionary<string, object>)kvBeast.Value;

            var abilityList = new List<AbilityInfo>();
            //Debug.Log($"�ε� - BeastID: {beastID}, AbilityRaw Count: {abilityDic.Count}");
            foreach (var kvAbility in abilityDic) // kvAbility.Key = abilityID(string)
            {
                var abilityData = (Dictionary<string, object>)kvAbility.Value;

                var abilityInfo = new AbilityInfo
                {
                    abilityID = Convert.ToInt32(abilityData[eAbilityInfo.abilityID.ToString()]),
                    abilityLevel = Convert.ToInt32(abilityData[eAbilityInfo.abilityLevel.ToString()])
                };

                abilityList.Add(abilityInfo);
                //Debug.Log($"   �ε� - AbilityID: {abilityInfo.abilityID}, Level: {abilityInfo.abilityLevel}");
            }

            BeastAbility.Add(beastID, abilityList);
            //Debug.Log($"�ε� �Ϸ� - BeastID: {beastID}, BeastAbility Count: {BeastAbility.Count}");
        }

        tutorialScenario = tutorial;
    }
}
