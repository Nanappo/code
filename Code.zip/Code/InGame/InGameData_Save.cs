using MiniJSON;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public partial class InGameData
{
    public enum eDataKey
    {
        //Property
        User_Coin,
        User_Gold,
        User_Dia,
        User_IsReview,
        User_IsPlayTimeReview,
        User_ReviewOpenTime,
        User_RewardStartTime,

        //Lobby
        Lobby_MeatSlot,
        Lobby_MeatCharge,
        Lobby_MeatCreate,
        Lobby_MeatLevel,
        Lobby_MeatBonusLevel,
        Lobby_MeatCurrentHighLevel,
        Lobby_MeatAutoCreate,
        Lobby_MeatSlotCount,
        Lobby_BattleSlotMeat,
        Lobby_BattleSlotCount,
        Lobby_BattleSlotBeast,

        //Time
        Lobby_MeatAutoCreateTime,
        Lobby_MeatAutoMergeTime,
        Lobby_MeatAutoCreate_SaveTime,

        //Battle
        Battle_LastWave,
        Battle_CurrentWave,
        Battle_HighestArea,
        Battle_CurrentArea,
        Battle_IsCoinReward,

        //Study
        Study_Level,

        //InGame
        InGame_Beast,
        InGame_BeastAbility,
        InGame_Tutorial,

        //Option
        Option_BgmVolume,
        Option_SfxVolume,
        Option_AutoSleep,
        Option_Language,
    }

    public enum eMeat
    {
        Level,
        BonusLevel,
    }

    public enum eBeast
    {
        BeastID,
        Class,
        Type,
        MoveSpeed,
        Atk,
        HP,
        AtkSpeed,
        CriRate,
        CriDamage,
        BonusLevel,
        SkillCoolTime,
    }

    public enum eHasBeast
    {
        Level,
        Count,
    }

    public enum eAbilityInfo
    {
        abilityID,
        abilityLevel,
    }

    public static readonly string SAVE_KEY = "BeastWar_Cle_Ver2";

    public static void SaveData()
    {
        var wholeSaveData = new Dictionary<eDataKey, object>();

        Save(wholeSaveData);

        string jsonSerialized = Json.Serialize(wholeSaveData);

        PlayerPrefs.SetString(SAVE_KEY, jsonSerialized);
        PlayerPrefs.Save();

        Debug.Log("���� ���� �Ϸ�");
    }

    public static void Save(Dictionary<eDataKey, object> wholeSaveData)
    {
        wholeSaveData.Clear();

        //Property
        SetInGameData();
        wholeSaveData.Add(eDataKey.User_Coin, Coin);
        wholeSaveData.Add(eDataKey.User_Gold, Gold);
        wholeSaveData.Add(eDataKey.User_Dia, Dia);
        wholeSaveData.Add(eDataKey.User_IsReview, IsReview);
        wholeSaveData.Add(eDataKey.User_IsPlayTimeReview, IsPlayTimeReview);
        wholeSaveData.Add(eDataKey.User_ReviewOpenTime, ReviewRewardTime);
        wholeSaveData.Add(eDataKey.User_RewardStartTime, RewardStartTime);

        //Lobby
        wholeSaveData.Add(eDataKey.Lobby_MeatSlot, GetMeatLobbyData());
        wholeSaveData.Add(eDataKey.Lobby_BattleSlotMeat, GetMeatBattleSlotData());
        wholeSaveData.Add(eDataKey.Lobby_MeatCharge, MeatCoin);
        wholeSaveData.Add(eDataKey.Lobby_MeatCreate, MeatCreate);
        wholeSaveData.Add(eDataKey.Lobby_MeatLevel, CreateMeatLevel);
        wholeSaveData.Add(eDataKey.Lobby_MeatBonusLevel, CreateMeatBonusLevel);
        wholeSaveData.Add(eDataKey.Lobby_MeatCurrentHighLevel, CurrentMeatHighLevel);
        wholeSaveData.Add(eDataKey.Lobby_MeatAutoCreate, IsAutoCreate);
        wholeSaveData.Add(eDataKey.Lobby_MeatSlotCount, MeatSlotCount);
        wholeSaveData.Add(eDataKey.Lobby_BattleSlotCount, BattleSlotCount);
        wholeSaveData.Add(eDataKey.Lobby_BattleSlotBeast, GetBeastBattleSlotData());

        //Time
        wholeSaveData.Add(eDataKey.Lobby_MeatAutoCreateTime, MeatAutoCreateTime);
        wholeSaveData.Add(eDataKey.Lobby_MeatAutoMergeTime, MeatAutoMergeTime);
        wholeSaveData.Add(eDataKey.Lobby_MeatAutoCreate_SaveTime, AutoCreateTime);

        //Battle
        wholeSaveData.Add(eDataKey.Battle_LastWave, LastWave);
        wholeSaveData.Add(eDataKey.Battle_CurrentWave, CurrentWave);
        wholeSaveData.Add(eDataKey.Battle_HighestArea, HighestArea);
        wholeSaveData.Add(eDataKey.Battle_CurrentArea, CurrentArea);
        wholeSaveData.Add(eDataKey.Battle_IsCoinReward, IsCoinReward);

        //Study
        wholeSaveData.Add(eDataKey.Study_Level, GetStudyData());

        //Beast
        wholeSaveData.Add(eDataKey.InGame_Beast, GetInGameBeast());
        wholeSaveData.Add(eDataKey.InGame_BeastAbility, GetInGameBeastAbility());
        wholeSaveData.Add(eDataKey.InGame_Tutorial, tutorialScenario);

        //Option
        wholeSaveData.Add(eDataKey.Option_BgmVolume, bgmVolume);
        wholeSaveData.Add(eDataKey.Option_SfxVolume, sfxVolume);
        wholeSaveData.Add(eDataKey.Option_AutoSleep, IsAutoSleep);
        wholeSaveData.Add(eDataKey.Option_Language, (int)languageType);
    }

    public static Dictionary<int, Dictionary<eMeat, object>> GetMeatLobbyData()
    {
        var meatLobbySlotData = new Dictionary<int, Dictionary<eMeat, object>>();

        if (MeatInLobby.Count == 0) return meatLobbySlotData;

        foreach (var kvLobbySlotInfo in MeatInLobby)
        {
            meatLobbySlotData.Add(kvLobbySlotInfo.Key, new Dictionary<eMeat, object>
            {
                { eMeat.Level,      kvLobbySlotInfo.Value.Level }
            });
        }

        return meatLobbySlotData;
    }

    public static Dictionary<int, Dictionary<eMeat, object>> GetMeatBattleSlotData()
    {
        var meatBattleSlotData = new Dictionary<int, Dictionary<eMeat, object>>();

        if (MeatInBattle.Count == 0) return meatBattleSlotData;

        foreach (var kvBattleSlotInfo in MeatInBattle)
        {
            meatBattleSlotData.Add(kvBattleSlotInfo.Key, new Dictionary<eMeat, object>
            {
                { eMeat.Level,      kvBattleSlotInfo.Value.Level }
            });
        }

        return meatBattleSlotData;
    }

    public static Dictionary<int, Dictionary<eBeast, object>> GetBeastBattleSlotData()
    {
        var beastBattleSlotData = new Dictionary<int, Dictionary<eBeast, object>>();

        if (BeastInBattle.Count == 0) return beastBattleSlotData;

        foreach (var kvBattleSlotInfo in BeastInBattle)
        {
            beastBattleSlotData.Add(kvBattleSlotInfo.Key, new Dictionary<eBeast, object>
            {
                { eBeast.BeastID,      kvBattleSlotInfo.Value.BeastID },
                { eBeast.Class,   kvBattleSlotInfo.Value.Class },
                { eBeast.Type , kvBattleSlotInfo.Value.Type },
                { eBeast.MoveSpeed,   kvBattleSlotInfo.Value.MoveSpeed },
                { eBeast.Atk,   kvBattleSlotInfo.Value.Atk },
                { eBeast.HP,   kvBattleSlotInfo.Value.HP },
                { eBeast.AtkSpeed,   kvBattleSlotInfo.Value.AtkSpeed },
                { eBeast.CriRate,   kvBattleSlotInfo.Value.CriRate },
                { eBeast.CriDamage,   kvBattleSlotInfo.Value.CriDamage },
                { eBeast.BonusLevel,   kvBattleSlotInfo.Value.BonusLevel },
                { eBeast.SkillCoolTime,   kvBattleSlotInfo.Value.SkillCoolTime },
            });
        }

        return beastBattleSlotData;
    }

    public static Dictionary<int, Dictionary<eHasBeast, object>> GetInGameBeast()
    {
        var beastData = new Dictionary<int, Dictionary<eHasBeast, object>>();

        if (BeastInGame.Count == 0) return beastData;

        foreach (var kvInGameBeast in BeastInGame)
        {
            beastData.Add(kvInGameBeast.Key, new Dictionary<eHasBeast, object>
            {
                { eHasBeast.Level,      kvInGameBeast.Value.beastLevel },
                { eHasBeast.Count,   kvInGameBeast.Value.beastCount }
            });
        }

        return beastData;
    }

    public static Dictionary<int, Dictionary<int, Dictionary<eAbilityInfo, object>>> GetInGameBeastAbility()
    {
        var beastAbilityData = new Dictionary<int, Dictionary<int, Dictionary<eAbilityInfo, object>>>();

        if (BeastAbility.Count == 0)
            return beastAbilityData;

        foreach (var kvBeast in BeastAbility) // kvBeast.Key = BeastID, kvBeast.Value = List<AbilityInfo>
        {
            var abilityDic = new Dictionary<int, Dictionary<eAbilityInfo, object>>();

            foreach (var ability in kvBeast.Value) // ����Ʈ ��ȸ
            {
                var abilityData = new Dictionary<eAbilityInfo, object>
                {
                    { eAbilityInfo.abilityID, ability.abilityID },
                    { eAbilityInfo.abilityLevel, ability.abilityLevel }
                };

                abilityDic.Add(ability.abilityID, abilityData);
                //Debug.Log($"   ���� - AbilityID: {ability.abilityID}, Level: {ability.abilityLevel}");
            }

            beastAbilityData.Add(kvBeast.Key, abilityDic);
        }
        //Debug.Log($"���� �Ϸ� - BeastAbilityData Count: {beastAbilityData.Count}");
        return beastAbilityData;
    }

    public static Dictionary<int, int> GetStudyData()
    {
        var studyData = new Dictionary<int, int>();

        if (StudyData.Count == 0)
        {
            SetStudyData();
        }

        foreach (var kvStudyInfo in StudyData)
        {
            studyData.Add(kvStudyInfo.Key, kvStudyInfo.Value);
        }

        return studyData;
    }

    public static void SetInGameData()
    {
        Gold = GameManager.Instance.InGameGold.Value;
        Coin = GameManager.Instance.InGameCoin.Value;
        Dia = GameManager.Instance.InGameDia.Value;

        //StudyData
        StudyData.Clear();
        foreach (var data in GameManager.Instance.InGameStudy)
        {
            StudyData.Add(data.Key, data.Value.Value);
        }
    }
}
