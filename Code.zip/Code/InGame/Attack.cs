using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Attack : MonoBehaviour
{
    public virtual GameObject MakeProjectile(int index, GameObject prefab = null, string prefabName = "")
    {
        //var projectile = Instantiate(prefab);
        //projectile.transform.SetParent(parent.transform);
        //projectile.transform.localPosition = Vector3.zero;
        //projectile.transform.localRotation = Quaternion.identity;
        //projectile.transform.localScale = Vector3.one;

        //return projectile;

        //var objname = prefab.name;
        var objname = prefabName == "" ? (prefab == null ? null : prefab.name) : prefabName;
        var objPath = string.Format("Prefabs/Projectile/{0}", objname);
        var objList = ObjectPoolManager.Instance.GetPool(objname, index, objPath);
        var obj = objList.GetObject(objPath);
        return obj;
    }

    public virtual void OnAttack(float coolTime, Action action)
    {
        StartCoroutine(OnCoolTime(coolTime, action));
    }

    private IEnumerator OnCoolTime(float coolTime, Action action)
    {
        yield return new WaitForSeconds(coolTime);
        action?.Invoke();
    }

    public virtual float HitToDamage(float hp, float damage)
    {
        hp -= damage;
        if (hp < 0) hp = 0;

        return hp;
    }

    public virtual void BeelineAttack(GameObject prefab, Vector2 dir, float force)
    {
        if (prefab == null) return;

        var rb = prefab.GetComponent<Rigidbody2D>();
        rb.velocity = dir * force;
        //var randomAngle = UnityEngine.Random.Range(-5f, 10f);
        //var dirAngle = Quaternion.Euler(0, 0, randomAngle) * dir;
    }

    public virtual void CurveAttack(GameObject prefab, Vector2 dir, float forwardForce, float upForce = 0f)
    {
        var rb = prefab.GetComponent<Rigidbody2D>();

        Vector2 forceDir = dir * forwardForce + Vector2.up * upForce;
        rb.AddForce(forceDir, ForceMode2D.Impulse);
    }

    public virtual void StopAttack()
    {
        StopAllCoroutines();
    }
}
