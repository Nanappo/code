using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StudySpecUp : MonoBehaviour
{
    protected void BeastAtkUp(int studyID)
    {
        GameManager.Instance.InGameStudy[studyID].Value += 1;

        foreach (var beast in GameManager.Instance.Battle.BattleBeast)
        {
            beast.Value.SelfData.Atk = GameManager.Instance.Battle.SetBattleBeastAtk(beast.Value.SelfData, beast.Key);
            beast.Value.BeastAttack.SetAtkToBuffAtk();
            beast.Value.BeastSkill.SetAtkToStyle(beast.Value.BeastSkill.myStyle);
            //Debug.Log($" Atk : {beast.Value.SelfData.Atk}");
        }
    }

    protected void BeastCriRateUp(int studyID)
    {
        GameManager.Instance.InGameStudy[studyID].Value += 1;

        foreach (var beast in GameManager.Instance.Battle.BattleBeast)
        {
            beast.Value.SelfData.CriRate = GameManager.Instance.Battle.SetBattleBeastCriRate(beast.Value.SelfData);
            //Debug.Log($" CriRate : {beast.Value.SelfData.CriRate}");
        }
    }

    protected void BeastCriDamageUp(int studyID)
    {
        GameManager.Instance.InGameStudy[studyID].Value += 1;

        foreach (var beast in GameManager.Instance.Battle.BattleBeast)
        {
            beast.Value.SelfData.CriDamage = GameManager.Instance.Battle.SetBattleBeastCriDamage(beast.Value.SelfData);
            //Debug.Log($" CriDamage : {beast.Value.SelfData.CriDamage}");
        }
    }

    protected void BeastMaxHPUp(int studyID)
    {
        GameManager.Instance.InGameStudy[studyID].Value += 1;

        foreach (var beast in GameManager.Instance.Battle.BattleBeast)
        {
            beast.Value.SelfData.MaxHP = GameManager.Instance.Battle.SetBattleBeastMaxHP(beast.Value.SelfData);
            beast.Value.BeastAttack.GuageBar.SetGuage(beast.Value.SelfData, beast.Value.SelfData.HP);
            beast.Value.BeastSkill.SetAtkToStyle(beast.Value.BeastSkill.myStyle);
            //Debug.Log($" HP : {beast.Value.SelfData.MaxHP}");
        }
    }

    protected void HealHpOnWaveChange(int studyID)
    {
        //���̺� Ŭ�����ϰ� ���� ���̺� �Ѿ ���� ����
        GameManager.Instance.InGameStudy[studyID].Value += 1;
    }

    protected void AmountOfGoldUp(int studyID)
    {
        GameManager.Instance.InGameStudy[studyID].Value += 1;
    }

    protected void DoubleGoldReward(int studyID)
    {
        GameManager.Instance.InGameStudy[studyID].Value += 1;
    }

    protected void IdleRewardUp(int studyID)
    {
        GameManager.Instance.InGameStudy[studyID].Value += 1;
    }

    protected void ThunderDamageUp(int studyID)
    {
        GameManager.Instance.InGameStudy[studyID].Value += 1;
    }

    protected void ThunderAutoSpeed(int studyID)
    {
        GameManager.Instance.InGameStudy[studyID].Value += 1;
        GameManager.Instance.Battle.BattleUI.AutoThunderAttack();
    }

    protected void MeatChargeSpeedUP(int studyID)
    {
        GameManager.Instance.InGameStudy[studyID].Value += 1;
        GameManager.Instance.Lobby.LobbyButton.SetMeatChargeTime(studyID);
    }

    protected void MeatCreateMaxUp(int studyID)
    {
        GameManager.Instance.InGameStudy[studyID].Value += 1;
        GameManager.Instance.Lobby.LobbyButton.SetMeatCreatMaxUp(studyID);
    }

    protected void LobbyMeatSlotAdd(int studyID)
    {
        GameManager.Instance.InGameStudy[studyID].Value += 1;
        InGameData.MeatSlotCount++;

        foreach (var slot in GameManager.Instance.Lobby.LobbyMeat.MeatSlots)
        {
            if (slot.SelfData.isLock)
            {
                slot.HideLockImage();
                break;
            }
        }
    }

    protected void CreateMeatLevelCoin(int studyID)
    {
        GameManager.Instance.InGameStudy[studyID].Value += 1;
        InGameData.CreateMeatLevel = GameManager.Instance.Lobby.SetMeatCreateLevel();
        GameManager.Instance.Lobby.UpgradeAllMeat();
    }

    protected void CreateMeatLevelDia(int studyID)
    {
        GameManager.Instance.InGameStudy[studyID].Value += 1;
        InGameData.CreateMeatLevel = GameManager.Instance.Lobby.SetMeatCreateLevel();
        GameManager.Instance.Lobby.UpgradeAllMeat();
    }

    protected void AutoCreateTime(int studyID)
    {
        GameManager.Instance.InGameStudy[studyID].Value += 1;

        var spec = TableManager.Instance.Beast2_DataTableTable.GetStudyAttribute(studyID).SpecValue;
        InGameData.MeatAutoCreateTime = 10 - (spec * GameManager.Instance.InGameStudy[studyID].Value);
    }

    protected void AutoMergeTime(int studyID)
    {
        GameManager.Instance.InGameStudy[studyID].Value += 1;

        var spec = TableManager.Instance.Beast2_DataTableTable.GetStudyAttribute(studyID).SpecValue;
        InGameData.MeatAutoMergeTime = 10 - (spec * GameManager.Instance.InGameStudy[studyID].Value);
    }
}
