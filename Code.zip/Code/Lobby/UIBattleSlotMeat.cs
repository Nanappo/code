using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class UIBattleSlotMeat : UIEventTrigger
{
    public GameObject MeatIconObj
    {
        get
        {
            return MeatIconRenderer.gameObject;
        }
    }

    public MeatData MeatBattleData { get; set; }
    public BeastData BeastBattleData { get; set; }

    public class MeatSlotData
    {
        public int SlotID;
        public int Level;
        public bool isMeat;
        public bool isLock;
    }

    public Button Slot;
    public MeatSlotData SelfData;
    public Image LockImg;
    public Image MeatIconRenderer;
    public Text MeatLeveltxt;
    public Text BeastBonusLeveltxt;
    public Image BeastIconObj;
    public Image BeastIcon;
    public Image BeastIconBackground;
    public GameObject WarningIcon;

    private LobbyManager Lobby;

    public void Initialize(int slotId)
    {
        Lobby = GameManager.Instance.Lobby;

        if (InGameData.MeatInBattle.ContainsKey(slotId))
        {
            SetBattleSlotData(slotId);
        }
        else
        {
            SelfData = new MeatSlotData()
            {
                SlotID = slotId,
                Level = 0,
                isMeat = false,
                isLock = true,
            };

            LockImg.gameObject.SetActive(true);
        }

        InitializeDrag();
    }

    public override void OnPointerDownDelegate(PointerEventData data)
    {
        Debug.Log("=== Pointer Down === @ " + SelfData.SlotID);

        if (InGameData.tutorialScenario < (int)eTutorial.FirstTeamSlot) return;
        GameManager.Instance.Lobby.PopupManager.BeastInfoPopup.ShowPopup(SelfData.SlotID, true);
    }

    public void BeastCreateIcon(int beastID)
    {
        BeastIconObj.gameObject.SetActive(true);
        BeastIcon.sprite = Lobby.LobbyUI.GetSprite(Lobby.LobbyUI.BattleslotBeastIcon, beastID.ToString());
        BeastIconBackground.color = GameManager.Instance.Battle.SetBeastIconBackgroundColor(BeastBattleData.Class);

    }

    public void MeatCreateIcon()
    {
        var iconIndex = SelfData.Level % 100 != 0 ? SelfData.Level % 100 : 100;
        var meatIcon = GameManager.Instance.Lobby.MeatSpriteDic[iconIndex];

        MeatIconRenderer.sprite = meatIcon;
        MeatLeveltxt.text = SelfData.Level.ToString();
        BeastBonusLeveltxt.text = string.Format("+ {0}", BeastBattleData.BonusLevel.ToString());
        LockImg.gameObject.SetActive(false);
        MeatIconObj.SetActive(true);
        MeatLeveltxt.gameObject.SetActive(true);
        var isbonus = BeastBattleData.BonusLevel == 0 ? false : true;
        BeastBonusLeveltxt.gameObject.SetActive(isbonus);
    }

    public void SetSelfData(UILobbyMeatSlot slotData)
    {
        SelfData.Level = slotData.MeatItemData.Level;
        SelfData.isMeat = true;
    }

    public void DeleteIcon()
    {
        MeatIconRenderer.sprite = null;
        MeatIconObj.SetActive(false);
    }

    public void SetBattleSlotData(int slotID)
    {
        MeatBattleData ??= new MeatData();
        MeatBattleData.SetMeatLevel(InGameData.MeatInBattle[slotID].Level);

        SelfData = new MeatSlotData()
        {
            SlotID = slotID,
            Level = InGameData.MeatInBattle[slotID].Level,
            isMeat = true,
            isLock = false,
        };

        UpdateBattleBeastData(slotID);
        MeatCreateIcon();
    }

    public void UpdateBattleBeastData(int slotID)
    {
        BeastBattleData = InGameData.BeastInBattle[slotID];
        BeastCreateIcon(BeastBattleData.BeastID);
    }
}
