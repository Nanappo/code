using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameCheat : MonoBehaviour
{
    public Button tutorialButton;
    public Button coinButton;
    public Button goldButton;
    public Button diaButton;
    public Button meatcoinButton;
    public Button gamespeedButton;

    private Button rootButton;
    private List<Button> buttonList = new List<Button>();

    private void Start()
    {
        rootButton = GetComponent<Button>();
        SetButtonList();

        rootButton.onClick.AddListener(() =>
        {
            OnRootButton();
        });

        tutorialButton.onClick.AddListener(() =>
        {
            OnTutorialButton();
        });

        coinButton.onClick.AddListener(() =>
        {
            OnCoinButton();
        });

        goldButton.onClick.AddListener(() =>
        {
            OnGoldButton();
        });

        diaButton.onClick.AddListener(() =>
        {
            OnDiaButton();
        });

        meatcoinButton.onClick.AddListener(() =>
        {
            OnMeatCoinButton();
        });

        gamespeedButton.onClick.AddListener(() =>
        {
            OnGameSpeedButton();
        });
    }

    private void SetButtonList()
    {
        buttonList.Add(tutorialButton);
        buttonList.Add(coinButton);
        buttonList.Add(goldButton);
        buttonList.Add(diaButton);
        buttonList.Add(meatcoinButton);
        buttonList.Add(gamespeedButton);
    }

    private void OnRootButton()
    {
        foreach (var button in buttonList)
        {
            button.gameObject.SetActive(!button.gameObject.activeSelf);
        }
    }

    private void OnTutorialButton()
    {
        GameManager.Instance.Lobby.Tutorial.StopTutorial();
        Debug.Log("=========Tutorial End");
    }

    private void OnCoinButton()
    {
        GameManager.Instance.InGameCoin.Value += 1000000000;
        Debug.Log("=========Coin Up");
    }

    private void OnGoldButton()
    {
        GameManager.Instance.InGameGold.Value += 1000000000;
        Debug.Log("=========Goid Up");
    }

    private void OnDiaButton()
    {
        GameManager.Instance.InGameDia.Value += 1000000000;
        Debug.Log("=========Dia Up");
    }

    private void OnMeatCoinButton()
    {
        InGameData.MeatCoin += 100;
        foreach (var button in GameManager.Instance.Lobby.LobbyButton.groups)
        {
            if (button.Type == eMeatButtonType.Charge)
            {
                var script = button.Button.gameObject.GetComponent<UILobbySlotButtonText>();
                script.SetMainText(InGameData.MeatCoin.ToString());
            }
        }

        Debug.Log("=========MeatCoin Up");
    }

    private void OnGameSpeedButton()
    {
        var gameSpeed = Time.timeScale;
        Time.timeScale += gameSpeed;

        if (Time.timeScale > 4f)
        {
            Time.timeScale = 1;
            Debug.Log($"=========GameSpeed Origin:  {Time.timeScale}");
        }

        Debug.Log($"=========GameSpeed Up:  {Time.timeScale}");
    }
}
