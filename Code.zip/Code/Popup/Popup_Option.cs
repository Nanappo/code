using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Popup_Option : UIPopupControl
{
    public Slider bgmSound;
    public Slider sfxSound;
    public Button languageButton;
    public Button sleepModeAutoButton;
    public Button sleepModeButton;
    public GameObject sleepModeOn;
    public GameObject sleepModeOff;
    public GameObject languageList;

    protected override void Initialize()
    {
        base.Initialize();
        var languge = languageList.GetComponent<LangugeSelect>();

        bgmSound.onValueChanged.AddListener(value =>
        {
            SoundManager.Instance.SetBgmVolume(value);
            InGameData.bgmVolume = value;
        });

        sfxSound.onValueChanged.AddListener(value =>
        {
            SoundManager.Instance.SetSfxVolume(value);
            InGameData.sfxVolume = value;
        });

        languageButton.onClick.AddListener(() =>
        {
            languageList.SetActive(true);
        });

        sleepModeButton.onClick.AddListener(() =>
        {
            GameManager.Instance.Lobby.LobbyUI.sleepMode.EnterSleepMode();
        });

        sleepModeAutoButton.onClick.AddListener(() =>
        {
            OnSleepModeAuto();
        });

        languge.Initialize();
        SetAutoSleepUI();
    }

    private void OnSleepModeAuto()
    {
        InGameData.IsAutoSleep = !InGameData.IsAutoSleep;
        SetAutoSleepUI();
    }

    private void SetAutoSleepUI()
    {
        sleepModeOn.SetActive(InGameData.IsAutoSleep);
        sleepModeOff.SetActive(!InGameData.IsAutoSleep);
    }

    public override void ShowPopup(int slotID = 0, bool isBattle = false)
    {
        OnCheck += ClosePopup;
        base.ShowPopup();
    }

    public override void ClosePopup()
    {
        base.ClosePopup();
    }
}
