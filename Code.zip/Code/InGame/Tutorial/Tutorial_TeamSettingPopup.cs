using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tutorial_TeamSettingPopup : UITutorial
{
    private Popup_TeamSetting Popup;

    public override void Ready(Tutorial master)
    {
        base.Ready(master);

        Popup = GameManager.Instance.Lobby.PopupManager.TeamSettingPopup;

        Target = GameManager.Instance.Lobby.TeamButton.gameObject;
        if (Target != null)
        {
            Master.Guide.transform.position = Target.transform.position;
        }

        Master.LockScreen[9].SetActive(true);
        NextScenario = eTutorial.InventorySelect;
    }

    public override IEnumerator Scenario()
    {
        Master.Guide.SetActive(true);
        Master.Guide.GetComponent<Animation>().Play("UI_Tuto_Idle");

        while (!isClear)
        {
            yield return null;
            if (Popup.gameObject.activeSelf == true)
            {
                isClear = true;
            }
        }

        End();
    }

    public override void End()
    {
        base.End();
        Master.LockScreen[9].SetActive(false);
        Master.NextTutorial(NextScenario);
    }
}
