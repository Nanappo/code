using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tutorial_ClosePopup : UITutorial
{
    private Popup_NewMeat Popup;

    public override void Ready(Tutorial master)
    {
        base.Ready(master);

        Popup = GameManager.Instance.Lobby.PopupManager.NewMeatPopup;

        Target = Popup.checkButton.gameObject;
        if (Target != null)
        {
            Master.Guide.transform.position = Target.transform.position;
        }

        Master.LockScreen[2].SetActive(true);
        NextScenario = eTutorial.BeastClosePopup;
    }

    public override IEnumerator Scenario()
    {
        if (Popup.gameObject.activeSelf == false) End();

        Master.Guide.SetActive(true);
        Master.Guide.GetComponent<Animation>().Play("UI_Tuto_Idle");

        while (!isClear)
        {
            yield return null;
            if (Popup.gameObject.activeSelf == false)
            {
                isClear = true;
            }
        }

        End();
    }

    public override void End()
    {
        base.End();
        Master.LockScreen[2].SetActive(false);
        Master.LogEvent();
        Master.NextTutorial(NextScenario);
    }
}
