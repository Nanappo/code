using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BeastData
{
    public int BeastID;
    public int Class;
    public int Type;
    public float MoveSpeed;
    public int Atk;
    public float HP;
    public float AtkSpeed;
    public float CriRate;
    public float CriDamage;
    public int Active;
    public int Passive;
    public int Owned;
    public int Abilitiy1;
    public int Abilitiy2;
    public int Abilitiy3;
    public int Abilitiy4;
    public int Abilitiy5;
    public int Abilitiy6;
    public int MaxHP;
    public int OriginAtk;
    public int BonusLevel;
    public float SkillCoolTime;

    public bool isfirst;

    public BeastData SetBeastData(int beastID)
    {
        var TableData = TableManager.Instance.Beast2_DataTableTable.GetBeastAttribute(beastID);
        var SKillTableData = TableManager.Instance.Beast2_DataTableTable.GetSkillAttribute(TableData.Active);

        BeastID = TableData.BeastID;
        Class = TableData.Class;
        Type = TableData.Type;
        MoveSpeed = TableData.MoveSpeed;
        Atk = TableData.Atk;
        HP = TableData.HP;
        AtkSpeed = TableData.AtkSpeed;
        CriRate = TableData.CriRate;
        CriDamage = TableData.CriDamage;
        Active = TableData.Active;
        Passive = TableData.Passive;
        Owned = TableData.Owned;
        Abilitiy1 = TableData.Abilitiy1;
        Abilitiy2 = TableData.Abilitiy2;
        Abilitiy3 = TableData.Abilitiy3;
        Abilitiy4 = TableData.Abilitiy4;
        Abilitiy5 = TableData.Abilitiy5;
        Abilitiy6 = TableData.Abilitiy6;
        MaxHP = TableData.HP;
        OriginAtk = TableData.Atk;
        BonusLevel = 0;
        SkillCoolTime = SKillTableData.CoolTime;

        isfirst = true;

        return this;
    }

    public BeastData SetSaveBeastData(int _beastID, int _class, int _type, float _moveSpeed, int _atk, int _HP,
        float _atkSpeed, float _criRate, float _criDamage, int _bonusLevel, float _coolTime)
    {
        var TableData = TableManager.Instance.Beast2_DataTableTable.GetBeastAttribute(_beastID);

        BeastID = _beastID;
        Class = _class;
        Type = _type;
        MoveSpeed = _moveSpeed;
        Atk = _atk;
        HP = _HP;
        AtkSpeed = _atkSpeed;
        CriRate = _criRate;
        CriDamage= _criDamage;
        Active = TableData.Active;
        Passive = TableData.Passive;
        Owned = TableData.Owned;
        Abilitiy1 = TableData.Abilitiy1;
        Abilitiy2 = TableData.Abilitiy2;
        Abilitiy3 = TableData.Abilitiy3;
        Abilitiy4 = TableData.Abilitiy4;
        Abilitiy5 = TableData.Abilitiy5;
        Abilitiy6 = TableData.Abilitiy6;
        MaxHP = TableData.HP;
        OriginAtk = TableData.Atk;
        BonusLevel = _bonusLevel;
        SkillCoolTime = _coolTime;

        return this;
    }
}
