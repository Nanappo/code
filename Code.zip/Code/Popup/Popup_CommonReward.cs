using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Popup_CommonReward : UIPopupControl
{
    public Text coinRewardText;

    protected override void Initialize()
    {
        base.Initialize();
    }

    public override void ShowPopup(int reward, bool isBattle = false)
    {
        OnCheck += ClosePopup;
        base.ShowPopup();

        mainText.text = reward.ToString();
        coinRewardText.text = reward.ToString();
    }

    public override void ClosePopup()
    {
        base.ClosePopup();
    }
}
