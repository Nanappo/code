using DLL_Datatables;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

public class StudyControl : MonoBehaviour, BottomState
{
    public GameObject basicSamplePrefab;
    public GameObject createSamplePrefab;
    public Toggle basicToggle;
    public Toggle createToggle;
    public GameObject basicScrollView;
    public GameObject creatScrollView;
    public Button TutorialButton { get; private set; }

    private List<cStudy> studyData = new List<cStudy>();
    private List<cStudy> basicStudy = new List<cStudy>();
    private List<cStudy> createStudy = new List<cStudy>();

    public void Init()
    {
        studyData = TableManager.Instance.Beast2_DataTableTable.GetStudyAttribute();

        foreach (var study in studyData)
        {
            if (study.Category == 1)
            {
                basicStudy.Add(study);
            }
            else
            {
                createStudy.Add(study);
            }
        }

        SetBasicItem();
        SetCreateItem();

        basicToggle.onValueChanged.AddListener((isOn) =>
        {
            if (isOn) SetBasicToggleItem();
        });

        createToggle.onValueChanged.AddListener((isOn) =>
        {
            if (isOn) SetCreateToggleItem();
        });
    }

    public void Open()
    {
        SetBasicToggleItem();
    }

    private void SetBasicToggleItem()
    {
        basicToggle.isOn = true;
        basicScrollView.SetActive(true);
        creatScrollView.SetActive(false);
    }

    private void SetCreateToggleItem()
    {
        basicScrollView.SetActive(false);
        creatScrollView.SetActive(true);
    }

    private void SetBasicItem()
    {
        var objName = basicSamplePrefab.name + "basic";
        var itemList = ObjectPoolManager.Instance.GetPool(objName, basicStudy.Count, "", null, basicSamplePrefab);
       
        for (int i = 0; i < itemList.PoolList.Count; i++)
        {
            var item = itemList.PoolList[i];
            item.transform.SetParent(basicSamplePrefab.transform.parent);
            var itemPos = item.transform.localPosition;
            itemPos.z = 0;
            item.transform.localPosition = itemPos;
            item.transform.localScale = Vector3.one;
            item.SetActive(true);
            item.GetComponent<StudyItem>().SetStudyData(basicStudy[i]);
            if (i == 1)
            {
                TutorialButton = item.GetComponent<StudyItem>().LvUpButton;
            }
        }

        basicSamplePrefab.SetActive(false);
    }

    private void SetCreateItem()
    {
        var objName = createSamplePrefab.name + "create";
        var itemList = ObjectPoolManager.Instance.GetPool(objName, createStudy.Count, "", null, createSamplePrefab);
        
        for (int i = 0; i < itemList.PoolList.Count; i++)
        {
            var item = itemList.PoolList[i];
            item.transform.SetParent(createSamplePrefab.transform.parent);
            var itemPos = item.transform.localPosition;
            itemPos.z = 0;
            item.transform.localPosition = itemPos;
            item.transform.localScale = Vector3.one;
            item.SetActive(true);
            item.GetComponent<StudyItem>().SetStudyData(createStudy[i]);
        }

        createSamplePrefab.SetActive(false);
    }
}
