using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class SingletonManager<T> : MonoBehaviour where T : SingletonManager<T>
{
    protected static bool IsInit = false;
    private static T instance = null;

    public static T Instance
    {
        get
        {
            if (instance == null)
            {
                instance = FindObjectOfType<T>();
                if (instance == null)
                {
                    GameObject obj = new GameObject();
                    obj.name = typeof(T).Name;
                    instance = obj.AddComponent<T>();
                }
            }
            return instance;
        }
    }

    private void Awake()
    {
        if (instance != null && instance != this)
        {
            DestroyImmediate(gameObject);
            return;
        }

        DontDestroyOnLoad(gameObject);
        InitManager();
        IsInit = true;
    }

    private void Start()
    {
        LateInitialize();
    }
    protected abstract void InitManager();

    protected abstract void LateInitialize();

    public static bool IsInitialize()
    {
        return IsInit;
    }

    protected void OnDestroy()
    {
        IsInit = false;
        StopAllCoroutines();
        instance = null;
    }
}
