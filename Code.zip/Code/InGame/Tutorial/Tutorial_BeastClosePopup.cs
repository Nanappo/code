using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Tutorial_BeastClosePopup : UITutorial
{
    private Popup_NewBeast Popup;

    public override void Ready(Tutorial master)
    {
        base.Ready(master);

        Popup = GameManager.Instance.Lobby.PopupManager.NewBeastPopup;

        Target = Popup.checkButton.GetComponentInChildren<Text>().gameObject;
        if (Target != null)
        {
            Master.Guide.transform.position = Target.transform.position;
        }

        NextScenario = eTutorial.MeatInBattleSlot;
    }

    public override IEnumerator Scenario()
    {
        if (Popup.gameObject.activeSelf == false) End();

        Master.Guide.SetActive(true);
        Master.Guide.GetComponent<Animation>().Play("UI_Tuto_Idle");

        while (!isClear)
        {
            yield return null;
            if (Popup.gameObject.activeSelf == false)
            {
                isClear = true;
            }
        }

        End();
    }

    public override void End()
    {
        base.End();
        Master.LogEvent();
        Master.NextTutorial(NextScenario);
    }
}
