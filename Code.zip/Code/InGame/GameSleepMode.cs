using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameSleepMode : MonoBehaviour
{
    public GameObject SleepImage;
    public Text TimeText;
    public Text PlayLvText;
    public Text WaveText;

    private bool isSleepMode = false;
    private float timeToSleep = 180f;
    private float idleTimer = 0f;
    private float originBrightness = 1f;
    private float ignoreInputTime = 0f;

    public void Initialize()
    {
        if (SleepImage != null) SleepImage.SetActive(false);

        Screen.sleepTimeout = SleepTimeout.NeverSleep;
        originBrightness = Screen.brightness;
    }

    public void EnterSleepMode()
    {
        isSleepMode = true;
        ignoreInputTime = Time.time + 0.2f;

        if (SleepImage != null) SleepImage.SetActive(true);
        originBrightness = Screen.brightness;
        Screen.brightness = 0.2f;

        AudioListener.pause = true;
    }

    private void ExitSleepMode()
    {
        isSleepMode = false;

        if (SleepImage != null) SleepImage.SetActive(false);
        Screen.brightness = originBrightness;

        AudioListener.pause = false;
    }

    private void Update()
    {
        if ((Input.touchCount > 0 || Input.anyKeyDown) && Time.time >= ignoreInputTime)
        {
            idleTimer = 0f;
            if (isSleepMode) ExitSleepMode();
        }
        else
        {
            if (!InGameData.IsAutoSleep) return;

            idleTimer += Time.unscaledDeltaTime;

            if (idleTimer > timeToSleep && !isSleepMode)
            {
                EnterSleepMode();
            }

            if (isSleepMode)
            {
                TimeText.text = DateTime.Now.ToString("HH:mm:ss");
                PlayLvText.text = GameManager.Instance.Lobby.LobbyUI.UIWave.stringLevel.text;
                WaveText.text = InGameData.CurrentWave.ToString();
            }
        }
    }
}
