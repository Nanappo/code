using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class Popup_TeamSetting : UIPopupControl
{
    public Dictionary<int, BeastData> InventoryBeast = new Dictionary<int, BeastData>();
    public List<Popup_UITeamSetting> TeamSlot = new List<Popup_UITeamSetting>();
    public List<GameObject> InventorySlot = new List<GameObject>();
    public List<Popup_UITeamSetting> allBeast = new List<Popup_UITeamSetting>();
    public GameObject sampleInventoryItem;
    public BeastData selectBeast;

    protected override void Initialize()
    {
        base.Initialize();
    }

    public override void ShowPopup(int slotID = 0, bool isBattle = false)
    {
        OnCheck += ClosePopup;
        SetTeamSlot();
        SetInventoryItem();

        base.ShowPopup();

        StartCoroutine(nameof(WaitInventoryOpen));
    }

    public override void ClosePopup()
    {
        foreach (var item in allBeast)
        {
            item.ClosePopup();
        }

        EquipProcess(false);
        base.ClosePopup();
    }

    public void SetTeamSlot()
    {
        for (int i = 0; i < GameManager.Instance.Lobby.LobbyMeat.BattleMeatLaneSlots.Count; i++)
        {
            var slot = GameManager.Instance.Lobby.LobbyMeat.BattleMeatLaneSlots[i];
            if (slot.SelfData.isLock)
            {
                TeamSlot[i].Initialize(true, eTeamPopupSlotType.Team, this);
                continue;
            }

            TeamSlot[i].Initialize(false, eTeamPopupSlotType.Team, this, slot.BeastBattleData, i);

            if (!allBeast.Contains(TeamSlot[i]))
            {
                allBeast.Add(TeamSlot[i]);
            }
        }
    }

    public void SetInventoryItem()
    {
        var objName = sampleInventoryItem.name + "inventory";
        var inventoryList = ObjectPoolManager.Instance.GetPool(objName, 30, "", null, sampleInventoryItem);
        var sortBeast = InGameData.BeastInGame.OrderByDescending(x => x.Key).ToDictionary(x => x.Key, x => x.Value);

        foreach (var inventory in inventoryList.PoolList)
        {
            inventory.SetActive(false);
        }

        foreach (var item in sortBeast)
        {
            var isSkip = false;

            foreach (var beast in GameManager.Instance.Battle.BattleBeast)
            {
                if (item.Key == beast.Value.SelfData.BeastID) isSkip = true;
            }
            if (isSkip) continue;

            var beastData = new BeastData().SetBeastData(item.Key);
            var prefab = inventoryList.GetObject(objName, sampleInventoryItem);
            prefab.transform.SetParent(sampleInventoryItem.transform.parent);
            var prefabPos = prefab.transform.localPosition;
            prefabPos.z = 0;
            prefab.transform.localPosition = prefabPos;
            prefab.transform.localScale = Vector3.one;
            var script = prefab.GetComponent<Popup_UITeamSetting>();
            script.Initialize(false, eTeamPopupSlotType.Inventory, this, beastData);
            InventorySlot.Add(prefab);

            if (!InventoryBeast.ContainsKey(item.Key))
            {
                InventoryBeast.Add(beastData.BeastID, beastData);
            }

            if (!allBeast.Contains(script))
            {
                allBeast.Add(script);
            }
        }

        sampleInventoryItem.SetActive(false);
    }

    public void OnlyOneBeastSelect()
    {
        foreach (var beast in allBeast)
        {
            beast.ClosePopup();
        }
    }

    public void EquipProcess(bool isActive)
    {
        foreach (var beast in TeamSlot)
        {
            beast.equipGuide.SetActive(isActive);
        }
    }

    private IEnumerator WaitInventoryOpen()
    {
        yield return new WaitForSeconds(0.5f);

        if (GameManager.Instance.Lobby.LobbyUI.Guide.activeSelf == true)
        {
            GameManager.Instance.Lobby.LobbyUI.Guide.SetActive(false);
            GameManager.Instance.Lobby.Tutorial.AgainTutorial();
        }
    }
}
