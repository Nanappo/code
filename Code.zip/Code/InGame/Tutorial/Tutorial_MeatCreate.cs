using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Tutorial_MeatCreate : UITutorial
{
    private Button CreateButton;

    public override void Ready(Tutorial master)
    {
        base.Ready(master);

        foreach (var button in GameManager.Instance.Lobby.LobbyButton.groups)
        {
            if (button.Type == eMeatButtonType.Create)
            {
                Target = button.Button.gameObject;
                CreateButton = button.Button;
            }
        }

        if (Target != null)
        {
            Master.Guide.transform.position = Target.transform.position;
        }

        Master.LockScreen[0].SetActive(true);
        NextScenario = eTutorial.MeatMerge;
    }

    public override IEnumerator Scenario()
    {
        Master.Guide.SetActive(true);
        Master.Guide.GetComponent<Animation>().Play("UI_Tuto_Idle");

        while (!isClear)
        {
            yield return null;
            if (GameManager.Instance.Lobby.LobbyMeat.MeatLaneSlots.Count == 2)
            {
                CreateButton.enabled = false;
                isClear = true;
            }
        }

        End();
    }

    public override void End()
    {
        base.End();
        Master.LockScreen[0].SetActive(false);
        Master.LogEvent();
        Master.NextTutorial(NextScenario);
    }
}
