using DLL_Datatables;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.UI;

public class BattleManager : MonoBehaviour
{
    public Dictionary<int, Beast> BattleBeast = new Dictionary<int, Beast>();
    public Dictionary<int, GameObject> BattleBeastPrefabs = new Dictionary<int, GameObject>();
    public Dictionary<GameObject, bool> EnemyList = new Dictionary<GameObject, bool>();
    public List<Prob> ProbList = new List<Prob>();
    public WaveSystem waveSystem;
    public Transform BeastParent;
    public Camera BattleCamera;
    public Canvas BattleCanvas;
    public BattleUIController BattleUI;
    public CameraFollow CameraFollow;
    public float[] BeastYPos => beastYPos;

    private float[] beastYPos = { 0.1f, -0.1f, 0.4f, -0.4f, 0.7f };

    public void Initialize()
    {
        waveSystem = GetComponent<WaveSystem>();
        waveSystem.StartWave(1.5f);

        var beastSlot = InGameData.BeastInBattle.ToArray();

        if (beastSlot.Length == 0) return;

        foreach (var beast in beastSlot)
        {
            var beastprefab = EnterTheBattle(beast.Value, beast.Key);
            if (beast.Value.HP <= 0)
            {
                beastprefab.gameObject.SetActive(false);
            }
        }

        var dieBeast = BattleBeastCheck();
        if (dieBeast == BattleBeast.Count)
        {
            GameManager.Instance.Battle.waveSystem.FailWave(1f, 4f, () =>
            {
                //ȯ���� �� ���������� ���� Ȯ�� �ʿ�.
                var coin = GameManager.Instance.Lobby.PopupManager.RebirthPopup.GetCoinToRebirth();
                GameManager.Instance.InGameCoin.Value += coin;
                GameManager.Instance.Lobby.PopupManager.RebirthPopup.BeastRebirth();
            });
        }

        CameraFollow = BattleCamera.GetComponent<CameraFollow>();
        CameraFollow.Initialize();
        BattleUI.Initialize();
    }

    public GameObject EnterTheBattle(BeastData beast, int slotID, bool isSetting = false)
    {
        var beastScript = CreateBeast(beast.BeastID, slotID);
        beast = SetBattleBeastSpec(beast, slotID);
        beastScript.Initialize(beast, slotID);
        if (isSetting)
        {
            float hp = beastScript.SelfData.MaxHP * 0.1f;
            beastScript.SelfData.HP = hp;
        }
        var beastAttack = beastScript.GetComponent<BeastState_Attack>();
        var guageBar = MakeHPBar(beastScript.Pivot);
        beastAttack.GuageBar = guageBar.GetComponent<HPGuageBar>();
        beastAttack.GuageBar.SetGuage(beast, beastScript.SelfData.HP);
        var sorting = beastScript.gameObject.AddComponent<SortingGroup>();
        sorting.sortingOrder = SortingOrderBeast(beastScript.startPos.y);
        //sorting.sortingOrder = (BeastYPos.Length - slotID) + 15;

        BattleBeast.Add(slotID, beastScript);
        return beastScript.gameObject;
    }

    private Beast CreateBeast(int beastID, int slotID)
    {
        var posX = GameManager.Instance.GameScreen.BattleScreenWidthLeftX;
        var pos = new Vector3(posX - 1f, BeastYPos[slotID], 0f);
        var beastPrefab = InstantiateBeast(beastID, pos, BeastParent);
        var beastScript = beastPrefab.AddComponent<Beast>();
        BattleBeastPrefabs.Add(slotID, beastPrefab);

        return beastScript;
    }

    public GameObject InstantiateBeast(int prefabID, Vector3 localPos, Transform parent = null)
    {
        var path = string.Format("Prefabs/Beast/{0}", prefabID);
        GameObject obj = Resources.Load(path) as GameObject;
        var instantiateObj = Instantiate(obj);
        instantiateObj.transform.SetParent(parent);
        instantiateObj.transform.localPosition = localPos;
        instantiateObj.transform.localScale = new Vector3(4, 4, 4);

        return instantiateObj;
    }

    private int SortingOrderBeast(float posY)
    {
        var minY = -0.4f;
        var maxY = 0.7f;

        var t = Mathf.InverseLerp(maxY, minY, posY);
        var result = Mathf.RoundToInt(Mathf.Lerp(16, 20, t));
        return result;
    }

    private GameObject MakeHPBar(GameObject beast)
    {
        GameObject obj = new GameObject();
        obj.name = "GuageContactor";
        obj.transform.SetParent(beast.transform);
        obj.transform.localPosition = new Vector3(0, -0.04f, 0);
        obj.transform.localScale = new Vector3(0.01f, 0.01f, 0);

        var UI = Instantiate(BattleUI.HPGuageBarSample);
        UI.transform.SetParent(obj.transform);
        UI.transform.localPosition = Vector2.zero;
        UI.transform.localScale = Vector2.one;

        return UI;
    }

    public void BeastFindToTarget()
    {
        foreach (var beast in BattleBeast)
        {
            beast.Value.Target = beast.Value.BeastAttack.FindTarget();

            if (beast.Value.Target == null)
            {
                Debug.Log("Ÿ�پ���");
            }
            //beast.Value.BeastAttack.OnTargetChange();
        }
    }

    public int BattleBeastCheck()
    {
        var beastDic = GameManager.Instance.Battle.BattleBeast;

        if (beastDic.Count < 1) return 0;

        int dieCount = 0;
        foreach (var beast in beastDic)
        {
            if (beast.Value.SelfData.HP <= 0)
            {
                dieCount++;
                GameManager.Instance.Lobby.LobbyMeat.BattleMeatLaneSlots[beast.Value.mySlotID].WarningIcon.SetActive(true);
            }
        }

        return dieCount;
    }

    public BeastData SetBattleBeastSpec(BeastData beast, int slotID)
    {
        beast.Atk = SetBattleBeastAtk(beast, slotID);
        beast.CriDamage = SetBattleBeastCriDamage(beast);
        beast.CriRate = SetBattleBeastCriRate(beast);
        beast.MaxHP = SetBattleBeastMaxHP(beast);
        beast.SkillCoolTime = SetBattleBeastSkillCoolTime(beast);
        beast.AtkSpeed = SetBattleBeastAtkSpeed(beast);
        return beast;
    }

    public int SetBattleBeastAtk(BeastData beast, int slotID, int meatLevel = 0)
    {
        var level = InGameData.BeastInGame[beast.BeastID].beastLevel;
        var StudyID = (int)eStudyID.Atk;
        var spec = TableManager.Instance.Beast2_DataTableTable.GetStudyAttribute(StudyID).SpecValue;
        var inMeatLevel = slotID != -1 ? InGameData.MeatInBattle[slotID].Level : meatLevel;
        //var atk = (level * (beast.OriginAtk + GameManager.Instance.InGameStudy[StudyID].Value * spec) * Mathf.Pow((float)(1 + 0.01 * beast.Class), inMeatLevel));
        //MVP��
        var atk = (level * (beast.OriginAtk + GameManager.Instance.InGameStudy[StudyID].Value * spec) * Mathf.Pow((float)(1 + 0.01 * beast.Class), inMeatLevel)) + inMeatLevel;
        return (int)atk;
    }

    public int SetBattleBeastCriDamage(BeastData beast)
    {
        var StudyID = (int)eStudyID.CriDamage;
        var StudySpec = TableManager.Instance.Beast2_DataTableTable.GetStudyAttribute(StudyID).SpecValue;
        var abilitySpec = TableManager.Instance.Beast2_DataTableTable.GetAbilitiyAttribute(beast.Abilitiy4).SpecValue;
        var abilityLevle = GetAbilityLevel(beast.BeastID, beast.Abilitiy4);
        var criDamage = beast.Atk * (1 + ((GameManager.Instance.InGameStudy[StudyID].Value * StudySpec) + (abilitySpec * abilityLevle)) / 100);
        return (int)criDamage;
    }

    public int SetBattleBeastCriRate(BeastData beast)
    {
        var StudyID = (int)eStudyID.CriRate;
        var StudySpec = TableManager.Instance.Beast2_DataTableTable.GetStudyAttribute(StudyID).SpecValue;
        var abilitySpec = TableManager.Instance.Beast2_DataTableTable.GetAbilitiyAttribute(beast.Abilitiy3).SpecValue;
        var abilityLevle = GetAbilityLevel(beast.BeastID, beast.Abilitiy3);
        var criRate = ((GameManager.Instance.InGameStudy[StudyID].Value * StudySpec) + (abilitySpec * abilityLevle));
        return (int)criRate;
    }

    public int SetBattleBeastMaxHP(BeastData beast)
    {
        var tableHP = TableManager.Instance.Beast2_DataTableTable.GetBeastAttribute(beast.BeastID).HP;
        var level = InGameData.BeastInGame[beast.BeastID].beastLevel;
        var StudyID = (int)eStudyID.HP;
        var StudySpec = TableManager.Instance.Beast2_DataTableTable.GetStudyAttribute(StudyID).SpecValue;
        var abilitySpec = TableManager.Instance.Beast2_DataTableTable.GetAbilitiyAttribute(beast.Abilitiy1).SpecValue;
        var abilityLevle = GetAbilityLevel(beast.BeastID, beast.Abilitiy1);
        var maxHP = beast.Class * level * (tableHP + (GameManager.Instance.InGameStudy[StudyID].Value * StudySpec) + (abilitySpec * abilityLevle));
        return (int)maxHP;
    }

    public float SetBattleBeastSkillCoolTime(BeastData beast)
    {
        var spec = TableManager.Instance.Beast2_DataTableTable.GetAbilitiyAttribute(beast.Abilitiy6).SpecValue;
        var level = GetAbilityLevel(beast.BeastID, beast.Abilitiy6);
        var currentCoolTime = TableManager.Instance.Beast2_DataTableTable.GetSkillAttribute(beast.Active).CoolTime;
        var coolTime = currentCoolTime - currentCoolTime * ((float)spec * level / 100);
        return (float)coolTime;
    }

    public float SetBattleBeastAtkSpeed(BeastData beast)
    {
        var spec = TableManager.Instance.Beast2_DataTableTable.GetAbilitiyAttribute(beast.Abilitiy2).SpecValue;
        var level = GetAbilityLevel(beast.BeastID, beast.Abilitiy2);
        var speed = beast.AtkSpeed - ((float)spec * level / 100);
        return speed;
    }

    public int GetAbilityLevel(int beastID, int abilityID)
    {
        var abilityList = InGameData.BeastAbility[beastID];
        foreach (var ability in abilityList)
        {
            if (ability.abilityID == abilityID)
            {
                return ability.abilityLevel;
            }
        }

        return 0;
    }

    public Color SetBeastIconBackgroundColor(int beastClass)
    {
        Color color = new Color();
        switch (beastClass)
        {
            case 1:
                color = new Color32(102, 161, 0, 255);
                break;
            case 2:
                color = new Color32(0, 162, 200, 255);
                break;
            case 3:
                color = new Color32(142, 69, 255, 255);
                break;
            case 4:
                color = new Color32(255, 144, 42, 255);
                break;
            case 5:
                color = new Color32(255, 76, 42, 255);
                break;
        }

        return color;
    }

    //Y�� ���� Sorting ������ ������µ� ������ �Ⱦ�.
    private void SetBeastSorting()
    {
        var sortorder = 20;
        var beastList = BattleBeast.ToList();
        beastList = beastList.OrderBy(obj => obj.Value.transform.position.y).ToList();
        foreach (var beast in beastList)
        {
            var sorting = beast.Value.gameObject.GetComponent<SortingGroup>();
            sorting.sortingOrder = sortorder;
            sortorder -= 1;
        }
    }
}
