using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BeastState_Move : BeastState
{
    private Beast beast;
    private float speedControl;

    public BeastState_Move(Beast _beast)
    {
        beast = _beast;
    }

    public void Enter()
    {
        beast.animator.SetBool("IsMove", true);
        SetFaceDir(Vector3.right);

        //beast.SetEnableAutoFaceMotion(true, true);
        speedControl = Random.Range(1.0f, 1.2f);
        beast.isDoing = true;
        //GameManager.Instance.Battle.CameraFollow.isCameraZoom = false;
    }

    public void Doing()
    {
        if (beast.Target == null)
        {
            Move();
            return;
        }
        if (IsInRange(beast.transform.position, beast.Target.transform.position, beast.SkillRadius)
            && beast.isSkill && beast.BeastSkill.myStyle == 1)
        {
            beast.animator.SetBool("IsMove", false);
            beast.SetCurrentStage(eBeastState.Battle_Skill);

            if (GameManager.Instance.Battle.CameraFollow.target.gameObject == beast.gameObject
                && beast.SelfData.Type == 1)
            {
                GameManager.Instance.Battle.CameraFollow.CameraMove(true);
            }
            return;
        }
        else if (beast.isSkill && beast.BeastSkill.myStyle != 1)
        {
            beast.animator.SetBool("IsMove", false);
            beast.SetCurrentStage(eBeastState.Battle_Skill);
            return;
        }

        if (IsInRange(beast.transform.position, beast.Target.transform.position, beast.BasicRadius))
        {
            beast.animator.SetBool("IsMove", false);
            beast.SetCurrentStage(eBeastState.Battle_Attack);

            if (GameManager.Instance.Battle.CameraFollow.target.gameObject == beast.gameObject
                && beast.SelfData.Type == 1)
            {
                GameManager.Instance.Battle.CameraFollow.CameraMove(true);
            }
        }
        else Move();
    }

    public void Exit()
    {
        beast.isDoing = false;
    }

    private void SetFaceDir(Vector3 _faceDir)
    {
        beast.animator.SetFloat("HorizonVector", _faceDir.x);
    }

    private void Move()
    {
        var beastPos = beast.transform.position;

        var moveTic = Time.deltaTime * beast.SelfData.MoveSpeed * speedControl;
        beastPos.x += (Vector3.right.x * moveTic);

        beast.transform.position = beastPos;
    }

    private bool IsInRange(Vector2 selfPos, Vector2 targetPos, float xRange)
    {
        float xDiff = Mathf.Abs(selfPos.x - targetPos.x);
        return xDiff <= xRange;
    }
}
