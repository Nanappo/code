using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Popup_Rebirth : UIPopupControl
{
    public GameObject Penalty;
    public Button stopButton;
    public Text waveText;
    public Text coinUpText;
    public Text coinBoostText;
    public Text penaltyText;
    public Text coinCountText;
    public Text timerText;
    //public Toggle rewardToggle;

    private bool isTimer = false;
    private float timer = 5.0f;
    private double coinCost = 0;

    protected override void Initialize()
    {
        base.Initialize();

        stopButton.onClick.AddListener(() =>
        {
            BeastRebirthStop();
        });
    }

    public override void ShowPopup(int data = 0, bool isCheck = false)
    {
        OnCheck += BeastRebirth;
        isTimer = true;
        coinCost = GetCoinToRebirth();
        SetPopupUI(coinCost);
        base.ShowPopup();
    }

    private void SetPopupUI(double cost)
    {
        if (GameManager.Instance.Lobby.LobbyUI.isRebirth) stopButton.gameObject.SetActive(true);
        else stopButton.gameObject.SetActive(false);

        waveText.text = InGameData.CurrentWave.ToString();
        coinBoostText.text = (InGameData.CoinMagnification * 100).ToString();
        coinCountText.text = GameManager.Instance.PropertyNotation.FormatGameNumber(cost);

        if (InGameData.CurrentWave < 21)
        {
            var areaData = GameManager.Instance.Map.mapChanger.AreaData;
            Penalty.SetActive(true);
            penaltyText.text = areaData.PenaltyValue.ToString();
        }
    }

    public override void ClosePopup()
    {
        Penalty.SetActive(false);
        base.ClosePopup();
    }

    //���� ȯ�������� ��Ȱ
    public void BeastRebirth()
    {
        if (GameManager.Instance.Lobby.LobbyUI.isRebirth)
        {
            GameManager.Instance.Battle.waveSystem.FailWave(1f, 4f, () => { GameManager.Instance.Lobby.LobbyUI.isRebirth = false; });
        }

        GameManager.Instance.Battle.BattleUI.FadeInOut.FadeIn(0.3f, () =>
        {
            foreach (var beast in GameManager.Instance.Battle.BattleBeast)
            {
                beast.Value.gameObject.SetActive(true);
                beast.Value.BeastAttack.OnActive();
                beast.Value.BeastSkill.OnActive();
                GameManager.Instance.Lobby.LobbyMeat.BattleMeatLaneSlots[beast.Value.mySlotID].WarningIcon.SetActive(false);
            }

            GameManager.Instance.Battle.BattleUI.isResurrection = true;
            GameManager.Instance.InGameCoin.Value += coinCost;
            ClosePopup();
        });
    }

    private void BeastRebirthStop()
    {
        isTimer = false;
        timer = 5.0f;
        GameManager.Instance.Lobby.LobbyUI.isRebirth = false;
        ClosePopup();
    }

    public double GetCoinToRebirth()
    {
        var areaData = GameManager.Instance.Map.mapChanger.AreaData;
        var currentWave = InGameData.CurrentWave;

        var coin = Mathf.Pow(areaData.RebirthValue, areaData.Order) * Mathf.Pow(areaData.PlayLv, 2) *
            (currentWave - 1) * 1.015 * currentWave * InGameData.CoinMagnification;
        if (currentWave <= areaData.PenaltyWave)
        {
            var penaltyCoin = coin * areaData.PenaltyValue / 100;
            return penaltyCoin;
        }

        return coin;
    }

    private void Update()
    {
        if (isTimer)
        {
            timerText.text = timer.ToString("F1");
            timer -= Time.deltaTime;

            if (timer <= 0)
            {
                checkButton.onClick.Invoke();
                isTimer = false;
                timer = 5.0f;
            }
        }
    }
}
