using DLL_Datatables;
using System.Collections;
using System.Collections.Frozen;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

public class MapChange : MonoBehaviour
{
    public bool isData = false;

    [System.Serializable]
    public class MapSetting
    {
        public Color AmbientColor;
        public Color AmbientFXColor;
        public GameObject Sky;
        public GameObject Flare;
        public GameObject Weather;
        public GameObject Cloud;
    }

    [System.Serializable]
    public class EnemySpawnSetting
    {
        public eSpawnSection Section;
        public eEnemySpawnType EnemyType;
        public GameObject Parent;
        public int NumberOfProb;
        public List<Vector3> SpawnPos;
    }

    [System.Serializable]
    public class ProbSpawnSetting
    {
        public GameObject Parent;
        public int NumberOfProb;
        public List<Vector3> SpawnPos;
    }

    public Material AmbientMaterial;
    public Material AmbientFXMaterial;
    public SpriteRenderer MapBack;
    public SpriteRenderer MapGround;
    public SpriteRenderer MapFront;
    public List<GameObject> ProbPrefab;
    public List<MapSetting> EnvironmentSettings = new List<MapSetting>();
    public List<EnemySpawnSetting> EnemySpawnList = new List<EnemySpawnSetting>();
    public List<ProbSpawnSetting> ProbSpawnList = new List<ProbSpawnSetting>();

    public cArea AreaData { get; private set; }

    private int randomValue = -1;
    private string currentProb;

    public void Initialize()
    {
        SetAreaID();
        SetChangeMap();
        SetChangeEnvironment();
        SetEnemySpawnPrefabs();
        //CreateProbPrefabs();
        SetProbSpawnPrefabs();
    }

    private int RandomEnvironment()
    {
        var random = Random.Range(0, EnvironmentSettings.Count);
        return random;
    }

    public void SetChangeEnvironment()
    {
        if (randomValue != -1)
        {
            EnvironmentSettings[randomValue].Sky.SetActive(false);
            EnvironmentSettings[randomValue].Flare.SetActive(false);
            EnvironmentSettings[randomValue].Weather.SetActive(false);
            EnvironmentSettings[randomValue].Cloud.SetActive(false);
        }

        randomValue = RandomEnvironment();
        AmbientMaterial.SetColor("_Color", EnvironmentSettings[randomValue].AmbientColor);
        AmbientFXMaterial.SetColor("_Color", EnvironmentSettings[randomValue].AmbientFXColor);
        EnvironmentSettings[randomValue].Sky.SetActive(true);
        EnvironmentSettings[randomValue].Flare.SetActive(true);
        EnvironmentSettings[randomValue].Weather.SetActive(true);
        EnvironmentSettings[randomValue].Cloud.SetActive(true);
    }

    public void SetChangeMap()
    {
        var lobbyUI = GameManager.Instance.Lobby.LobbyUI;
        MapBack.sprite = lobbyUI.GetSprite(lobbyUI.MapIcon, AreaData.MapBack);
        MapGround.sprite = lobbyUI.GetSprite(lobbyUI.MapIcon, AreaData.MapGround);
        MapFront.sprite = lobbyUI.GetSprite(lobbyUI.MapIcon, AreaData.MapFront);
    }

    //������ �ٲ� �� �ٽ� ȣ���ؼ� �����ʿ�.
    public void SetAreaID()
    {
        var areaID = 1100000 + 10 * InGameData.CurrentArea;
        AreaData = TableManager.Instance.Beast2_DataTableTable.GetAreaAttribute(areaID);
    }

    private int FindDeployIndex()
    {
        var deployID = 0;
        var deployIndex = InGameData.CurrentWave % 5;

        switch (deployIndex)
        {
            case 0:
                deployID = AreaData.Deploy5;
                break;
            case 1:
                deployID = AreaData.Deploy1;
                break;
            case 2:
                deployID = AreaData.Deploy2;
                break;
            case 3:
                deployID = AreaData.Deploy3;
                break;
            case 4:
                deployID = AreaData.Deploy4;
                break;
        }

        return deployID;
    }

    private void CreateProbPrefabs()
    {
        for (int i = 0; i < ProbPrefab.Count; i++)
        {
            var objName = ProbPrefab[i].name;
            ObjectPoolManager.Instance.AddObjectPool(objName, 10, "", null, ProbPrefab[i]);
        }
    }

    public void SetProbSpawnPrefabs()
    {
        if (ProbSpawnList.Count < 1) return;

        GameManager.Instance.Battle.ProbList.Clear();

        var prefabName = currentProb;
        var objpath = string.Format("Prefabs/Prob/{0}", prefabName);

        foreach (var prob in ProbSpawnList)
        {
            var posList = SetRandomSpawnPos(prob.SpawnPos);
            var objList = ObjectPoolManager.Instance.GetPool(prefabName, 30, objpath, prob.Parent);

            for (int i = 0; i < prob.NumberOfProb; i++)
            {
                var obj = objList.GetObject(objpath);
                obj.transform.SetParent(prob.Parent.transform);
                obj.transform.localPosition = posList[i];
                obj.transform.localScale = new Vector3(4, 4, 4);
                var objscript = obj.GetComponent<Prob>();
                objscript.SetOriginParent();
                GameManager.Instance.Battle.ProbList.Add(objscript);
            }
        }
    }

    public void SetEnemySpawnPrefabs()
    {
        if (EnemySpawnList.Count < 1) return;

        GameManager.Instance.Battle.EnemyList.Clear();
        var deployID = FindDeployIndex();

        cDeploy deploy = TableManager.Instance.Beast2_DataTableTable.GetDeployAttribute(deployID);
        currentProb = deploy.Prob;

        foreach (var prefab in EnemySpawnList)
        {
            var objname = "";
            var number = prefab.NumberOfProb;

            switch (prefab.EnemyType)
            {
                case eEnemySpawnType.Enemy_Shot:
                    objname = deploy.Enemy_Shot;
                    if (isData) number = deploy.Shot_Number;
                    break;
                case eEnemySpawnType.Enemy_Missile:
                    objname = deploy.Enemy_Missile;
                    if (isData) number = deploy.Missile_Number;
                    break;
                case eEnemySpawnType.Enemy_Fly:
                    objname = deploy.Enemy_Fly;
                    if (isData) number = deploy.Fly_Number;
                    break;
                case eEnemySpawnType.Enemy_Barrier:
                    objname = deploy.Enemy_Barrier;
                    if (isData) number = deploy.Barrier_Number;
                    break;
            }

            var objpath = string.Format("Prefabs/Enemy/{0}", objname);
            var objList = ObjectPoolManager.Instance.GetPool(objname, 10, objpath, prefab.Parent);

            var posList = SetRandomSpawnPos(prefab.SpawnPos);

            for (int i = 0; i < number; i++)
            {
                var obj = objList.GetObject(objpath);
                obj.transform.SetParent(prefab.Parent.transform);
                obj.transform.localPosition = posList[i];
                obj.transform.localScale = new Vector3(4, 4, 4);
                var objScript = obj.GetComponent<Enemy>();
                objScript.Initialize(prefab.Section);
                objScript.Parent = prefab.Parent.transform;

                if (GameManager.Instance.Battle.EnemyList.ContainsKey(obj))
                {
                    GameManager.Instance.Battle.EnemyList[obj] = true;
                }
                else GameManager.Instance.Battle.EnemyList.Add(obj, true);
            }
        }
    }

    private List<Vector3> SetRandomSpawnPos(List<Vector3> pos)
    {
        for (int i = 0; i < pos.Count; i++)
        {
            int randIndex = Random.Range(i, pos.Count);
            (pos[i], pos[randIndex]) = (pos[randIndex], pos[i]);
        }

        return pos;
    }

    private List<GameObject> SetRandomPrefabs(List<GameObject> obj)
    {
        for (int i = 0; i < obj.Count; i++)
        {
            int randIndex = Random.Range(i, obj.Count);
            (obj[i], obj[randIndex]) = (obj[randIndex], obj[i]);
        }

        return obj;
    }
}
