using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AreaSystem : MonoBehaviour
{

    public void ChangeArea()
    {
        InGameData.CurrentArea++;
        GameManager.Instance.Map.mapChanger.SetAreaID();
        GameManager.Instance.Map.mapChanger.SetChangeMap();

        StartCoroutine(CheckReviewEvent(InGameData.CurrentArea));
    }

    private IEnumerator CheckReviewEvent(int area)
    {
        if (area != 2 && InGameData.IsReview) yield break;

        yield return new WaitForSeconds(1f);

        GameManager.Instance.Lobby.LobbyUI.ReviewButton.gameObject.SetActive(true);
        GameManager.Instance.Lobby.PopupManager.ReviewPopup.ShowPopup();
    }
}
