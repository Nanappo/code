using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;

public class LobbyManager : MonoBehaviour
{
    public readonly LobbyMeat LobbyMeat = new LobbyMeat();
    public Dictionary<int, Sprite> MeatSpriteDic = new Dictionary<int, Sprite>();
    public Camera LobbyCamera;
    public RectTransform BattleImage;
    public Canvas LobbyCanvas;
    public GameObject Meatslot;
    public GameObject BattleMeatslot;
    public Button TeamButton;
    public UILobbySlotButton LobbyButton;
    public PopupManager PopupManager;
    public LobbyUIController LobbyUI;
    public FadeInOut LobbyFade;
    public Tutorial Tutorial;

    public void Initialize()
    {
        Sprite[] meatSprite = new Sprite[LobbyUI.MeatIcon.spriteCount];
        LobbyUI.MeatIcon.GetSprites(meatSprite);
        meatSprite = meatSprite.OrderBy(s => LobbyUI.GetSpriteNumber(s.name)).ToArray();

        for (int i = 0; i < meatSprite.Length; i++)
        {
            MeatSpriteDic.Add(i + 1, meatSprite[i]);
        }

        PopupManager.Initialize();
        LobbyUI.Initialize();
        LobbyMeat.Initialize();
        LobbyButton.Initialize();

        TeamButton.onClick.AddListener(() =>
        {
            PopupManager.TeamSettingPopup.ShowPopup();
        });
    }

    //���� �߰� �ɶ� ����ȿ�� 
    public int SetMeatCreateLevel()
    {
        var coinSpec = TableManager.Instance.Beast2_DataTableTable.GetStudyAttribute((int)eStudyID.CoinMeatLevel).SpecValue;
        var diaSpec = TableManager.Instance.Beast2_DataTableTable.GetStudyAttribute((int)eStudyID.DiaMeatLevel).SpecValue;

        float beastSpec = 0;
        //foreach (var beast in GameManager.Instance.Battle.BattleBeast)
        //{
        //    var ownedID = beast.Value.SelfData.Owned;
        //    var skillSpec = TableManager.Instance.Beast2_DataTableTable.GetSkillAttribute(ownedID).SpecValue;
        //    beastSpec += skillSpec;
        //}

        foreach (var beast in InGameData.BeastInGame)
        {
            var ownedID = TableManager.Instance.Beast2_DataTableTable.GetBeastAttribute(beast.Key).Owned;
            var skillSpec = TableManager.Instance.Beast2_DataTableTable.GetSkillAttribute(ownedID).SpecValue;
            for (int i = 0; i < beast.Value.beastCount; i++)
            {
                beastSpec += skillSpec;
            }
        }
        var level = beastSpec + (coinSpec * GameManager.Instance.InGameStudy[(int)eStudyID.CoinMeatLevel].Value) +
            (diaSpec * GameManager.Instance.InGameStudy[(int)eStudyID.DiaMeatLevel].Value) + 1;

        return (int)level;
    }

    public void UpgradeAllMeat()
    {
        var meatLevel = InGameData.CreateMeatLevel;

        //Team Slot
        foreach (var meat in LobbyMeat.BattleMeatLaneSlots)
        {
            if (meat.Value.SelfData.isMeat && meat.Value.SelfData.Level < meatLevel)
            {
                InGameData.MeatInBattle[meat.Value.SelfData.SlotID].SetMeatLevel(meatLevel);
                meat.Value.SetBattleSlotData(meat.Value.SelfData.SlotID);
            }
        }

        //Lobby Slot
        foreach (var meat in LobbyMeat.MeatLaneSlots)
        {
            if (meat.Value.SelfData.isMeat && meat.Value.SelfData.Level < meatLevel)
            {
                meat.Value.SelfData.Level = meatLevel;
                var script = meat.Value.GetComponent<UILobbyMeatSlot>();
                script.SaveItemData();
                script.CreateIcon();
            }
        }
    }
}
