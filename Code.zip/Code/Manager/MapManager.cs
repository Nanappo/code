using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MapManager : MonoBehaviour
{
    public GameObject FollowObj;
    public GameObject MapBack;
    public MapChange mapChanger;

    private Transform targetCamera;
    private Vector3 lastCameraPos;
    private Vector3 offset;
    private float moveRatio = 0.8f;

    public void Initialize()
    {
        mapChanger = GetComponent<MapChange>();
        mapChanger.Initialize();

        targetCamera = GameManager.Instance.Battle.BattleCamera.transform;
        //SetMapPosition();
        offset = FollowObj.transform.position - targetCamera.position;
        lastCameraPos = targetCamera.position;
    }

    private void SetMapPosition()
    {
        var posX = GameManager.Instance.GameScreen.BattleScreenWidthLeftX;
        var pos = new Vector3(posX - 2f, -0.3f, 0f);
        transform.localPosition = pos;
    }

    private void ObjToCameraFollow()
    {
        Vector3 targetPos = targetCamera.position + offset;
        targetPos.y = FollowObj.transform.position.y;
        targetPos.z = FollowObj.transform.position.z;
        FollowObj.transform.position = targetPos;
    }

    private void LateUpdate()
    {
        if (FollowObj != null && GameManager.Instance.isLoading)
        {
            if (targetCamera.position.x > 0)
            {
                ObjToCameraFollow();

                var delta = targetCamera.position - lastCameraPos;
                if (Mathf.Abs(delta.x) > 0.001f)
                {
                    MapBack.transform.position += new Vector3(delta.x * moveRatio, 0, 0);
                }

                lastCameraPos = targetCamera.position;
            }
        }
    }
}
