using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Projectile : MonoBehaviour
{
    protected float damage;

    public virtual void SetDamage(float _damage, bool _isCritical = false)
    {
        damage = _damage;
    }
}
