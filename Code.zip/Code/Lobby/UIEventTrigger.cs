using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

//[RequireComponent(typeof(Button))]
public class UIEventTrigger : MonoBehaviour
{
    public bool IsOverSlot { get; protected set; }
    public bool IsPressed { get; protected set; }
    public Vector4 DragLimit { get; set; }

    void Start()
    {
        EventTrigger trigger = GetComponent<EventTrigger>();

        EventTrigger.Entry entry = new EventTrigger.Entry();
        entry.eventID = EventTriggerType.PointerDown;
        entry.callback.AddListener((data) => { OnPointerDownDelegate((PointerEventData)data); });
        trigger.triggers.Add(entry);

        EventTrigger.Entry entryEnter = new EventTrigger.Entry();
        entryEnter.eventID = EventTriggerType.PointerEnter;
        entryEnter.callback.AddListener((data) => { OnPointerEnterDelegate((PointerEventData)data); });
        trigger.triggers.Add(entryEnter);

        EventTrigger.Entry entryExit = new EventTrigger.Entry();
        entryExit.eventID = EventTriggerType.PointerExit;
        entryExit.callback.AddListener((data) => { OnPointerExitDelegate((PointerEventData)data); });
        trigger.triggers.Add(entryExit);

        EventTrigger.Entry entryUp = new EventTrigger.Entry();
        entryUp.eventID = EventTriggerType.PointerUp;
        entryUp.callback.AddListener((data) => { OnPointerUpDelegate((PointerEventData)data); });
        trigger.triggers.Add(entryUp);
    }

    public void InitializeDrag()
    {
        EventTrigger trigger = GetComponent<EventTrigger>();

        EventTrigger.Entry entryBeginDrag = new EventTrigger.Entry();
        entryBeginDrag.eventID = EventTriggerType.BeginDrag;
        entryBeginDrag.callback.AddListener((data) => { OnPointerBeginDragDelegate((PointerEventData)data); });
        trigger.triggers.Add(entryBeginDrag);

        EventTrigger.Entry entryDrag = new EventTrigger.Entry();
        entryDrag.eventID = EventTriggerType.Drag;
        entryDrag.callback.AddListener((data) => { OnPointerDragDelegate((PointerEventData)data); });
        trigger.triggers.Add(entryDrag);

        EventTrigger.Entry entryEndDrag = new EventTrigger.Entry();
        entryEndDrag.eventID = EventTriggerType.EndDrag;
        entryEndDrag.callback.AddListener((data) => { OnPointerEndDragDelegate((PointerEventData)data); });
        trigger.triggers.Add(entryEndDrag);
    }

    public virtual void OnClickBtn()
    {

    }

    public virtual void OnPointerDownDelegate(PointerEventData data)
    {
        // ��ư ������ Ŭ���� �ߴ� = ������ ������.
        // ������ ������ ����.
    }

    public virtual void OnPointerEnterDelegate(PointerEventData data)
    {
        // 
    }

    public virtual void OnPointerExitDelegate(PointerEventData data)
    {
    }

    public virtual void OnPointerUpDelegate(PointerEventData data)
    {
    }

    public virtual void OnPointerBeginDragDelegate(PointerEventData data)
    {
    }

    public virtual void OnPointerDragDelegate(PointerEventData data)
    {
    }

    public virtual void OnPointerEndDragDelegate(PointerEventData data)
    {
    }
}
