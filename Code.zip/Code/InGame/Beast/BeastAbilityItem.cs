using DLL_Datatables;
using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;

public class BeastAbilityItem : AbilitySpecUp
{
    public Image abilityIcon;
    public Text abilityIconLevel;
    public Text abilityName;
    public Text abilityDescription;
    public Button LevelUp;
    public Text LevelUpSpec;
    public Text LevelUpCost;
    public GameObject LevelMax;

    public void SetAbilityUI(AbilityInfo info, BeastData beastdata, int index, Beast beast)
    {
        LevelMax.SetActive(false);
        LevelUp.enabled = true;
        var data = TableManager.Instance.Beast2_DataTableTable.GetAbilitiyAttribute(info.abilityID);
        object[] spec = new object[] { data.MaxLv, data.SpecValue * info.abilityLevel };

        abilityIcon.sprite = GameManager.Instance.Lobby.LobbyUI.GetSprite(GameManager.Instance.Lobby.LobbyUI.BilinearIcon, data.AbilitiyID.ToString());
        abilityIconLevel.text = string.Format("Lv.{0}", InGameData.BeastAbility[beastdata.BeastID][index].abilityLevel.ToString());
        abilityName.text = CleLocalization.Format("Localization", data.AbilitiyID.ToString(), spec[0]);
        abilityDescription.text = CleLocalization.Format("Localization", data.Description.ToString(), spec[1]);

        LevelUpSpec.text = data.SpecValue.ToString();
        LevelUpCost.text = GameManager.Instance.PropertyNotation.FormatGameNumber(GetItemValue(data, info));

        SetLevelUpListener(data, beastdata, index, info, beast);

        if (InGameData.BeastAbility[beastdata.BeastID][index].abilityLevel >= data.MaxLv)
        {
            LevelMax.SetActive(true);
            LevelUp.enabled = false;
        }
    }

    private void OnLevelUp(cAbilitiy data, BeastData beastdata, int index, AbilityInfo info, Beast beast)
    {
        var cost = GetItemValue(data, info);
        if (!UseItemCheck(cost))
        {
            GameManager.Instance.Lobby.PopupManager.SplashMessagePopup.ShowPopup((int)eSplashMessageType.Proterty);
            return;
        }

        InGameData.BeastAbility[beastdata.BeastID][index].abilityLevel += 1;
        //�����Կ� ������ ������ �����
        //�κ��丮 ������ ���� TextUI�� ����.
        if (beast != null) BeastSpecUp(data.AbilitiyID, beast);
        else
        {
            beastdata.MaxHP = GameManager.Instance.Battle.SetBattleBeastMaxHP(beastdata);
            GameManager.Instance.Lobby.PopupManager.BeastInfoPopup.beastHP.text =
            GameManager.Instance.PropertyNotation.FormatGameNumber(beastdata.MaxHP);
        }

        SetLevelUpUI(data, beastdata, index);

        if (InGameData.BeastAbility[beastdata.BeastID][index].abilityLevel >= data.MaxLv)
        {
            LevelMax.SetActive(true);
            LevelUp.enabled = false;
            return;
        }
    }

    private void SetLevelUpUI(cAbilitiy data, BeastData beast, int index)
    {
        var info = InGameData.BeastAbility[beast.BeastID][index];
        object[] spec = new object[] { data.SpecValue * info.abilityLevel };
        abilityIconLevel.text = string.Format("Lv.{0}", InGameData.BeastAbility[beast.BeastID][index].abilityLevel.ToString());
        abilityDescription.text = CleLocalization.Format("Localization", data.Description.ToString(), spec[0]);
        LevelUpCost.text = GameManager.Instance.PropertyNotation.FormatGameNumber(GetItemValue(data, info));

        if (InGameData.BeastAbility[beast.BeastID][index].abilityID == (int)eAbilityID.Skill)
        {
            GameManager.Instance.Lobby.PopupManager.BeastInfoPopup.UpdateBeastSkill(beast, InGameData.BeastAbility[beast.BeastID][index].abilityLevel);
        }
    }

    private double GetItemValue(cAbilitiy data, AbilityInfo info)
    {
        var cost = data.ItemValue * Mathf.Pow(1.2f, info.abilityLevel);
        return cost;
    }

    private void BeastSpecUp(int abilityID, Beast beast)
    {
        switch (abilityID)
        {
            case 1070010:
                BeastMaxHpUp(beast);
                break;
            case 1070020:
                BeastAtkSpeedUp(abilityID, beast);
                break;
            case 1070030:
                BeastCriRateUp(beast);
                break;
            case 1070040:
                BeastCriDamageUp(beast);
                break;
            case 1070050:
                BeastSkillUp(beast);
                break;
            case 1070060:
                BeastCoolTime(abilityID, beast);
                break;
            default:
                break;
        }

        InGameData.SaveData();
    }

    private bool UseItemCheck(double cost)
    {
        if (GameManager.Instance.InGameCoin.Value < cost) return false;

        GameManager.Instance.InGameCoin.Value -= cost;
        return true;
    }

    private void SetLevelUpListener(cAbilitiy data, BeastData beastdata, int index, AbilityInfo info, Beast beast)
    {
        LevelUp.onClick.RemoveAllListeners();
        LevelUp.onClick.AddListener(() =>
        {
            OnLevelUp(data, beastdata, index, info, beast);
        });
    }
}
