using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BeastState_Idle : BeastState
{
    private Beast beast;

    public BeastState_Idle(Beast _beast)
    {
        beast = _beast;
    }

    public void Enter()
    {
        beast.isDoing = true;
    }

    public void Doing()
    {
        if (beast.BeastAttack.isDied)
        {
            beast.SetCurrentStage(eBeastState.Battle_Die);
        }
        else
        {
            beast.SetCurrentStage(eBeastState.Battle_Move);
        }
    }

    public void Exit()
    {
        beast.isDoing = false;
    }
}
