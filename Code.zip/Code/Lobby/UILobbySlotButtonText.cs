using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

public class UILobbySlotButtonText : MonoBehaviour
{
    private UILobbySlotButton slotButton;
    private eMeatButtonType Type;
    private Text MainText;
    private Text SubText;
    private GameObject AutoOn;
    private GameObject AutoOff;
    private Animation basicEffect;
    private Animation upgradeEffect;

    private bool isTimeCheck = false;
    private float autoStartTime;
    private float autoSaveTime;

    public void Initialize(UILobbySlotButton Master, eMeatButtonType _type)
    {
        slotButton = Master;
        Type = _type;

        switch (_type)
        {
            case eMeatButtonType.Charge:
                MainText = GetComponentInChildren<Text>();
                SetMainText(InGameData.MeatCoin.ToString());
                break;
            case eMeatButtonType.Create:
                MainText = GetComponentsInChildren<Text>().FirstOrDefault(text => text.name.Contains("Stock"));
                SubText = GetComponentsInChildren<Text>().FirstOrDefault(text => text.name.Contains("Max"));
                basicEffect = GetComponentsInChildren<Animation>().FirstOrDefault(ani => ani.name.Contains("Basic"));
                upgradeEffect = GetComponentsInChildren<Animation>().FirstOrDefault(ani => ani.name.Contains("Upgrade"));
                SetMainText(InGameData.MeatCreate.ToString());
                break;
            case eMeatButtonType.Auto:
                var textList = GetComponentsInChildren<Text>();
                var textIndex = Array.FindIndex(textList, element => element.gameObject.name.Contains("Time"));
                MainText = textList[textIndex];
                AutoOn = GetComponentsInChildren<Transform>(true).Select(t => t.gameObject).FirstOrDefault(go => go.name == "ON");
                AutoOff = GetComponentsInChildren<Transform>(true).Select(t => t.gameObject).FirstOrDefault(go => go.name == "OFF");
                autoSaveTime = InGameData.AutoCreateTime;

                int min = Mathf.FloorToInt(InGameData.AutoCreateTime / 60);
                int sec = Mathf.FloorToInt(InGameData.AutoCreateTime % 60);
                MainText.text = string.Format("{0:D2}:{1:D2}", min, sec);
                break;
            default:
                MainText = GetComponentInChildren<Text>();
                break;
        }
    }

    public void SetMainText(string str)
    {
        MainText.text = str;
    }

    public void SetSubText(string str)
    {
        SubText.text = str;
    }

    public void SetBasicAni()
    {
        basicEffect.Play();
    }

    public void SetUpgradeAni()
    {
        upgradeEffect.Play();
    }

    public bool TimeCheck()
    {
        autoStartTime = Time.realtimeSinceStartup;
        isTimeCheck = !isTimeCheck;
        AutoOn.SetActive(isTimeCheck);
        AutoOff.SetActive(!isTimeCheck);
        InGameData.IsAutoCreate = isTimeCheck;

        if (!isTimeCheck)
        {
            InGameData.AutoCreateTime = autoSaveTime;
        }

        return isTimeCheck;
    }

    private void Update()
    {
        if (isTimeCheck)
        {
            float elapsed = Time.realtimeSinceStartup - autoStartTime;
            float remaining = InGameData.AutoCreateTime - elapsed;

            if (remaining <= 0f)
            {
                isTimeCheck = false;
                AutoOn.SetActive(false);
                AutoOff.SetActive(true);
                autoSaveTime = 900;
                InGameData.AutoCreateTime = 900f;
                InGameData.IsAutoCreate = false;

                int resetMin = Mathf.FloorToInt(InGameData.AutoCreateTime / 60);
                int resetSec = Mathf.FloorToInt(InGameData.AutoCreateTime % 60);
                MainText.text = string.Format("{0:D2}:{1:D2}", resetMin, resetSec);
                return;
            }

            int min = Mathf.FloorToInt(remaining / 60);
            int sec = Mathf.FloorToInt(remaining % 60);
            MainText.text = string.Format("{0:D2}:{1:D2}", min, sec);

            autoSaveTime = remaining;
        }
    }

    private void OnApplicationPause(bool pause)
    {
        if (pause)
        {
#if UNITY_IOS
            InGameData.AutoCreateTime = autoSaveTime;

            InGameData.SaveData();
#endif
        }
    }

    private void OnApplicationQuit()
    {
        if (Type == eMeatButtonType.Auto)
        {
            InGameData.AutoCreateTime = autoSaveTime;
            InGameData.SaveData();
        }
    }
}
