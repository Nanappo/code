using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tutorial_FirstTeamSlot : UITutorial
{
    private Popup_BeastInfo Popup;

    public override void Ready(Tutorial master)
    {
        base.Ready(master);

        Popup = GameManager.Instance.Lobby.PopupManager.BeastInfoPopup;
        Target = GameManager.Instance.Lobby.LobbyMeat.BattleMeatLaneSlots[0].gameObject;
        if (Target != null)
        {
            Master.Guide.transform.position = Target.transform.position;
        }

        Master.LockScreen[6].SetActive(true);
        NextScenario = eTutorial.AbilityHp;
    }

    public override IEnumerator Scenario()
    {
        Master.Guide.SetActive(true);
        Master.Guide.GetComponent<Animation>().Play("UI_Tuto_Idle");

        while (!isClear)
        {
            yield return null;
            if (Popup.gameObject.activeSelf == true)
            {
                isClear = true;
            }
        }

        End();
    }

    public override void End()
    {
        base.End();
        Master.LockScreen[6].SetActive(false);
        Master.LogEvent();
        Master.NextTutorial(NextScenario);
        InGameData.tutorialScenario = (int)eTutorial.FirstTeamSlot;
    }
}
