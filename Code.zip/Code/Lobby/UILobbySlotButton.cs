using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

public class UILobbySlotButton : MonoBehaviour
{
    [System.Serializable]
    public class ButtonGroup
    {
        public Button Button;
        public eMeatButtonType Type;
    }

    public List<ButtonGroup> groups = new List<ButtonGroup>();
    public float meatChargeTime { get; set; }

    //private GameObject SlotPrefab;
    //private UILobbyMeatSlot CreateSlot;          //����ID = 100 (�󽽷�)
    private LobbyMeat lobbyMeat;
    private UILobbySlotButtonText CreateText;
    private UILobbySlotButtonText ChargeText;
    private int MeatCreateMax = 20;
    private float spacing = 140f;               //grid slot�� position���� -135f��..
    private float autoTime = 0;
    private GridLayoutGroup Grid;
    private Coroutine autoCreateCoroutine;
    private Coroutine autoMergeCoroutine;

    public void Initialize()
    {
        lobbyMeat = GameManager.Instance.Lobby.LobbyMeat;
        //CreateSpecialSlot();

        for (int i = 0; i < groups.Count; i++)
        {
            int temp = i;

            var UISet = groups[temp].Button.gameObject.AddComponent<UILobbySlotButtonText>();
            UISet.Initialize(this, groups[temp].Type);

            groups[temp].Button.onClick.AddListener(() =>
                OnClickButton(groups[temp].Type, UISet));

            if (groups[temp].Type == eMeatButtonType.Create)
            {
                CreateText = UISet;
            }
            else if (groups[temp].Type == eMeatButtonType.Charge)
            {
                ChargeText = UISet;
            }
        }

        if (InGameData.IsAutoCreate)
        {
            Invoke(nameof(AutoCreateStart), 0.5f);
        }

        Invoke(nameof(SetButtonPosition), 0.1f);
        //SetButtonPosition();
        StartCoroutine(LobbyMeatCreateCharge(CreateText));
        SetMeatChargeTime((int)eStudyID.MeatChargeTime);
        SetMeatCreatMaxUp((int)eStudyID.MeatCreateMax);
    }

    private void SetButtonPosition()
    {
        Grid = GameManager.Instance.Lobby.Meatslot.GetComponent<GridLayoutGroup>();
        var rect = lobbyMeat.SpecialSlot.GetComponent<RectTransform>();
        rect.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, Grid.cellSize.x);
        rect.SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, Grid.cellSize.y);

        var rectTransform = GetComponent<RectTransform>();
        var gridrect = GameManager.Instance.Lobby.Meatslot.GetComponent<RectTransform>();
        var gridScript = gridrect.GetComponent<GridLayoutGroup>();
        var dynamicGrid = gridrect.GetComponent<DynamicGrid>();
        var gridHeight = gridrect.rect.height;
        var newPos = rectTransform.anchoredPosition;
        newPos.y = -gridHeight - spacing;
        rectTransform.anchoredPosition = newPos;

        //��ư ��ġ ������� Limit�� �ɾ�����ؼ� ����� ����...
        foreach (var slot in lobbyMeat.MeatSlots)
        {
            slot.SetLimitDragArea();
        }

        gridScript.enabled = false;
        dynamicGrid.enabled = false;
    }

    private void AutoCreateStart()
    {
        foreach (var group in groups)
        {
            if (group.Type != eMeatButtonType.Auto) continue;

            var text = group.Button.GetComponent<UILobbySlotButtonText>();
            AutoCreate(text, CreateText);
        }
    }

    private GameObject InstantiateCreateSlot()
    {
        //SlotPrefab = Resources.Load<GameObject>("Prefabs/MeatSlot");
        var slotName = GameManager.Instance.PrefabName[ePrefabName.CreateSlot];
        var slotPath = string.Format("Prefabs/{0}", slotName);
        var slotList = ObjectPoolManager.Instance.GetPool(slotName, 20, slotPath, transform.gameObject);
        var slotObj = slotList.GetObject(slotPath);
        //var slotObj = Instantiate(SlotPrefab);
        slotObj.transform.SetParent(transform);
        slotObj.transform.localPosition = Vector3.zero;
        slotObj.transform.localScale = Vector3.one;

        return slotObj;
    }

    private UILobbyMeatSlot CreateSpecialSlot()
    {
        var slotObj = InstantiateCreateSlot();
        var CreateSlot = slotObj.GetComponent<UILobbyMeatSlot>();
        CreateSlot.Initialize(100);
        CreateSlot.Lockimg.gameObject.SetActive(false);
        CreateSlot.MeatIcon.gameObject.SetActive(false);
        CreateSlot.gameObject.SetActive(false);

        return CreateSlot;
    }

    public void SetMeatCreatMaxUp(int studyID)
    {
        var spec = TableManager.Instance.Beast2_DataTableTable.GetStudyAttribute(studyID).SpecValue;
        MeatCreateMax = (int)(20 + (spec * GameManager.Instance.InGameStudy[studyID].Value));

        foreach (var group in groups)
        {
            if (group.Type == eMeatButtonType.Create)
            {
                var script = group.Button.GetComponent<UILobbySlotButtonText>();
                script.SetSubText(MeatCreateMax.ToString());
            }
        }
    }

    public void SetMeatChargeTime(int studyID)
    {
        var spec = TableManager.Instance.Beast2_DataTableTable.GetStudyAttribute(studyID).SpecValue;
        meatChargeTime = 10 - (spec * GameManager.Instance.InGameStudy[studyID].Value);
    }

    private IEnumerator LobbyMeatCreateCharge(UILobbySlotButtonText buttonText)
    {
        while (true)
        {
            yield return new WaitForSeconds(meatChargeTime);

            if (InGameData.MeatCreate >= MeatCreateMax) continue;

            InGameData.MeatCreate += 1;
            buttonText.SetMainText(InGameData.MeatCreate.ToString());
            Debug.Log("���� Į �����˴ϴ�~");
        }
    }

    #region Button

    private void OnClickButton(eMeatButtonType type, UILobbySlotButtonText buttonText)
    {
        switch (type)
        {
            case eMeatButtonType.Sort:
                OnLevelSorting();
                break;
            case eMeatButtonType.Charge:
                OnMeatCharge(buttonText);
                break;
            case eMeatButtonType.Create:
                OnMeatCreate(buttonText);
                break;
            case eMeatButtonType.Auto:
                InGameData.IsAutoCreate = true;
                //InGameData.AutoCreateTime = 900f;
                AutoCreate(buttonText, CreateText);
                break;
            case eMeatButtonType.Setting:
                break;
            default:
                break;
        }
    }

    private void OnLevelSorting()
    {
        //var newlist = lobbyMeat.MeatLaneSlots.OrderByDescending(data => data.Value.MeatItemData.Level).ToDictionary(x => x.Key, x => x.Value);
        var newlist = lobbyMeat.MeatLaneSlots.OrderByDescending(data => data.Value.MeatItemData.Level).ToList();
        var slot = lobbyMeat.MeatSlots;

        lobbyMeat.MeatLaneSlots.Clear();
        InGameData.MeatInLobby.Clear();

        for (int i = 0; i < newlist.Count; i++)
        {
            var iconIndex = newlist[i].Value.MeatItemData.Level % 100 != 0 ? newlist[i].Value.MeatItemData.Level % 100 : 100;
            slot[i].SelfData.Level = newlist[i].Value.MeatItemData.Level;
            slot[i].SelfData.isMeat = true;
            slot[i].MeatLvtxt.text = newlist[i].Value.MeatItemData.Level.ToString();
            slot[i].Iconimg.sprite = GameManager.Instance.Lobby.MeatSpriteDic[iconIndex];
            slot[i].MeatIcon.gameObject.SetActive(true);
        }

        for (int i = 0; i < newlist.Count; i++)
        {
            if (slot[i].MeatItemData == null)
            {
                slot[i].MeatItemData = new MeatData(slot[i].SelfData.Level);
            }
            else
            {
                slot[i].SetMeatData();
            }

            lobbyMeat.MeatLaneSlots.Add(slot[i].SelfData.SlotID, slot[i]);
            InGameData.MeatInLobby.Add(slot[i].SelfData.SlotID, slot[i].MeatItemData);
        }

        for (int i = newlist.Count; i < lobbyMeat.MeatSlots.Count; i++)
        {
            if (slot[i].SelfData.isLock) break;

            if (slot[i].SelfData.isMeat)
            {
                slot[i].SelfData.Level = 0;
                slot[i].SelfData.isMeat = false;
                slot[i].MeatIcon.gameObject.SetActive(false);
            }
        }
    }

    private void OnMeatCharge(UILobbySlotButtonText btntext)
    {
        if (InGameData.MeatCreate >= MeatCreateMax || InGameData.MeatCoin < 1) return;

        InGameData.MeatCoin -= 1;
        InGameData.MeatCreate += MeatCreateMax;
        btntext.SetMainText(InGameData.MeatCoin.ToString());

        foreach (var group in groups)
        {
            if (group.Type == eMeatButtonType.Create)
            {
                var script = group.Button.GetComponent<UILobbySlotButtonText>();
                script.SetMainText(InGameData.MeatCreate.ToString());
            }
        }
    }

    private void OnMeatCreate(UILobbySlotButtonText btntext)
    {
        StartCoroutine(Co_OnMeatCreate(btntext, false));
    }

    private IEnumerator Co_OnMeatCreate(UILobbySlotButtonText btntext, bool isAuto)
    {
        if (InGameData.MeatCreate < 1)
        {
            if (InGameData.MeatCoin < 1)
            {
                GameManager.Instance.Lobby.PopupManager.SplashMessagePopup.ShowPopup((int)eSplashMessageType.Proterty);
                yield break;
            }

            OnMeatCharge(ChargeText);
        }
        
        var startPos = btntext.gameObject.transform.position;
        var createSlot = CreateSpecialSlot();
        createSlot.transform.position = startPos;

        var slot = lobbyMeat.MeatSlots;
        var isfoundSlot = false;

        for (int i = 0; i < slot.Count; i++)
        {
            if (!slot[i].SelfData.isLock && !slot[i].SelfData.isMeat && !slot[i].isMaking)
            {
                isfoundSlot = true;

                if (isAuto)
                {
                    btntext.SetUpgradeAni();
                }
                else
                {
                    btntext.SetBasicAni();
                }

                slot[i].isMaking = true;
                createSlot.SelfData.Level = InGameData.CreateMeatLevel;
                createSlot.CreateIcon();
                createSlot.MeatIcon.gameObject.SetActive(true);
                createSlot.gameObject.SetActive(true);

                InGameData.MeatCreate -= 1;
                btntext.SetMainText(InGameData.MeatCreate.ToString());

                slot[i].SelfData.SlotID = i;
                slot[i].SelfData.Level = InGameData.CreateMeatLevel;
                slot[i].SelfData.isMeat = true;
                slot[i].MeatItemData = new MeatData(slot[i].SelfData.Level);
                InGameData.MeatInLobby.Add(i, slot[i].MeatItemData);
                lobbyMeat.MeatLaneSlots.Add(i, slot[i]);
                slot[i].SaveItemData();

                var endPos = slot[i].transform.position;
                var elapsed = 0f;
                var duration = 0.3f;

                while (elapsed < duration)
                {
                    var time = elapsed / duration;

                    createSlot.transform.position = Vector3.Lerp(startPos, endPos, time);
                    elapsed += Time.deltaTime;
                    yield return null;
                }

                slot[i].CreateIcon();

                createSlot.gameObject.SetActive(false);
                createSlot.transform.position = startPos;
                slot[i].isMaking = false;

                if (InGameData.CurrentMeatHighLevel < InGameData.CreateMeatLevel)
                {
                    InGameData.CurrentMeatHighLevel = InGameData.CreateMeatLevel;
                    lobbyMeat.NewMeatFind(InGameData.CreateMeatLevel);
                    GameManager.Instance.Lobby.PopupManager.NewMeatPopup.ShowPopup(InGameData.CreateMeatLevel);
                }

                yield break;
            }
        }

        if (!isfoundSlot)
        {
            GameManager.Instance.Lobby.PopupManager.SplashMessagePopup.ShowPopup((int)eSplashMessageType.Meat);
        }
    }

    private void AutoCreate(UILobbySlotButtonText btntext, UILobbySlotButtonText createtext)
    {
        autoTime = InGameData.AutoCreateTime;
        var isAuto = btntext.TimeCheck();
        if (isAuto)
        {
            autoCreateCoroutine = StartCoroutine(Co_AutoCreate(createtext));
            autoMergeCoroutine = StartCoroutine(Co_AutoMerge());
        }
        else
        {
            autoTime = 0;
            StopCoroutine(autoCreateCoroutine);
            StopCoroutine(autoMergeCoroutine);
            autoCreateCoroutine = null;
            autoMergeCoroutine = null;
        }
    }

    private IEnumerator Co_OnMeatMerge()
    {
        foreach (var slot1 in lobbyMeat.MeatSlots)
        {
            foreach (var slot2 in lobbyMeat.MeatSlots)
            {
                if (slot1.SelfData.SlotID != slot2.SelfData.SlotID &&
                    slot1.SelfData.Level == slot2.SelfData.Level &&
                    !slot1.IsPressed && !slot2.IsPressed &&
                    slot1.SelfData.isMeat && slot2.SelfData.isMeat &&
                    !slot1.isMaking && !slot2.isMaking)
                {
                    if (!InGameData.IsAutoCreate) yield break;

                    slot1.SelfData.Level += 1;
                    slot1.CreateIcon();
                    slot1.SaveItemData();

                    if (slot1.SelfData.Level > InGameData.CurrentMeatHighLevel)
                    {
                        InGameData.CurrentMeatHighLevel = slot1.SelfData.Level;
                        lobbyMeat.NewMeatFind(slot1.SelfData.Level);
                        GameManager.Instance.Lobby.PopupManager.NewMeatPopup.ShowPopup(slot1.SelfData.Level);
                    }

                    lobbyMeat.MeatLaneSlots.Remove(slot2.SelfData.SlotID);
                    InGameData.MeatInLobby.Remove(slot2.SelfData.SlotID);
                    slot2.ResetData();

                    yield return new WaitForSecondsRealtime(InGameData.MeatAutoMergeTime);
                    break;
                }
            }
        }
    }

    private IEnumerator Co_AutoCreate(UILobbySlotButtonText btntext)
    {
        var startTime = Time.realtimeSinceStartup;

        while (Time.realtimeSinceStartup - startTime < autoTime)
        {
            StartCoroutine(Co_OnMeatCreate(btntext, true));
            yield return new WaitForSecondsRealtime(InGameData.MeatAutoCreateTime);
        }
    }

    private IEnumerator Co_AutoMerge()
    {
        var startTime = Time.realtimeSinceStartup;

        while (Time.realtimeSinceStartup - startTime < autoTime)
        {
            yield return StartCoroutine(Co_OnMeatMerge());
        }
    }
    #endregion
}
