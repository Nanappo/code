using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum eMeatButtonType
{
    Sort,
    Charge,
    Create,
    Auto,
    Setting
}

public enum eBeastState
{
    Battle_Idle,
    Battle_Move,
    Battle_Attack,
    Battle_Skill,
    Battle_Die,
}

public enum eEnemySpawnType
{
    Enemy_Shot,
    Enemy_Missile,
    Enemy_Fly,
    Enemy_Barrier,
}

public enum eSpawnSection
{
    Section1,
    //Section2,
    //Section3,
}

public enum eFiretype
{
    None,
    Shot,
    Missile,
}

public enum ePrefabName
{
    Coin,
    Thunder,
    EnemyDamage,
    CreateSlot,
}

public enum eStudyID
{
    BattleSlot = 1060010,
    Atk = 1060020,
    CriRate = 1060030,
    CriDamage = 1060040,
    HP = 1060050,
    WaveHp = 1060060,
    AmountGold = 1060070,
    GoldDoubleUp = 1060080,
    IdleRewardUp = 1060090,
    ThunderDamage = 1060100,
    ThunderAuto = 1060110,
    MeatChargeTime = 1061010,
    MeatCreateMax = 1061020,
    CoinMeatLevel = 1061040,
    DiaMeatLevel = 1061050,
}

public enum eAbilityID
{
    HP = 1070010,
    AtkSpeed = 1070020,
    CriRate = 1070030,
    CriDamage = 1070040,
    Skill = 1070050,
    CoolTime = 1070060,
}

public enum eTeamPopupSlotType
{
    Team,
    Inventory
}

public enum eTutorial
{
    MeatCreate = 1,
    MeatMerge = 2,
    MeatClosePopup = 3,
    BeastClosePopup = 4,
    MeatInBattleSlot = 5,
    ClickStudy = 6,
    AtkUpgrade = 7,
    CloseStudy = 8,
    Thunder = 9,
    FirstTeamSlot = 10,
    AbilityHp = 11,
    BeastInfoClosePopup = 12,
    FirstEnd = 13,
    TeamSettingPopup = 14,
    InventorySelect = 15,
    TeamslotAdd = 16,
    End = 20
}

public enum eBottomButtonType
{
    Manage,
    Study,
    Dungeon,
    Summon,
    Shop
}

public enum eSplashMessageType
{
    Proterty = 1,
    Meat = 2
}
