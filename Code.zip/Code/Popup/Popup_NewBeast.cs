using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Popup_NewBeast : UIPopupControl
{
    public Image beastIcon;
    public Image beastIconBackground;
    public List<GameObject> beastIconClass = new List<GameObject>();
    public Text beastIconLevel;
    public Text beastName;
    public Text beastIconCount;
    public Text beastIconNextCount;
    public Text beastOwnerDescription;
    public Slider beastIconCountSlider;

    private BattleManager Battle;
    private LobbyManager Lobby;
    private int BeastID;

    protected override void Initialize()
    {
        base.Initialize();

        Battle = GameManager.Instance.Battle;
        Lobby = GameManager.Instance.Lobby;
    }

    public override void ShowPopup(int beastID = 0, bool isBattle = false)
    {
        OnCheck += ClosePopup;
        base.ShowPopup();

        BeastID = beastID;
        var beastData= new BeastData().SetBeastData(beastID);
        SetBeastIcon(beastData);
    }

    public override void ClosePopup()
    {
        ResetUI();
        if (BeastID == 1010060) GameManager.Instance.Lobby.LobbyUI.Guide.SetActive(true);
        base.ClosePopup();
    }

    private void SetBeastIcon(BeastData beast)
    {
        var ownerID = TableManager.Instance.Beast2_DataTableTable.GetBeastAttribute(beast.BeastID).Owned;
        var skillData = TableManager.Instance.Beast2_DataTableTable.GetSkillAttribute(ownerID);
        var ownedLevel = InGameData.BeastInGame[beast.BeastID].beastLevel > skillData.MaxLv ? skillData.MaxLv : InGameData.BeastInGame[beast.BeastID].beastLevel;
        var spec = new object[] { skillData.SpecValue * ownedLevel };

        beastIcon.sprite = Lobby.LobbyUI.GetSprite(Lobby.LobbyUI.BattleslotBeastIcon, beast.BeastID.ToString());
        beastIconBackground.color = Battle.SetBeastIconBackgroundColor(beast.Class);
        for (int i = 0; i < beast.Class; i++)
        {
            beastIconClass[i].SetActive(true);
        }

        beastName.text = CleLocalization.Format("Localization", beast.BeastID.ToString(), null);
        beastOwnerDescription.text = CleLocalization.Format("Localization", skillData.Description.ToString(), spec[0]);
        //�������� �� �����ִµ� ���� ��ü ������ ����, �����ؼ� ���� ������. ���� �� �����ؾ���.
        //�ϴ� 1�θ� ������ ó��
        beastIconLevel.text = "1";
        beastIconCount.text = "1";
        beastIconNextCount.text = "10";
        beastIconCountSlider.value = 1;
    }

    private void ResetUI()
    {
        for (int i = 0; i < beastIconClass.Count; i++)
        {
            beastIconClass[i].SetActive(false);
        }
    }
}
