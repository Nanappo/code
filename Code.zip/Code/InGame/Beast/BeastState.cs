using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface BeastState
{
    public void Enter();

    public void Doing();

    public void Exit();
}
