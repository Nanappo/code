using Firebase.Analytics;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

public class LobbyMeat : MonoBehaviour
{
    public Dictionary<int, UIBattleSlotMeat> BattleMeatLaneSlots = new Dictionary<int, UIBattleSlotMeat>();     //��Ʋ���⽽��
    public Dictionary<int, LobbyMeatSlot> MeatLaneSlots = new Dictionary<int, LobbyMeatSlot>();     //�κ��� ���Ⱑ �ִ� ����
    public List<UILobbyMeatSlot> MeatSlots = new List<UILobbyMeatSlot>();       //�� ���⽽��

    public GameObject SpecialSlot;
    private GameObject MeatPrefab;
    private GameObject BattleMeatPrefab;

    public void Initialize()
    {
        MeatPrefab = Resources.Load<GameObject>("Prefabs/MeatSlot");
        BattleMeatPrefab = Resources.Load<GameObject>("Prefabs/BattleSlotMeat");

        for (int i = 0; i < 41; i++)
        {
            var slotObj = Instantiate(MeatPrefab);
            slotObj.transform.SetParent(GameManager.Instance.Lobby.Meatslot.transform);
            slotObj.tag = "MeatSlot";
            slotObj.transform.localPosition = Vector3.zero;
            slotObj.transform.localScale = Vector3.one;
            if (i == 40)
            {
                SpecialSlot = slotObj;
                var slotinfo = SpecialSlot.GetComponent<UILobbyMeatSlot>();
                slotinfo.Lockimg.gameObject.SetActive(false);
                slotinfo.MeatIcon.gameObject.SetActive(false);
                SpecialSlot.SetActive(false);
                break;
            }

            var slot = slotObj.GetComponent<UILobbyMeatSlot>();
            slot.Initialize(i);
            MeatSlots.Add(slot);

            if (slot.SelfData.isMeat)
            {
                MeatLaneSlots.Add(i, slot);
            }
        }

        for (int i = 0; i < 5; i++)
        {
            var slotObj = Instantiate(BattleMeatPrefab);
            slotObj.transform.SetParent(GameManager.Instance.Lobby.BattleMeatslot.transform);
            slotObj.tag = "TeamSlot";
            slotObj.transform.localPosition = Vector3.zero;
            slotObj.transform.localScale = Vector3.one;

            var slot = slotObj.GetComponent<UIBattleSlotMeat>();
            slot.Initialize(i);

            BattleMeatLaneSlots.Add(i, slot);
        }
    }

    public void OnDraging(Vector3 UISpacePos, GameObject item)
    {
        UISpacePos.y += 0.2f;
        item.transform.position = UISpacePos;
    }

    public void NewMeatFind(int level)
    {
        if (level % 5 == 0)
        {
            GameManager.Instance.Firebase.LogEvent("meat_level", new Parameter("level", level));
            Debug.Log($"Event Log : meatLevel {level}");
        }

        var beastID = 0;
        switch (level)
        {
            case 2:
            case 3:
            case 4:
            case 5:
                beastID = 1010000 + (level * 10);
                SetBattleSlot(beastID);
                break;
            case 6:
            case 7:
            case 8:
            case 9:
            case 10:
                beastID = 1010000 + (level * 10);
                SetInventory(beastID);
                break;
            default:
                return;
        }

        GameManager.Instance.Lobby.PopupManager.NewBeastPopup.ShowPopup(beastID);
        InGameData.SaveData();
    }

    private void SetBattleSlot(int beastID)
    {
        var slotIndex = InGameData.BattleSlotCount;
        if (InGameData.BeastInBattle.ContainsKey(slotIndex)) return;

        InGameData.BattleSlotCount++;
        //�ӽ�ID
        InGameData.MeatInBattle.Add(slotIndex, new MeatData(InGameData.CreateMeatLevel));
        //�����̱� ����� ���� ������ �ִ°� �ִ��� Ȯ���ؼ� ������
        //ID�־��ְ� ������ ��� ������ ���ִ°ɷ� �ٲ����.
        InGameData.BeastInBattle.Add(slotIndex, new BeastData().SetBeastData(beastID));
        BattleMeatLaneSlots[slotIndex].SetBattleSlotData(slotIndex);

        if (InGameData.BeastInGame.ContainsKey(beastID))
        {
            InGameData.BeastInGame[beastID].beastCount += 1;
        }
        else
        {
            InGameData.BeastInGame[beastID] = new HasBeast
            {
                beastLevel = 1,
                beastCount = 1
            };
        }

        if (!InGameData.BeastAbility.ContainsKey(beastID))
        {
            InGameData.BeastAbility[beastID] = new List<AbilityInfo>{
            new AbilityInfo { abilityID = 1070010, abilityLevel = 0 },
            new AbilityInfo { abilityID = 1070020, abilityLevel = 0 },
            new AbilityInfo { abilityID = 1070030, abilityLevel = 0 },
            new AbilityInfo { abilityID = 1070040, abilityLevel = 0 },
            new AbilityInfo { abilityID = 1070050, abilityLevel = 0 },
            new AbilityInfo { abilityID = 1070060, abilityLevel = 0 }
            };
        }

        GameManager.Instance.Battle.EnterTheBattle(InGameData.BeastInBattle[slotIndex], slotIndex);
        //������ ���� ���� �÷��ֱ�
        GameManager.Instance.InGameStudy[1060010].Value += 1;
        //������ �߰��ɶ� ����ȿ���� ���� ���ⷹ�� ������ �ֱ⿡ �־���.
        InGameData.CreateMeatLevel = GameManager.Instance.Lobby.SetMeatCreateLevel();
        GameManager.Instance.Lobby.UpgradeAllMeat();
    }

    private void SetInventory(int beastID)
    {
        if (InGameData.BeastInGame.ContainsKey(beastID))
        {
            InGameData.BeastInGame[beastID].beastCount += 1;
        }
        else
        {
            InGameData.BeastInGame[beastID] = new HasBeast
            {
                beastLevel = 1,
                beastCount = 1
            };
        }

        if (!InGameData.BeastAbility.ContainsKey(beastID))
        {
            InGameData.BeastAbility[beastID] = new List<AbilityInfo>{
            new AbilityInfo { abilityID = 1070010, abilityLevel = 0 },
            new AbilityInfo { abilityID = 1070020, abilityLevel = 0 },
            new AbilityInfo { abilityID = 1070030, abilityLevel = 0 },
            new AbilityInfo { abilityID = 1070040, abilityLevel = 0 },
            new AbilityInfo { abilityID = 1070050, abilityLevel = 0 },
            new AbilityInfo { abilityID = 1070060, abilityLevel = 0 }
            };
        }

        //������ �߰��ɶ� ����ȿ���� ���� ���ⷹ�� ������ �ֱ⿡ �־���.
        InGameData.CreateMeatLevel = GameManager.Instance.Lobby.SetMeatCreateLevel();
        GameManager.Instance.Lobby.UpgradeAllMeat();
    }
}
