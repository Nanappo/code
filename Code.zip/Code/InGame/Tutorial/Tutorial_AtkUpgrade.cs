using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tutorial_AtkUpgrade : UITutorial
{
    private BottomButtonControl Bottom;
    private StudyControl studyPrefab;
    private UIBottomButton studyButton;

    public override void Ready(Tutorial master)
    {
        base.Ready(master);

        Bottom = GameManager.Instance.Lobby.LobbyUI.BottomControl;
        foreach (var button in Bottom.BottomButton)
        {
            if (button.mytype == eBottomButtonType.Study)
            {
                studyPrefab = button.OpenPrefab.GetComponent<StudyControl>();
                studyButton = button;
            }
        }

        if (studyButton.selectObj.activeSelf == false)
        {
            NextScenario = eTutorial.Thunder;
            End();
            return;
        }

        Target = studyPrefab.TutorialButton.gameObject;
        Master.Guide.transform.position = Target.transform.position;
        Master.LockScreen[4].SetActive(true);
        NextScenario = eTutorial.CloseStudy;
    }

    public override IEnumerator Scenario()
    {
        Master.Guide.SetActive(true);
        Master.Guide.GetComponent<Animation>().Play("UI_Tuto_Idle");

        while (!isClear)
        {
            yield return null;
            if (GameManager.Instance.InGameStudy[1060020].Value == 1)
            {
                isClear = true;
            }
        }

        End();
    }

    public override void End()
    {
        base.End();
        studyButton.Button.enabled = true;
        Master.LockScreen[4].SetActive(false);
        Master.LogEvent();
        Master.NextTutorial(NextScenario);
    }
}
