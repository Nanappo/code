using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class RawImageButton : MonoBehaviour
{
    public Action OnTutorialEvent;
    private Button button;

    private void Start()
    {
        button = GetComponent<Button>();

        button.onClick.AddListener(() =>
        {
            if (OnTutorialEvent != null) OnTutorialEvent.Invoke();
            GameManager.Instance.Battle.BattleUI.ThunderStart();
        });
    }
}
