using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Rendering;

public class LobbyMeatSlot : UIEventTrigger
{
    public MeatData MeatItemData { get; set; }

    public class SlotData
    {
        public int SlotID;
        public int Level;
        public bool isMeat;
        public bool isLock;
    }

    public Vector2 FirstTouchPos { get; private set; }
    public Vector2 DragStartPos { get; private set; }
    public Vector2 OriginPos { get; private set; }
    public SlotData SelfData { get; private set; }
    public bool isMaking { get; set; }

    protected LobbyMeat lobbyMeat;
    protected int originIndex;
    protected Vector3 originPos;

    public virtual void Initialize(int slotID)
    {
        if (InGameData.MeatInLobby.ContainsKey(slotID))
        {
            MeatItemData = new MeatData(
                InGameData.MeatInLobby[slotID].Level
                );

            SelfData = new SlotData()
            {
                SlotID = slotID,
                Level = InGameData.MeatInLobby[slotID].Level,
                isMeat = true,
                isLock = false
            };

            //SelfData.isMeat = InGameData.MeatInLobby[slotID].Level == 0 ? false : true;
        }
        else
        {
            SelfData = new SlotData()
            {
                SlotID = slotID,
                Level = 0,
                isMeat = false
            };

            SelfData.isLock = slotID < InGameData.MeatSlotCount ? false : true;
        }

        InitializeDrag();

        lobbyMeat = GameManager.Instance.Lobby.LobbyMeat;
        originIndex = transform.GetSiblingIndex();
    }

    public void SetLimitDragArea()
    {
        //�׸��� ��ġ���� ��ģ �� �� ������ �ʰ� ��ƾ��ؼ� ���⿡ �־��..
        originPos = transform.position;

        float xMaxLimit = GameManager.Instance.GameScreen.LobbyOffsetRight - 1.8f;
        float yTopLimit = GameManager.Instance.Lobby.BattleMeatslot.transform.position.y;
        float yBottomLimit = GameManager.Instance.Lobby.LobbyButton.transform.position.y;
        DragLimit = new Vector4(-xMaxLimit, xMaxLimit, yBottomLimit, yTopLimit);
        //float yTopLimit = GameManager.Instance.GameScreen.LobbyOffsetTop - 1f;
        //float yBottomLimit = GameManager.Instance.GameScreen.LobbyOffsetBottom + 4f;
    }

    public override void OnPointerBeginDragDelegate(PointerEventData data)
    {
        if (!SelfData.isMeat) return;

        IsPressed = true;
        DragStartPos = data.position;
        lobbyMeat.SpecialSlot.transform.SetSiblingIndex(originIndex);
        lobbyMeat.SpecialSlot.transform.position = originPos;
        lobbyMeat.SpecialSlot.SetActive(true);

        transform.SetAsLastSibling();
    }

    public override void OnPointerDragDelegate(PointerEventData data)
    {
        if (!SelfData.isMeat) return;

        FirstTouchPos = Vector2.Lerp(FirstTouchPos, DragStartPos, Time.unscaledDeltaTime * 10f);

        Vector2 moveDist = data.position - DragStartPos;
        Vector2 movePosScreen = FirstTouchPos + moveDist;
        Vector3 newPos = GameManager.Instance.Lobby.LobbyCamera.ScreenToWorldPoint(movePosScreen);
        newPos.y = newPos.y < DragLimit.z ? DragLimit.z :
                   newPos.y > DragLimit.w ? DragLimit.w :
                   newPos.y;
        newPos.x = newPos.x < DragLimit.x ? DragLimit.x :
                   newPos.x > DragLimit.y ? DragLimit.y :
                   newPos.x;
        newPos.z = 10f;

        lobbyMeat.OnDraging(newPos, gameObject);
    }

    public override void OnPointerDownDelegate(PointerEventData data)
    {
        if (!SelfData.isMeat) return;

        FirstTouchPos = data.position;
        OriginPos = transform.position;

        tag = "Untagged";
    }
}
