using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIBottomButton : MonoBehaviour
{
    public GameObject normalObj;
    public GameObject selectObj;
    public GameObject OpenPrefab;
    public eBottomButtonType mytype { get; set; }
    public Button Button { get; private set; }

    private BottomButtonControl Master;

    public void Initialize(BottomButtonControl master, int type)
    {
        Master = master;
        Button = GetComponent<Button>();
        mytype = (eBottomButtonType)type;

        if (Button != null)
        {
            Button.onClick.AddListener(() =>
            {
                SetClickButton();
            });
        }

        if (OpenPrefab != null)
        {
            OpenPrefab.GetComponent<BottomState>().Init();
        }
    }

    public void SetClickButton(bool isPush = false)
    {
        if (normalObj.activeSelf)
        {
            Master.ButtonControl(this);
            normalObj.SetActive(false);
            selectObj.SetActive(true);
            if (OpenPrefab != null)
            {
                OpenPrefab.SetActive(true);
                OpenPrefab.GetComponent<BottomState>().Open();
            }
            transform.localScale = Vector3.one * 1.1f;
        }
        else if (selectObj.activeSelf || isPush)
        {
            Master.currentButton = null;
            normalObj.SetActive(true);
            selectObj.SetActive(false);
            transform.localScale = Vector3.one;
            if (OpenPrefab != null)
            {
                OpenPrefab.SetActive(false);
            }
        }
    }
}
