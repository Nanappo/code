using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tutorial_Thunder : UITutorial
{
    private RawImageButton ThunderEvent;
    private int count = 0;

    public override void Ready(Tutorial master)
    {
        base.Ready(master);

        ThunderEvent = GameManager.Instance.Lobby.BattleImage.GetComponentInChildren<RawImageButton>();
        ThunderEvent.OnTutorialEvent += OnCheckThunder;
        Target = GameManager.Instance.Lobby.BattleImage.gameObject;
        if (Target != null)
        {
            var pos = Target.transform.position;
            pos.y += 2f;
            Master.Guide.transform.position = pos;
        }

        Master.LockScreen[5].SetActive(true);
        NextScenario = eTutorial.FirstTeamSlot;
    }

    public override IEnumerator Scenario()
    {
        Master.Guide.SetActive(true);
        Master.Guide.GetComponent<Animation>().Play("UI_Tuto_Idle");

        while (!isClear)
        {
            yield return null;
            if (count == 2)
            {
                isClear = true;
            }
        }

        End();
    }

    public override void End()
    {
        base.End();
        ThunderEvent.OnTutorialEvent = null;
        Master.LockScreen[5].SetActive(false);
        Master.LogEvent();
        Master.NextTutorial(NextScenario);
    }

    private void OnCheckThunder()
    {
        count++;
    }
}
