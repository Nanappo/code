using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tutorial_InventorySelect : UITutorial
{
    private Popup_TeamSetting Popup;

    public override void Ready(Tutorial master)
    {
        base.Ready(master);

        Popup = GameManager.Instance.Lobby.PopupManager.TeamSettingPopup;
        if (Popup.InventorySlot.Count > 0) Target = Popup.InventorySlot[0];

        if (Target != null)
        {
            Master.Guide.transform.position = Target.transform.position;
        }

        Master.LockScreen[10].SetActive(true);
        NextScenario = eTutorial.TeamslotAdd;
    }

    public override IEnumerator Scenario()
    {
        Master.Guide.SetActive(true);
        Master.Guide.GetComponent<Animation>().Play("UI_Tuto_Idle");

        while (!isClear)
        {
            yield return null;
            if (Popup.InventorySlot[0].GetComponent<Popup_UITeamSetting>().beastSelect.activeSelf)
            {
                isClear = true;
            }
        }

        End();
    }

    public override void End()
    {
        base.End();
        Master.LockScreen[10].SetActive(false);
        Master.NextTutorial(NextScenario);
        InGameData.tutorialScenario = (int)eTutorial.FirstEnd;
    }
}
