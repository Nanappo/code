using UnityEngine;
using UnityEngine.UI;

public class Popup_NextArea : UIPopupControl
{
    public Button cancleButton;

    protected override void Initialize()
    {
        base.Initialize();
        if (cancleButton == null) return;

        cancleButton.onClick.AddListener(() =>
        {
            OnCancleButton();
        });
    }

    public override void ShowPopup(int data = 0, bool isCheck = false)
    {
        OnCheck += OnCheckButton;
        base.ShowPopup();
    }

    private void OnCancleButton()
    {
        ClosePopup();
    }

    private void OnCheckButton()
    {
        GameManager.Instance.Battle.waveSystem.FailWave(1f, 4f, () =>
        {
            GameManager.Instance.Lobby.PopupManager.RebirthPopup.ShowPopup();
            GameManager.Instance.Battle.waveSystem.ChangeArea();
            GameManager.Instance.Battle.waveSystem.WaveSystemUI.CloseNextWaveUI();
            ClosePopup();
        });
    }
}
