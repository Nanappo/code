using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BeastProjectile : Projectile
{
    public float LifeTime = 0;

    private Beast beast;
    private GameObject enemy;
    private bool IsPenetration;
    private bool IsCritical;

    public void SetData(Beast _beast = null, int penetration = 0)
    {
        if (_beast != null) beast = _beast;
        IsPenetration = penetration == 1 ? true : false;
    }

    public override void SetDamage(float _damage, bool _isCritical = false)
    {
        base.SetDamage(_damage);
        IsCritical = _isCritical;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (!collision.gameObject.CompareTag("Enemy")) return;

        var script = collision.GetComponent<Enemy>();
        if (script.Attack.isDied) return;

        script.Attack.AfterTakingDamage(damage, IsCritical);
        if (IsPenetration) return;

        gameObject.SetActive(false);
    }

    private IEnumerator Co_ActiveOff(float delay)
    {
        yield return new WaitForSeconds(delay);
        gameObject.SetActive(false);
    }

    public void ActiveOff()
    {
        StartCoroutine(Co_ActiveOff(LifeTime));
    }
}
