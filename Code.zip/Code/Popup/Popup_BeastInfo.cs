using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Popup_BeastInfo : UIPopupControl
{
    [Header("BeastThumbnail")]
    public Image beastIcon;
    public Image beastIconBackground;
    public List<GameObject> beastIconClass = new List<GameObject>();
    public Text beastIconLevel;
    public Text beastName;
    public Text beastIconCount;
    public Text beastIconNextCount;
    public Slider beastIconCountSlider;

    [Header("BattleSpec")]
    public Text beastAtk;
    public Text beastHP;
    public Text meatLevel;
    public Text beastBonusLevel;

    [Header("BeastSkill")]
    public Image activeSkillIcon;
    public Text activeSkillLevel;
    public Text activeSkillName;
    public Text activeSkillDescription;

    public Image ownedSkillIcon;
    public Text ownedSkillLevel;
    public Text ownedSkillName;
    public Text ownedSkillDescription;

    [Header("Ability")]
    public GameObject abilitySample;

    public List<BeastAbilityItem> beastAbilityItems { get; set; }

    private BattleManager Battle;
    private LobbyManager Lobby;

    protected override void Initialize()
    {
        base.Initialize();

        beastAbilityItems = new List<BeastAbilityItem>();
        Battle = GameManager.Instance.Battle;
        Lobby = GameManager.Instance.Lobby;
    }

    public override void ShowPopup(int slotID = -1, bool isBattle = false)
    {
        OnCheck += ClosePopup;
        base.ShowPopup();
        SetBeastInfoUI(isBattle, slotID);
    }

    public override void ClosePopup()
    {
        ResetUI();
        base.ClosePopup();
    }

    private void SetBeastInfoUI(bool isBattle, int slotID)
    {
        if (isBattle)
        {
            var beast = Battle.BattleBeast[slotID];
            SetBeastIcon(beast.SelfData);
            SetBattleSpec(beast.SelfData, slotID);
            SetBeastSkill(beast.SelfData);
            SetAbilityPrefabs(beast.SelfData, beast);
        }
        else
        {
            //slotID=beastID
            var beast = GameManager.Instance.Lobby.PopupManager.TeamSettingPopup.InventoryBeast[slotID];
            SetBeastIcon(beast);
            SetBattleSpec(beast, -1);
            SetBeastSkill(beast);
            SetAbilityPrefabs(beast);
        }
    }

    private void SetBeastIcon(BeastData beast)
    {
        beastIcon.sprite = Lobby.LobbyUI.GetSprite(Lobby.LobbyUI.BattleslotBeastIcon, beast.BeastID.ToString());
        beastIconBackground.color = Battle.SetBeastIconBackgroundColor(beast.Class);
        for (int i = 0; i < beast.Class; i++)
        {
            beastIconClass[i].SetActive(true);
        }

        beastName.text = CleLocalization.Format("Localization", beast.BeastID.ToString(), null);
        //�������� �� �����ִµ� ���� ��ü ������ ����, �����ؼ� ���� ������. ���� �� �����ؾ���.
        //�ϴ� 1�θ� ������ ó��
        beastIconLevel.text = "1";
        beastIconCount.text = "1";
        beastIconNextCount.text = "10";
        beastIconCountSlider.value = 1;
    }

    private void SetBattleSpec(BeastData beast, int slotID)
    {
        var atk = GameManager.Instance.Battle.SetBattleBeastAtk(beast, slotID, InGameData.CreateMeatLevel);
        var hp = GameManager.Instance.Battle.SetBattleBeastMaxHP(beast);

        beastAtk.text = GameManager.Instance.PropertyNotation.FormatGameNumber(atk);
        beastHP.text = GameManager.Instance.PropertyNotation.FormatGameNumber(hp);

        //���Ŀ� ������ ���� ��� ����� ���� ���ⷹ�� / ���� ���ⷹ�� �� ���������.
        if (slotID == -1)
        {
            meatLevel.text = InGameData.CreateMeatLevel.ToString();
        }
        else meatLevel.text = InGameData.MeatInBattle[slotID].Level.ToString();
        beastBonusLevel.text = beast.BonusLevel.ToString();
    }

    private void SetBeastSkill(BeastData beast)
    {
        var activeSkillData = TableManager.Instance.Beast2_DataTableTable.GetSkillAttribute(beast.Active);
        var ownedSkillData = TableManager.Instance.Beast2_DataTableTable.GetSkillAttribute(beast.Owned);
        var activeLevel = GetAbilityLevle(beast, (int)eAbilityID.Skill);
        var ownedLevel = InGameData.BeastInGame[beast.BeastID].beastLevel > ownedSkillData.MaxLv ? ownedSkillData.MaxLv : InGameData.BeastInGame[beast.BeastID].beastLevel;

        object[] spec = new object[] { activeSkillData.MaxLv, ownedSkillData.MaxLv, activeSkillData.SpecValue * activeLevel, activeSkillData.Duration, ownedSkillData.SpecValue * ownedLevel };

        activeSkillIcon.sprite = Lobby.LobbyUI.GetSprite(Lobby.LobbyUI.BilinearIcon, beast.Active.ToString());
        activeSkillLevel.text = string.Format("Lv.{0}", activeLevel.ToString());
        activeSkillName.text = CleLocalization.Format("Localization", beast.Active.ToString(), spec[0]);
        activeSkillDescription.text = CleLocalization.Format("Localization", activeSkillData.Description.ToString(), spec[2], spec[3]);

        ownedSkillIcon.sprite = Lobby.LobbyUI.GetSprite(Lobby.LobbyUI.BilinearIcon, beast.Owned.ToString());
        ownedSkillLevel.text = string.Format("Lv.{0}", ownedLevel.ToString());
        ownedSkillName.text = CleLocalization.Format("Localization", beast.Owned.ToString(), spec[1]);
        ownedSkillDescription.text = CleLocalization.Format("Localization", ownedSkillData.Description.ToString(), spec[4]);
    }

    public void UpdateBeastSkill(BeastData beast, int activeLevel)
    {
        var activeSkillData = TableManager.Instance.Beast2_DataTableTable.GetSkillAttribute(beast.Active);
        object[] spec = new object[] { activeSkillData.SpecValue * activeLevel, activeSkillData.Duration };
        activeSkillLevel.text = string.Format("Lv.{0}", activeLevel.ToString());
        activeSkillDescription.text = CleLocalization.Format("Localization", activeSkillData.Description.ToString(), spec[0], spec[1]);
    }

    private void ResetUI()
    {
        for (int i = 0; i < beastIconClass.Count; i++)
        {
            beastIconClass[i].SetActive(false);
        }
    }

    private int GetAbilityLevle(BeastData beast, int abilityID)
    {
        foreach (var item in InGameData.BeastAbility[beast.BeastID])
        {
            if (item.abilityID != abilityID) continue;

            return item.abilityLevel;
        }

        return 0;
    }

    private void SetAbilityPrefabs(BeastData beastdata, Beast beast = null)
    {
        beastAbilityItems.Clear();

        var objName = abilitySample.name;
        var itemList = ObjectPoolManager.Instance.GetPool(objName, 6, "", null, abilitySample);

        for (int i = 0; i < itemList.PoolList.Count; i++)
        {
            var item = itemList.PoolList[i];
            item.transform.SetParent(abilitySample.transform.parent);
            var itemPos = item.transform.localPosition;
            itemPos.z = 0;
            item.transform.localPosition = itemPos;
            item.transform.localScale = Vector3.one;
            item.SetActive(true);
            var abilityInfo = InGameData.BeastAbility[beastdata.BeastID][i];
            var script = item.GetComponent<BeastAbilityItem>();
            script.SetAbilityUI(abilityInfo, beastdata, i, beast);
            beastAbilityItems.Add(script);
        }

        abilitySample.SetActive(false);
    }
}
