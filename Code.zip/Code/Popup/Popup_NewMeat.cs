using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Popup_NewMeat : UIPopupControl
{
    public Animation newMeatAni;
    public Image newMeatIcon;
    public Text newMeatText;

    private double rewardGold;

    protected override void Initialize()
    {
        base.Initialize();
    }

    public override void ShowPopup(int level, bool isCheck = false)
    {
        OnCheck += OnReward;
        SetNewMeatUI(level);
        base.ShowPopup();
    }

    public void UpdatePopup(int level)
    {
        SetNewMeatUI(level);
    }

    private void OnReward()
    {
        GameManager.Instance.InGameGold.Value += rewardGold;
        ClosePopup();
    }

    private void SetNewMeatUI(int level)
    {
        var iconIndex = level % 100 != 0 ? level % 100 : 100;
        newMeatAni.Play();
        newMeatIcon.sprite = GameManager.Instance.Lobby.MeatSpriteDic[iconIndex];
        newMeatText.text = string.Format("Lv.{0}", level);
        rewardGold = 1000 * Math.Pow(level, 2);
        mainText.text = GameManager.Instance.PropertyNotation.FormatGameNumber(rewardGold);
    }
}
