using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface BottomState
{
    public void Init();

    public void Open();
}
