using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIEnemyDamage : MonoBehaviour
{
    public Animation Ani;
    public Text Normal;
    public Text Critical;

    private string clipName = "UI_DamageText";

    public void SetText(bool isCritical, float damage)
    {
        if (isCritical)
        {
            Critical.text=GameManager.Instance.PropertyNotation.FormatGameNumber(damage);
        }
        else
        {
            Normal.text = GameManager.Instance.PropertyNotation.FormatGameNumber(damage);
        }

        Normal.gameObject.SetActive(!isCritical);
        Critical.gameObject.SetActive(isCritical);

        var clipLength = Ani[clipName].length;
        Invoke(nameof(ActiveFalseObject), clipLength);
    }

    private void ActiveFalseObject()
    {
        gameObject.SetActive(false);
    }
}
