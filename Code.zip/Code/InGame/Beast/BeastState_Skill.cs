using DLL_Datatables;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BeastState_Skill : Attack, BeastState
{
    public GameObject SkillPoint;
    public int myStyle { get; private set; }
    public GameObject SkillProjectile { get; private set; }

    private Beast beast;
    private cSkill ActiveSkillData;
    private Action SkillAction;
    private float SkillAtk;
    private Coroutine CO_CoolTime;

    public void Init()
    {
        beast = GetComponent<Beast>();
        ActiveSkillData = TableManager.Instance.Beast2_DataTableTable.GetSkillAttribute(beast.SelfData.Active);
        myStyle = ActiveSkillData.Style;
        SetTargetDistance();
        SetSkillStyle();

        if (gameObject.activeSelf)
        {
            StartCoolTime();
        }
    }

    private void SetSkillStyle()
    {
        SetAtkToStyle(myStyle);

        switch (myStyle)
        {
            case 1:
                SkillAction = () =>
                {
                    SkillProjectile = MakeProjectile(5, null, ActiveSkillData.UsePrefab);
                    var script = SkillProjectile.GetComponent<BeastProjectile>();
                    script.SetData(beast, ActiveSkillData.Penetration);
                    script.SetDamage(SkillAtk);
                    script.ActiveOff();

                    if (ActiveSkillData.ProjectileSpeed == 1)
                    {
                        switch (ActiveSkillData.TargetDistance)
                        {
                            case 3:
                                CurveAttack(SkillProjectile, Vector2.right, beast.BeastAttack.curveAttackForce, beast.BeastAttack.curveAttackUpForce);
                                break;
                            case 1:
                            case 2:
                                BeelineAttack(SkillProjectile, Vector2.right, beast.BeastAttack.beelineAttackForce);
                                break;
                        }
                    }
                };
                break;
            case 2:
                SkillAction = () =>
                {
                    var duration = ActiveSkillData.Duration;
                    beast.BeastAttack.BuffAtk = (int)SkillAtk;
                    StartCoroutine(DurationSkill(duration, () =>
                    {
                        beast.BeastAttack.SetAtkToBuffAtk();
                    }));
                };
                break;
            case 3:
                SkillAction = () =>
                {
                    beast.SelfData.HP += SkillAtk;
                    if (beast.SelfData.HP > beast.SelfData.MaxHP)
                    {
                        beast.SelfData.HP = beast.SelfData.MaxHP;
                    }
                    beast.BeastAttack.GuageBar.SetGuage(beast.SelfData, beast.SelfData.HP);
                };
                break;
            case 4:
                SkillAction = () =>
                {
                    var duration = ActiveSkillData.Duration;
                    foreach (var beast in GameManager.Instance.Battle.BattleBeast)
                    {
                        beast.Value.BeastAttack.BuffAtk = (int)SetAtkToStyle(beast.Value.SelfData, myStyle);
                    }
                    StartCoroutine(DurationSkill(duration, () =>
                    {
                        foreach (var beast in GameManager.Instance.Battle.BattleBeast)
                        {
                            beast.Value.BeastAttack.SetAtkToBuffAtk();
                        }
                    }));
                };
                break;
            case 5:
                SkillAction = () =>
                {
                    foreach (var beast in GameManager.Instance.Battle.BattleBeast)
                    {
                        if (beast.Value.isDie) continue;

                        beast.Value.SelfData.HP += SetAtkToStyle(beast.Value.SelfData, myStyle);
                        if (beast.Value.SelfData.HP > beast.Value.SelfData.MaxHP)
                        {
                            beast.Value.SelfData.HP = beast.Value.SelfData.MaxHP;
                        }
                        beast.Value.BeastAttack.GuageBar.SetGuage(beast.Value.SelfData, beast.Value.SelfData.HP);
                    }
                };
                break;
        }
    }

    public void SetAtkToStyle(int style)
    {
        var abilityLevel = GameManager.Instance.Battle.GetAbilityLevel(beast.SelfData.BeastID, beast.SelfData.Abilitiy5);

        switch (style)
        {
            case 1:
            case 2:
            case 4:
                SkillAtk = beast.SelfData.Atk * (1 + ActiveSkillData.SpecValue * abilityLevel);
                break;
            case 3:
            case 5:
                SkillAtk = beast.SelfData.MaxHP * (ActiveSkillData.SpecValue + ActiveSkillData.SpecValue * abilityLevel) / 100;
                break;
        }
    }

    public float SetAtkToStyle(BeastData beast, int style)
    {
        var abilityLevel = GameManager.Instance.Battle.GetAbilityLevel(beast.BeastID, beast.Abilitiy5);

        var result = 0f;

        switch (style)
        {
            case 4:
                result = beast.Atk * (1 + ActiveSkillData.SpecValue * abilityLevel);
                break;
            case 5:
                result = beast.MaxHP * (ActiveSkillData.SpecValue + ActiveSkillData.SpecValue * abilityLevel) / 100;
                break;
        }

        return result;
    }

    //Skill Animation ��ų�� �� �� ȣ��
    public void OnSkillAniStart()
    {
        SkillAction?.Invoke();
    }

    //Skill Animation ���� �� ȣ��
    public void OnSkillAniEnd()
    {
        beast.SetCurrentStage(eBeastState.Battle_Idle);
    }

    public void Enter()
    {
        beast.animator.SetTrigger("Skill_A");
        beast.isDoing = true;
    }

    public void Doing()
    {
    }

    public void Exit()
    {
        beast.isDoing = false;
        beast.isSkill = false;
        StartCoolTime();
    }

    public void OnActive()
    {
        StartCoolTime();
        if (!beast.isSkill) return;

        beast.animator.ResetTrigger("Skill_A");
        SkillProjectile?.SetActive(false);
        beast.animator.Play("Beast_Idle", 0, 0f);
    }

    public void ResetDataToWave()
    {
        StartCoolTime();
    }

    public override GameObject MakeProjectile(int index, GameObject prefab = null, string prefabName = "")
    {
        if (SkillPoint == null) return null;

        var pre = base.MakeProjectile(index, null, prefabName);
        pre.transform.position = SkillPoint.transform.position;
        return pre;
    }

    private void StartCoolTime()
    {
        if (CO_CoolTime != null)
        {
            StopCoroutine(CO_CoolTime);
        }

        CO_CoolTime = StartCoroutine(CoolTimeCheck());
    }

    private IEnumerator CoolTimeCheck()
    {
        float time = 0;
        while (time < beast.SelfData.SkillCoolTime)
        {
            time += Time.deltaTime;
            yield return null;
        }

        beast.isSkill = true;
    }

    private IEnumerator DurationSkill(int duration, Action action)
    {
        float time = 0;
        while (time < duration)
        {
            time += Time.deltaTime;
            yield return null;
        }

        action?.Invoke();
    }

    public void SetTargetDistance()
    {
        beast.SkillRadius = beast.BasicRadius;
    }

    private void OnDisable()
    {
        StopAllCoroutines();
    }
}
