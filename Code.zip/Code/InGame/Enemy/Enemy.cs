using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    public eSpawnSection mySection { get; set; }
    public EnemyData SelfData { get; set; }
    public EnemyAttack Attack { get; set; }
    public Transform Parent { get; set; }

    private CameraFollow battleCamera;
    private float Radius = 7f;
    private bool isRadius = false;
    

    private void OnEnable()
    {
        isRadius = false;
    }

    public void Initialize(eSpawnSection section)
    {
        mySection = section;
        SelfData = GetComponent<EnemyData>();
        Attack = SelfData.animator.GetComponent<EnemyAttack>();
        battleCamera = GameManager.Instance.Battle.BattleCamera.GetComponent<CameraFollow>();
        Attack.Initialize(SelfData.FirePrefab, this);
        SelfData.FinalHP = SetEnemyHP();
    }

    public void SetChangeStageData()
    {
        SelfData.FinalHP = SetEnemyHP();
        Attack.OnActive();
        gameObject.SetActive(false);
    }

    private bool IsInRange(Vector2 selfPos, Vector2 targetPos, float radius)
    {
        var distance = Vector2.Distance(selfPos, targetPos);
        return distance <= radius;
    }

    public void PlayAttackAni()
    {
        //�ִϸ��̼� Attack���� Play
        SelfData.animator.SetTrigger("Attack");
    }

    public float SetEnemyHP()
    {
        var areaData = GameManager.Instance.Map.mapChanger.AreaData;
        var hp = Mathf.Pow(SelfData.HP, areaData.Order) * Mathf.Pow(areaData.PlayLv, 2) * InGameData.CurrentWave;
        return hp;
    }

    private void Update()
    {
        if (SelfData.EnemyType == eEnemySpawnType.Enemy_Barrier && !isRadius)
        {
            if (battleCamera.target == null) return;

            var rangeCheck = IsInRange(transform.position, battleCamera.target.position, Radius);
            if (rangeCheck)
            {
                isRadius = true;
                Debug.Log("�ݰ�ȿ� ���Գ�~");
                
                foreach (var enemy in GameManager.Instance.Battle.EnemyList)
                {
                    if (enemy.Value == true)
                    {
                        var script = enemy.Key.GetComponent<Enemy>();
                        if (mySection == script.mySection && script.SelfData.EnemyType != eEnemySpawnType.Enemy_Barrier)
                        {
                            script.PlayAttackAni();
                        }
                    }
                }
            }
        }
    }

}
