using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using Unity.VisualScripting;

public class UILobbyMeatSlot : LobbyMeatSlot
{
    public Button SlotButton;
    public Image Lockimg;
    public Image Iconimg;
    public Text MeatLvtxt;
    public GameObject MeatIcon;


    private List<RaycastResult> results;
    private float moveTime;
    private RectTransform rectTransform;

    //test
    [SerializeField]
    private int slotID;
    [SerializeField]
    private int Level;

    public override void Initialize(int slotID)
    {
        base.Initialize(slotID);

        rectTransform = GetComponent<RectTransform>();
        var iconIndex = SelfData.Level % 100 != 0 ? SelfData.Level % 100 : 100;
        Iconimg.sprite = SelfData.isMeat ? GameManager.Instance.Lobby.MeatSpriteDic[iconIndex] : null;
        MeatLvtxt.text = SelfData.Level.ToString();
        //Iconimg.gameObject.SetActive(SelfData.isMeat);
        Lockimg.gameObject.SetActive(SelfData.isLock);
        MeatIcon.gameObject.SetActive(SelfData.isMeat);
        SlotButton.enabled = !SelfData.isLock;
        //SetUnLockSlot(slotID);

        results = new List<RaycastResult>();
        if (SelfData.isMeat)
        {
            slotID = SelfData.SlotID;
            Level = MeatItemData.Level;
        }

        moveTime = 0.3f;
    }

    public void HideLockImage()
    {
        SelfData.isLock = false;
        Lockimg.gameObject.SetActive(false);
        SlotButton.enabled = true;
    }

    public void CreateIcon()
    {
        if (SelfData.Level < 1) return;

        var iconIndex = SelfData.Level % 100 != 0 ? SelfData.Level % 100 : 100;
        var meatIconSprite = GameManager.Instance.Lobby.MeatSpriteDic[iconIndex];

        Iconimg.sprite = meatIconSprite;
        MeatLvtxt.text = SelfData.Level.ToString();
        MeatIcon.gameObject.SetActive(true);
    }

    public void ChangeMeatData(MeatData data)
    {
        MeatLvtxt.text = data.Level.ToString();
    }

    public void ResetData()
    {
        SelfData.Level = 0;
        SelfData.isMeat = false;

        MeatIcon.gameObject.SetActive(false);
        slotID = SelfData.SlotID;
        Level = SelfData.Level;

        SetMeatData();
    }

    public void SaveItemData()
    {
        SetMeatData();

        if (InGameData.MeatInLobby[SelfData.SlotID] == null) return;

        InGameData.MeatInLobby[SelfData.SlotID].Level = MeatItemData.Level;
    }

    public void SetMeatData()
    {
        MeatItemData.Level = SelfData.Level;
    }

    public override void OnPointerUpDelegate(PointerEventData data)
    {
        if (!SelfData.isMeat) return;

        results.Clear();

        var uiCamera = GameManager.Instance.Lobby.LobbyCamera;
        var canvas = GameManager.Instance.Lobby.LobbyCanvas;
        var screenPoint = RectTransformUtility.WorldToScreenPoint(uiCamera, rectTransform.position);
        var pointData = new PointerEventData(EventSystem.current);
        pointData.position = screenPoint;
        EventSystem.current.RaycastAll(pointData, results);
        //EventSystem.current.RaycastAll(data, results);

        foreach (RaycastResult result in results)
        {
            if (result.gameObject.CompareTag("TeamSlot"))
            {
                if (GameManager.Instance.Lobby.Tutorial.isLockBattleSlot) break;

                var LaneSlot = result.gameObject.GetComponent<UIBattleSlotMeat>();
                if (LaneSlot.SelfData.isLock) break;

                lobbyMeat.MeatLaneSlots.Remove(SelfData.SlotID);
                InGameData.MeatInLobby.Remove(SelfData.SlotID);

                if (LaneSlot.SelfData.isMeat)
                {
                    var meatData = LaneSlot.MeatBattleData;
                    foreach (UILobbyMeatSlot slot in lobbyMeat.MeatSlots)
                    {
                        if (!slot.SelfData.isMeat)
                        {
                            slot.SelfData.isMeat = true;
                            slot.SelfData.Level = meatData.Level;
                            slot.CreateIcon();
                            if (slot.MeatItemData == null)
                            {
                                slot.MeatItemData = new MeatData(slot.SelfData.Level);
                            }
                            else slot.SetMeatData();

                            InGameData.MeatInBattle.Remove(LaneSlot.SelfData.SlotID);
                            lobbyMeat.MeatLaneSlots.Add(slot.SelfData.SlotID, slot);
                            InGameData.MeatInLobby.Add(slot.SelfData.SlotID, slot.MeatItemData);
                            break;
                        }
                    }
                }

                LaneSlot.SetSelfData(this);
                LaneSlot.MeatCreateIcon();
                LaneSlot.MeatBattleData = new MeatData(MeatItemData.Level);

                InGameData.MeatInBattle.Add(LaneSlot.SelfData.SlotID, LaneSlot.MeatBattleData);
                var beast = GameManager.Instance.Battle.BattleBeast[LaneSlot.SelfData.SlotID];
                beast.SelfData.Atk = GameManager.Instance.Battle.SetBattleBeastAtk(beast.SelfData, LaneSlot.SelfData.SlotID);
                beast.BeastAttack.SetAtkToBuffAtk();
                beast.BeastSkill.SetAtkToStyle(beast.BeastSkill.myStyle);
                ResetData();
                break;
            }

            if (result.gameObject.CompareTag("MeatSlot"))
            {
                var LaneSlot = result.gameObject.GetComponent<UILobbyMeatSlot>();

                if (LaneSlot.SelfData == null ||
                    LaneSlot.SelfData.Level != SelfData.Level ||
                    !LaneSlot.SelfData.isMeat) break;

                LaneSlot.SelfData.Level += 1;
                LaneSlot.CreateIcon();
                LaneSlot.SaveItemData();

                lobbyMeat.MeatLaneSlots.Remove(SelfData.SlotID);
                InGameData.MeatInLobby.Remove(SelfData.SlotID);

                ResetData();
                if (LaneSlot.SelfData.Level > InGameData.CurrentMeatHighLevel)
                {
                    InGameData.CurrentMeatHighLevel = LaneSlot.SelfData.Level;
                    lobbyMeat.NewMeatFind(LaneSlot.SelfData.Level);
                    GameManager.Instance.Lobby.PopupManager.NewMeatPopup.ShowPopup(LaneSlot.SelfData.Level);
                }

                break;
            }
        }

        ToOriginPosSlot();
        //StartCoroutine(ToOriginPos());

        tag = "MeatSlot";
        IsPressed = false;

        InGameData.SaveData();
    }

    private IEnumerator ToOriginPos()
    {
        Vector2 transformPos = new Vector2(transform.position.x, transform.position.y);

        var time = 0f;
        while (time < 1)
        {
            time += Time.deltaTime / moveTime;
            transform.position = Vector2.Lerp(transformPos, OriginPos, time);
            yield return null;
        }

        transform.SetSiblingIndex(originIndex);
        lobbyMeat.SpecialSlot.transform.SetAsLastSibling();
        lobbyMeat.SpecialSlot.SetActive(false);
        yield return null;
    }

    private void ToOriginPosSlot()
    {
        transform.position = OriginPos;
        transform.SetSiblingIndex(originIndex);
        lobbyMeat.SpecialSlot.transform.SetAsLastSibling();
        lobbyMeat.SpecialSlot.SetActive(false);
    }
}
