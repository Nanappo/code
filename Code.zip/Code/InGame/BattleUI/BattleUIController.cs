using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class BattleUIController : MonoBehaviour
{
    [Header("FadeInOut")]
    public FadeInOut FadeInOut;
    [Header("Coin")]
    public bool isPhysics;
    public RectTransform coinTarget;            //���� ���� ������
    [Header("GuageBar")]
    public GameObject HPGuageBarSample;

    public bool isFadeIn { get; set; }
    public bool isResurrection { get; set; }    //ȯ���� �ƴ��� üũ�ϴ� ����

    private float duration = 1.5f;              //���ư��� �ð�
    private float explosionDuration = 0.7f;     //������ �ð�
    private int thunderCount = 10;              //���ʿ� ������ų ������ ����
    private float thunderRange = 2.5f;          //�� �ݰ� üũ ( ���� )
    //private bool isThunder = false;
    private int thunderStudyID;
    private int thunderAutoStudyID;
    private float thunderSpec;
    private float thunderAutoSpec;
    private float thunderInterval;

    private Coroutine thunderCoroutine;

    private float spreadForce = 1.5f;             //������� ���ο� ���ϴ� ��
    private float jumpForce = 3f;               //������� ���ο� ���� ���ϴ� ��

    public void Initialize()
    {
        thunderCoroutine = null;
        thunderStudyID = (int)eStudyID.ThunderDamage;
        thunderAutoStudyID = (int)eStudyID.ThunderAuto;
        thunderSpec = TableManager.Instance.Beast2_DataTableTable.GetStudyAttribute(thunderStudyID).SpecValue;
        thunderAutoSpec = TableManager.Instance.Beast2_DataTableTable.GetStudyAttribute(thunderAutoStudyID).SpecValue;

        if (GameManager.Instance.InGameStudy[thunderAutoStudyID].Value > 0)
        {
            Invoke(nameof(AutoThunderAttack), 3f);
        }
    }

    #region Coin
    public void ShowCoinEffect(GameObject parent, int coinCount)
    {
        var coinPrefabName = GameManager.Instance.PrefabName[ePrefabName.Coin];
        var coinPath = string.Format("Prefabs/Prob/{0}", coinPrefabName);
        var coinList = ObjectPoolManager.Instance.GetPool(coinPrefabName, coinCount, coinPath);
        var posList = SpawnCoinPos(parent.transform, coinCount);
        var coin = coinList.PoolList;

        if (!isPhysics)
        {
            //���� LeanTween��� ����
            var originalTargetPos = LobbyToBattleCanvas();
            var initialBattleCamPos = GameManager.Instance.Battle.BattleCamera.transform.position;

            for (int i = 0; i < coinCount; i++)
            {
                var currentCoin = coinList.GetObject(coinPath);
                var ani = currentCoin.GetComponentInChildren<Animation>();
                ani.enabled = true;
                var currentPos = posList[i];

                currentCoin.transform.SetParent(parent.transform, false);
                currentCoin.transform.localPosition = Vector2.zero;
                currentCoin.transform.localRotation = Quaternion.identity;
                currentCoin.transform.localScale = Vector2.one * 0.25f;

                LeanTween.moveLocal(currentCoin, currentPos, explosionDuration).setEaseOutQuad()
                    .setDelay(0.1f).setOnComplete(() =>
                    {
                        Vector3 previousPos = currentCoin.transform.position;
                        Vector3 velocity = Vector3.zero;
                        LeanTween.value(currentCoin, 0f, 1f, duration).setEase(LeanTweenType.easeInOutCirc).setOnUpdate((float t) =>
                        {
                            Vector3 camOffset = GameManager.Instance.Battle.BattleCamera.transform.position - initialBattleCamPos;

                            Vector3 correctedTargetPos = originalTargetPos + new Vector3(camOffset.x, 0, 0);

                            float smoothTime = 0.3f; // 0.05~0.2 ������ ���� ����
                            previousPos = Vector3.SmoothDamp(previousPos, correctedTargetPos, ref velocity, smoothTime);
                            currentCoin.transform.position = previousPos;
                        }).setOnComplete(() =>
                        {
                            ani.enabled = false;
                            currentCoin.gameObject.SetActive(false);
                        });
                    });
            }
        }
        else
        {
            //�������� ����
            for (int i = 0; i < coinCount; i++)
            {
                var currentCoin = coinList.GetObject(coinPath);
                Vector2 spawnPos = parent.transform.position + new Vector3(Random.Range(-0.3f, 0.3f), Random.Range(0f, 0.3f), 0);
                Vector2 randDir = new Vector2(Random.Range(-1.5f, 1.5f), 0);
                Vector2 force = randDir * spreadForce + Vector2.up * jumpForce;
                float torque = Random.Range(-200f, 200f);

                StartCoroutine(SpawnAndLaunchCoin(currentCoin, parent.transform, spawnPos, force, torque));
            }
        }
    }

    private IEnumerator SpawnAndLaunchCoin(GameObject currentCoin, Transform parent, Vector2 spawnPos, Vector2 force, float torque)
    {
        currentCoin.transform.SetParent(parent, false);
        currentCoin.transform.localPosition = Vector2.zero;
        currentCoin.transform.localRotation = Quaternion.identity;
        currentCoin.transform.localScale = Vector3.one * 0.25f;

        var rb = currentCoin.GetComponent<Rigidbody2D>();

        rb.velocity = Vector2.zero;
        rb.angularVelocity = 0f;
        rb.simulated = false;

        rb.position = spawnPos;
        currentCoin.transform.position = spawnPos;

        yield return null;
        yield return new WaitForFixedUpdate();
        rb.simulated = true;
        rb.WakeUp();

        yield return new WaitForFixedUpdate();

        rb.AddForce(force, ForceMode2D.Impulse);
        rb.AddTorque(torque);

        var delayTime = Random.Range(1.5f, 2f);
        yield return new WaitForSeconds(delayTime);

        rb.velocity = Vector3.zero;
        rb.simulated = false;

        var originalTargetPos = LobbyToBattleCanvas();
        var initialBattleCamPos = GameManager.Instance.Battle.BattleCamera.transform.position;
        Vector3 previousPos = currentCoin.transform.position;
        Vector3 velocity = Vector3.zero;

        LeanTween.value(currentCoin, 0f, 1f, duration).setEase(LeanTweenType.easeInOutCirc).setOnUpdate((float t) =>
        {
            Vector3 camOffset = GameManager.Instance.Battle.BattleCamera.transform.position - initialBattleCamPos;

            Vector3 correctedTargetPos = originalTargetPos + new Vector3(camOffset.x, 0, 0);

            float smoothTime = 0.3f; // 0.05~0.2 ������ ���� ����
            previousPos = Vector3.SmoothDamp(previousPos, correctedTargetPos, ref velocity, smoothTime);
            currentCoin.transform.position = previousPos;
        }).setOnComplete(() =>
        {
            currentCoin.gameObject.SetActive(false);
        });
    }

    private List<Vector2> SpawnCoinPos(Transform trans, int coinCount)
    {
        List<Vector2> posList = new List<Vector2>();
        var radius = SetCoinRadius(trans.gameObject);
        var yScale = 0.6f;

        for (int i = 0; i < coinCount; i++)
        {
            Vector2 pos = Random.insideUnitCircle * radius;
            pos.y *= yScale;
            pos.y = Mathf.Clamp(pos.y, 0.1f, radius * yScale);

            if (trans.gameObject.GetComponent<Enemy>()?.SelfData.EnemyType == eEnemySpawnType.Enemy_Fly)
            {
                pos.y -= 1f;
            }

            posList.Add(pos);
        }

        return posList;
    }

    private Vector3 LobbyToBattleCanvas()
    {
        Vector2 screenPos = RectTransformUtility.WorldToScreenPoint(GameManager.Instance.Lobby.LobbyCamera, coinTarget.position);

        var imageRect = GameManager.Instance.Lobby.BattleImage;
        RectTransformUtility.ScreenPointToLocalPointInRectangle(imageRect, screenPos, GameManager.Instance.Lobby.LobbyCamera, out Vector2 localPoint);
        Rect rect = imageRect.rect;
        float px = imageRect.pivot.x * rect.width;
        float py = imageRect.pivot.y * rect.height;

        Vector2 uv;
        uv.x = (localPoint.x + px) / rect.width;
        uv.y = (localPoint.y + py) / rect.height;

        uv.x = Mathf.Clamp01(uv.x);
        uv.y = Mathf.Clamp01(uv.y);

        Vector3 viewportPos = new Vector3(uv.x, uv.y, 0f);
        Vector3 worldPos = GameManager.Instance.Battle.BattleCamera.ViewportToWorldPoint(viewportPos);

        return worldPos;
    }

    private float SetCoinRadius(GameObject enemy)
    {
        var sprite = enemy.GetComponent<Enemy>().SelfData.EnemySprite;
        if (sprite == null) return 0f;

        var size = sprite.bounds.size;
        var radius = Mathf.Max(size.x, size.y) * 0.5f;
        //Debug.Log("�ݰ�: " + radius);

        return radius;
    }
    #endregion
    #region Thunder
    public GameObject CreateThunder()
    {
        var ThunderPrefabName = GameManager.Instance.PrefabName[ePrefabName.Thunder];
        var thunderPath = string.Format("Prefabs/Projectile/{0}", ThunderPrefabName);
        var thunderList = ObjectPoolManager.Instance.GetPool(ThunderPrefabName, thunderCount, thunderPath);
        var thunder = thunderList.GetObject(thunderPath);
        return thunder;
    }

    public void OnThunder(Vector3 pos)
    {
        var thunder = CreateThunder();
        var particle = thunder.GetComponent<ParticleSystem>();
        var particleMain = particle.main;
        var thunderScript = thunder.GetComponent<BeastProjectile>();
        thunderScript.SetData(null, 1);
        var damage = SetThunderDamage();
        thunderScript.SetDamage(damage);

        thunder.transform.position = pos;
        StartCoroutine(WaitForParticle(particle));
        //particleMain.stopAction = ParticleSystemStopAction.Disable;
    }

    //public override void OnPointerDownDelegate(PointerEventData data)
    //{
    //    Debug.Log("PointDown");
    //    ThunderStart();
    //}

    public void ThunderStart()
    {
        var targetPos = SetThunderPos();
        if (targetPos == Vector3.zero) return;

        //isThunder = true;
        OnThunder(targetPos);
    }

    private Vector3 SetThunderPos()
    {
        var camera = GameManager.Instance.Battle.BattleCamera.GetComponent<CameraFollow>();
        if (camera.target == null) return Vector3.zero;

        var beast = camera.target.GetComponent<Beast>();
        var target = beast.Target;
        var ranPos = Random.Range(0.7f, 1.1f);

        if (target == null)
        {
            return beast.transform.position * ranPos;
        }
        else
        {
            if (!IsThunderRange(camera.target.transform.position, (Vector2)target.transform.position, thunderRange))
            {
                return beast.transform.position * ranPos;
            }

            return target.transform.position;
        }
    }
    private bool IsThunderRange(Vector2 beastPos, Vector2 targetPos, float xRange)
    {
        float xDiff = Mathf.Abs(beastPos.x - targetPos.x);

        return xDiff <= xRange;
    }

    private IEnumerator WaitForParticle(ParticleSystem ps)
    {
        yield return new WaitUntil(() => !ps.IsAlive(true));

        //isThunder = false;
        ps.gameObject.SetActive(false);
    }

    private float SetThunderDamage()
    {
        var damage = 10 * (1 + thunderSpec * GameManager.Instance.InGameStudy[thunderStudyID].Value / 100);
        return damage;
    }

    public void AutoThunderAttack()
    {
        if (thunderCoroutine != null) StopCoroutine(thunderCoroutine);

        thunderInterval = 10 / (thunderAutoSpec * GameManager.Instance.InGameStudy[thunderAutoStudyID].Value);
        thunderCoroutine = StartCoroutine(AutoThunder());
    }

    //�ڵ��������
    private IEnumerator AutoThunder()
    {
        float time = 0;
        while (true)
        {
            //if (isThunder) time = 0;

            time += Time.deltaTime;
            if (time > thunderInterval)
            {
                ThunderStart();
                time = 0;
            }

            yield return null;
        }
    }
    #endregion
}
