using DLL_Datatables;
using MessagePack;
using ServerCore;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.SceneManagement;
using System.Globalization;

public partial class GameManager : SingletonManager<GameManager>
{
    public readonly GameScreen GameScreen = new GameScreen();
    public readonly Notation PropertyNotation = new Notation();
    public readonly Dictionary<ePrefabName, string> PrefabName = new Dictionary<ePrefabName, string>
    {
        { ePrefabName.Coin, "Coin"},
        { ePrefabName.Thunder, "Projectile_Thunder"},
        { ePrefabName.EnemyDamage, "DamageText"},
        { ePrefabName.CreateSlot, "MeatSlot"}
    };

    public ObservableValue<double> InGameGold = new ObservableValue<double>(-1);
    public ObservableValue<double> InGameCoin = new ObservableValue<double>(-1);
    public ObservableValue<double> InGameDia = new ObservableValue<double>(-1); //�ӽ�(�������)
    public Dictionary<int, ObservableValue<int>> InGameStudy = new Dictionary<int, ObservableValue<int>>();
    public Dictionary<string, eLanguageType> LanguageType;

    public LobbyManager Lobby { get; set; }
    public BattleManager Battle { get; set; }
    public MapManager Map { get; set; }
    public bool isLoading { get; set; }
    public FirebaseControl Firebase { get; set; }

    private const float idleMaxMinutes = 60f * 24f;     //��ġ ���� �ִ� �ð�

    protected override void InitManager()
    {
        //ServerManager.Instance.ConnectSever();
        LanguageType = new Dictionary<string, eLanguageType>();
        InGameData.UserDataInitialize();
        StartCoroutine(GameSetting());
    }

    protected override void LateInitialize()
    {
        Firebase = GetComponent<FirebaseControl>();
        Firebase.Initialize();
    }

    private IEnumerator GameSetting()
    {
        yield return new WaitForSeconds(0.2f);

        SoundManager.Instance.SetBgmVolume(InGameData.bgmVolume);
        SoundManager.Instance.SetSfxVolume(InGameData.sfxVolume);

        yield return new WaitForSeconds(0.2f);

        string[] names = Enum.GetNames(typeof(eLanguageType));
        foreach (string name in names)
        {
            var key = name.Split('_').Last();
            var value = (eLanguageType)Enum.Parse(typeof(eLanguageType), name);
            LanguageType.Add(key, value);
        }

        if (InGameData.isNewPlayer)
        {
            SetLanguageCheck();
        }
        else CleLocalization.SetLanguage(InGameData.languageType);
    }

    public void StartGameScene()
    {
        SoundManager.Instance.PlayBGM(0);

        Lobby = GameObject.FindObjectOfType<LobbyManager>();
        Battle = GameObject.FindObjectOfType<BattleManager>();
        Map = GameObject.FindObjectOfType<MapManager>();

        GameScreen.Initialize();
        Map.Initialize();
        Lobby.Initialize();
        Battle.Initialize();

        Lobby.LobbyFade.gameObject.SetActive(true);
        Lobby.LobbyFade.FadeOut(1f, () =>
        {
            Lobby.LobbyFade.gameObject.SetActive(false);

            if (InGameData.tutorialScenario < (int)eTutorial.FirstEnd)
            {
                Lobby.Tutorial.Initialize();
            }
            else if (InGameData.tutorialScenario > (int)eTutorial.FirstEnd
            && InGameData.tutorialScenario < (int)eTutorial.End)
            {
                Lobby.Tutorial.AgainTutorial();
            }
            else if (InGameData.tutorialScenario == (int)eTutorial.FirstEnd
            && InGameData.BeastInGame.Keys.Max() == 1010060)
            {
                Lobby.LobbyUI.Guide.SetActive(true);
            }
            else if (GetIdleRewardTime() > 1
            && (InGameData.tutorialScenario == (int)eTutorial.FirstEnd || InGameData.tutorialScenario == (int)eTutorial.End))
            {
                Lobby.PopupManager.IdleRewardPopup.ShowPopup();
            }
        });

        isLoading = true;
    }

    public void ChangeScene()
    {
        SceneManager.LoadScene("Game");
        StartCoroutine(Co_WaitScene());
    }

    private IEnumerator Co_WaitScene()
    {
        yield return new WaitForSeconds(0.5f);
        StartGameScene();
    }

    public int GetIdleRewardTime()
    {
        if (!DateTime.TryParse(InGameData.RewardStartTime.ToString(), out DateTime lastTime))
        {
            Debug.Log("������ ���ӽð� �Ľ� ���ФФ�");
        }

        var nowTime = DateTime.UtcNow;
        var elapsedMinutes = (nowTime - lastTime).TotalMinutes;
        var validMinutes = Math.Min(elapsedMinutes, idleMaxMinutes);

        return (int)validMinutes;
    }

    public void SetLanguageCheck()
    {
        CultureInfo culture = CultureInfo.CurrentCulture;
        var type = culture.Name.Split('-').Last();

        if (LanguageType.ContainsKey(type))
        {
            var lang = LanguageType[type];
            CleLocalization.SetLanguage(lang);
            InGameData.languageType = lang;
        }
        else
        {
            var lang = eLanguageType.LT_US;
            CleLocalization.SetLanguage(lang);
            InGameData.languageType = lang;
        }
    }

    private void OnApplicationFocus(bool focus)
    {
        if (focus)
        {
            Screen.sleepTimeout = SleepTimeout.NeverSleep;
        }
    }

    private void OnApplicationPause(bool pause)
    {
        if (pause)
        {
#if UNITY_IOS
            InGameData.SaveData();
#endif
        }
    }

    private void OnApplicationQuit()
    {
        InGameData.SaveData();
    }
}
