using System;
using System.Collections;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using UnityEngine;
using UnityEngine.U2D;
using UnityEngine.UI;

public class ObservableValue<T>
{
    private T _value;
    public event Action<T> OnValueChanged;

    public T Value
    {
        get => _value;
        set
        {
            if (!Equals(_value, value))
            {
                _value = value;
                OnValueChanged?.Invoke(_value);
            }
        }
    }

    public ObservableValue(T value = default)
    {
        _value = value;
    }
}

public class LobbyUIController : MonoBehaviour
{
    [Header("Atlas")]
    public SpriteAtlas BattleslotBeastIcon;
    public SpriteAtlas BilinearIcon;
    public SpriteAtlas MeatIcon;
    public SpriteAtlas MapIcon;

    [Header("UI")]
    public Text TopCoinText;
    public Text TopGoldText;
    public Text TopDiaText;
    public Button RebirthButton;
    public Button ReviewButton;
    public Button RewardButton;
    public GameObject RewardAlarm;
    public UIWaveSystem UIWave;
    public BottomButtonControl BottomControl;
    public GameObject Guide;

    [Header("Menu")]
    public Button Menu;

    public delegate void LanguageChangedDelegate();
    public event LanguageChangedDelegate OnLanguageEvent;

    public bool isRebirth { get; set; }
    public bool isIdleReward { get; set; }
    public GameSleepMode sleepMode { get; set; }

    public void Initialize()
    {
        GameManager.Instance.InGameGold.OnValueChanged +=
            gold => TopGoldText.text = GameManager.Instance.PropertyNotation.FormatGameNumber(gold);
        GameManager.Instance.InGameCoin.OnValueChanged +=
            coin => TopCoinText.text = GameManager.Instance.PropertyNotation.FormatGameNumber(coin);
        GameManager.Instance.InGameDia.OnValueChanged +=
            dia => TopDiaText.text = ((int)dia).ToString();

        GameManager.Instance.InGameCoin.Value = InGameData.Coin;
        GameManager.Instance.InGameGold.Value = InGameData.Gold;
        GameManager.Instance.InGameDia.Value = InGameData.Dia;

        sleepMode = GetComponent<GameSleepMode>();

        RebirthButton.onClick.AddListener(() =>
        {
            isRebirth = true;
            GameManager.Instance.Lobby.PopupManager.RebirthPopup.ShowPopup();
        });

        ReviewButton.onClick.AddListener(() =>
        {
            GameManager.Instance.Lobby.PopupManager.ReviewPopup.ShowPopup();
        });

        RewardButton.onClick.AddListener(() =>
        {
            GameManager.Instance.Lobby.PopupManager.IdleRewardPopup.ShowPopup();
        });

        Menu.onClick.AddListener(() =>
        {
            GameManager.Instance.Lobby.PopupManager.OptionPopup.ShowPopup();
        });

        foreach (var study in InGameData.StudyData)
        {
            GameManager.Instance.InGameStudy.Add(study.Key, new ObservableValue<int>(study.Value));
        }

        BottomControl.Initialize();
        sleepMode.Initialize();
        SetReviewAlarm();
        isIdleReward = true;
    }

    public Sprite GetSprite(SpriteAtlas atlas, string name)
    {
        var sprite = atlas.GetSprite(name);
        return sprite;
    }

    public int GetSpriteNumber(string name)
    {
        Match match = Regex.Match(name, @"\d+");
        return match.Success ? int.Parse(match.Value) : 0;
    }

    public bool SetRewardAlarm()
    {
        var time = GameManager.Instance.GetIdleRewardTime();
        if (time >= 1)
        {
            RewardAlarm.SetActive(true);
            return true;
        }
        else
        {
            RewardAlarm.SetActive(false);
            return false;
        }
    }

    private void SetReviewAlarm()
    {
        if (InGameData.CurrentArea >= 2 || InGameData.IsPlayTimeReview)
        {
            if (InGameData.IsReview) return;
            ReviewButton.gameObject.SetActive(true);
        }
    }

    public void LanguageEventCallback()
    {
        OnLanguageEvent?.Invoke();
    }

    private void Update()
    {
        if (isIdleReward)
        {
            var isCheck = SetRewardAlarm();
            if (isCheck) isIdleReward = false;
        }

        if (!InGameData.IsPlayTimeReview)
        {
            InGameData.ReviewRewardTime += Time.deltaTime;

            if (InGameData.ReviewRewardTime >= 1800.0)
            {
                InGameData.IsPlayTimeReview = true;

                if (InGameData.IsReview) return;

                ReviewButton.gameObject.SetActive(true);
                GameManager.Instance.Lobby.PopupManager.ReviewPopup.ShowPopup();
            }
        }
    }
}
