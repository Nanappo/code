using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIPopupControl : MonoBehaviour
{
    public Text mainText;
    public Button checkButton;
    public event Action OnCheck;

    private bool Isinit = false;

    protected virtual void Initialize()
    {
        if (checkButton == null) return;

        checkButton.onClick.AddListener(() =>
        {
            OnCheck?.Invoke();
        });
    }

    public virtual void ShowPopup(int data = 0, bool isCheck = false)
    {
        if (!Isinit)
        {
            Isinit = true;
            Initialize();
        }

        gameObject.SetActive(true);
    }

    public virtual void ClosePopup()
    {
        OnCheck = null;
        gameObject.SetActive(false);
    }
}
