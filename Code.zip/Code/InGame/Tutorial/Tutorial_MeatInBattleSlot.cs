using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Tutorial_MeatInBattleSlot : UITutorial
{
    private LobbyMeat LobbyMeat;
    private Button CreateButton;
    private float speed = 0.7f;

    public override void Ready(Tutorial master)
    {
        base.Ready(master);

        LobbyMeat = GameManager.Instance.Lobby.LobbyMeat;

        foreach (var button in GameManager.Instance.Lobby.LobbyButton.groups)
        {
            if (button.Type == eMeatButtonType.Create)
            {
                CreateButton = button.Button;
            }
        }

        foreach (var target in LobbyMeat.MeatLaneSlots)
        {
            Master.Guide.transform.position = target.Value.transform.position;
        }

        Master.isLockBattleSlot = false;
        Target = LobbyMeat.BattleMeatLaneSlots[0].gameObject;
        Master.LockScreen[2].SetActive(true);
        NextScenario = eTutorial.ClickStudy;
    }

    public override IEnumerator Scenario()
    {
        Master.Guide.SetActive(true);
        Master.Guide.GetComponent<Animation>().Play("UI_Tuto_Drag");

        while (!isClear)
        {
            yield return null;
            yield return MoveToGuide();
        }

        End();
    }

    public override void End()
    {
        base.End();
        CreateButton.enabled = true;
        Master.LockScreen[2].SetActive(false);
        Master.LogEvent();
        Master.NextTutorial(NextScenario);
    }

    private IEnumerator MoveToGuide()
    {
        var originPos = Master.Guide.transform.position;
        while (Vector2.Distance(Master.Guide.transform.position, Target.transform.position) > 0.01f)
        {
            Master.Guide.transform.position = Vector2.MoveTowards(Master.Guide.transform.position, Target.transform.position, speed * Time.deltaTime);
            yield return null;

            if (LobbyMeat.BattleMeatLaneSlots[0].SelfData.Level == 2 || LobbyMeat.BattleMeatLaneSlots[1].SelfData.Level == 2)
            {
                isClear = true;
                yield break;
            }
        }

        Master.Guide.transform.position = originPos;
    }
}
