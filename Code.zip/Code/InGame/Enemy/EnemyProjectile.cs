using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyProjectile : Projectile
{
    public GameObject ProjectileParticle;
    public GameObject ExplosionParticle;
    public float LifeTime = 0;

    public override void SetDamage(float _damage, bool _isCritical = false)
    {
        base.SetDamage(_damage);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (!collision.gameObject.CompareTag("Beast")) return;

        var script = collision.GetComponent<Beast>();
        script.BeastAttack.AfterTakingDamage(damage);

        var rb = GetComponent<Rigidbody2D>();
        rb.velocity = Vector2.zero;
        rb.isKinematic = true;
        ProjectileParticle.SetActive(false);
        ExplosionParticle.SetActive(true);
        var explosionParticle = ExplosionParticle.GetComponent<ParticleSystem>();
        StartCoroutine(Co_ActiveOff(explosionParticle.main.duration));
        //Destroy(gameObject, explosionParticle.main.duration);
    }

    private IEnumerator Co_ActiveOff(float delay)
    {
        yield return new WaitForSeconds(delay);
        gameObject.SetActive(false);
    }

    public void ActiveOff()
    {
        StartCoroutine(Co_ActiveOff(LifeTime));
    }
}
