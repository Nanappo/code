using System;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class FadeInOut : MonoBehaviour
{
    public Image FadeImg;

    //��ο���
    public void FadeIn(float time, Action nextEvent = null)
    {
        StartCoroutine(FadeInCoroutine(time, nextEvent));
    }

    //����� 
    public void FadeOut(float time, Action nextEvent = null)
    {
        StartCoroutine(FadeOutCoroutine(time, nextEvent));
    }

    public void FadeInOutFunc(float inTime, float outTime)
    {
        StartCoroutine(FadeInOutCoroutine(inTime, outTime));
    }

    public IEnumerator FadeInOutCoroutine(float inTime, float outTime)
    {
        FadeIn(inTime, OnFadeIn);

        yield return new WaitUntil(() => GameManager.Instance.Battle.BattleUI.isFadeIn);

        yield return new WaitForSeconds(1f);
        FadeOut(outTime, OffFadeIn);
    }

    private IEnumerator FadeInCoroutine(float time, Action nextEvent)
    {
        var alpha = FadeImg.color;

        while (alpha.a < 1f)
        {
            alpha.a += Time.deltaTime / time;
            if (alpha.a >= 1) alpha.a = 1f;

            FadeImg.color = alpha;

            yield return null;
        }

        nextEvent?.Invoke();
    }

    private IEnumerator FadeOutCoroutine(float time, Action nextEvent)
    {
        var alpha = FadeImg.color;

        while (alpha.a > 0f)
        {
            alpha.a -= Time.deltaTime / time;
            if (alpha.a <= 0) alpha.a = 0f;

            FadeImg.color = alpha;

            yield return null;
        }

        nextEvent?.Invoke();
    }

    private void OnFadeIn()
    {
        GameManager.Instance.Battle.BattleUI.isFadeIn = true;
    }

    private void OffFadeIn()
    {
        GameManager.Instance.Battle.BattleUI.isFadeIn = false;
    }
}
