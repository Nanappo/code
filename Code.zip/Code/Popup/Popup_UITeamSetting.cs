using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Popup_UITeamSetting : MonoBehaviour
{
    public GameObject slotItem;
    public GameObject equipGuide;
    public Image beastIcon;
    public Image beastIconBackground;
    public List<GameObject> beastIconClass = new List<GameObject>();
    public Text beastIconLevel;
    public Text beastName;
    public GameObject beastSelect;
    public Button infoButton;
    public Button useButton;
    public GameObject warningImg;
    public eTeamPopupSlotType myType { get; private set; }
    public Button beastButton { get; set; }

    private Popup_TeamSetting Master;
    private int slotID = -1;


    public void Initialize(bool isLock, eTeamPopupSlotType type, Popup_TeamSetting master, BeastData beast = null, int slotid = -1)
    {
        Master = master;
        myType = type;
        beastButton = GetComponent<Button>();
        if (type == eTeamPopupSlotType.Team)
        {
            SetWarningIcon(false);
            slotID = slotid;
            if (beast != null && beast.HP <= 0)
            {
                SetWarningIcon(true);
            }
        }

        beastButton.onClick.AddListener(() =>
        {
            if (type == eTeamPopupSlotType.Inventory)
            {
                if (Master.selectBeast != null && Master.selectBeast.BeastID != beast.BeastID)
                {
                    Master.selectBeast = null;
                    Master.EquipProcess(false);
                }
            }

            if (equipGuide != null && equipGuide.activeSelf && type == eTeamPopupSlotType.Team)
            {
                ChangeBattleBeast(Master.selectBeast);
            }
            else SelectBeastButton(myType);
        });

        infoButton.onClick.AddListener(() =>
        {
            if (beast != null)
            {
                OnClickInfo(myType, beast, slotid);
            }
        });

        useButton?.onClick.AddListener(() =>
        {
            OnClickUse(beast);
        });

        if (isLock)
        {
            beastButton.enabled = false;
            slotItem.SetActive(false);
            equipGuide.SetActive(false);
        }
        else SetBeastIcon(beast);
    }

    private void SetBeastIcon(BeastData beast)
    {
        if (myType == eTeamPopupSlotType.Team) slotItem.SetActive(true);

        foreach (var beastclass in beastIconClass)
        {
            beastclass.SetActive(false);
        }

        beastIcon.sprite = GameManager.Instance.Lobby.LobbyUI.GetSprite(GameManager.Instance.Lobby.LobbyUI.BattleslotBeastIcon, beast.BeastID.ToString());
        beastIconBackground.color = GameManager.Instance.Battle.SetBeastIconBackgroundColor(beast.Class);
        for (int i = 0; i < beast.Class; i++)
        {
            beastIconClass[i].SetActive(true);
        }

        beastName.text = CleLocalization.Format("Localization", beast.BeastID.ToString(), null);
        //�������� �� �����ִµ� ���� ��ü ������ ����, �����ؼ� ���� ������. ���� �� �����ؾ���.
        //�ϴ� 1�θ� ������ ó��
        beastIconLevel.text = "1";
    }

    public void SetWarningIcon(bool isWarning)
    {
        warningImg.SetActive(isWarning);
    }

    private void SelectBeastButton(eTeamPopupSlotType type)
    {
        Master.OnlyOneBeastSelect();
        beastSelect.SetActive(true);

        if (type == eTeamPopupSlotType.Team)
        {
            transform.localScale = new Vector3(1.1f, 1.1f, 1.1f);
        }
        else
        {
            transform.localScale = new Vector3(1.15f, 1.15f, 1.15f);
        }
    }

    private void OnClickInfo(eTeamPopupSlotType type, BeastData beast, int slotID)
    {
        if (type == eTeamPopupSlotType.Team)
        {
            GameManager.Instance.Lobby.PopupManager.BeastInfoPopup.ShowPopup(slotID, true);
        }
        else
        {
            GameManager.Instance.Lobby.PopupManager.BeastInfoPopup.ShowPopup(beast.BeastID, false);
        }
    }

    private void OnClickUse(BeastData beast)
    {
        Master.EquipProcess(true);
        Master.selectBeast = beast;
        //Master.selectItem = gameObject;
    }

    private void ChangeBattleBeast(BeastData beast)
    {
        if (GameManager.Instance.Lobby.LobbyMeat.BattleMeatLaneSlots[slotID].WarningIcon.activeSelf)
        {
            GameManager.Instance.Lobby.LobbyMeat.BattleMeatLaneSlots[slotID].WarningIcon.SetActive(false);
        }

        InGameData.BeastInBattle.Remove(slotID);
        InGameData.BeastInBattle.Add(slotID, new BeastData().SetBeastData(beast.BeastID));
        GameManager.Instance.Lobby.LobbyMeat.BattleMeatLaneSlots[slotID].UpdateBattleBeastData(slotID);
        GameManager.Instance.Battle.BattleBeast.Remove(slotID);
        Destroy(GameManager.Instance.Battle.BattleBeastPrefabs[slotID]);
        GameManager.Instance.Battle.BattleBeastPrefabs.Remove(slotID);
        GameManager.Instance.Battle.EnterTheBattle(InGameData.BeastInBattle[slotID], slotID, true);
        Master.SetInventoryItem();
        SetBeastIcon(GameManager.Instance.Lobby.LobbyMeat.BattleMeatLaneSlots[slotID].BeastBattleData);
        SetWarningIcon(false);

        Master.EquipProcess(false);
        Master.OnlyOneBeastSelect();
        Master.selectBeast = null;
        ClosePopup();
    }

    public void ClosePopup()
    {
        beastSelect.SetActive(false);
        transform.localScale = Vector3.one;
    }
}
