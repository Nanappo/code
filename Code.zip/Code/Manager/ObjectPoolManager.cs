using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectPoolManager : SingletonManager<ObjectPoolManager>
{
    private Dictionary<string, ObjectPool> ObjectPoolDic;

    protected override void InitManager()
    {
        ObjectPoolDic = new Dictionary<string, ObjectPool>();
    }

    protected override void LateInitialize()
    {
    }

    public void AddObjectPool(string objName, int index, string objPath = "", GameObject parent = null, GameObject prefab = null)
    {
        if (objName == null)
        {
            Debug.LogError("No obj Name!!");
            return;
        }

        var objTransform = parent == null ? transform : parent.transform;
        var objString = objPath == "" ? objName : objPath;
        var pool = new GameObject(string.Format("{0}_PoolParent", objName)).AddComponent<ObjectPool>();
        pool.transform.SetParent(objTransform);
        pool.transform.localPosition = Vector3.zero;
        pool.transform.localRotation = Quaternion.identity;
        pool.transform.localScale = Vector3.one;

        ObjectPoolDic.Add(objName, pool);
        pool.AddObject(objString, index, prefab);
    }

    public ObjectPool GetPool(string objName, int index = 10, string objPath = "", GameObject parent = null, GameObject prefab = null)
    {
        if (!ObjectPoolDic.ContainsKey(objName))
        {
            AddObjectPool(objName, index, objPath, parent, prefab);
        }

        return ObjectPoolDic[objName];
    }

    public GameObject GetPoolObject(string objName)
    {
        if (!ObjectPoolDic.ContainsKey(objName)) return null;

        return ObjectPoolDic[objName].GetObject(objName);
    }
}
