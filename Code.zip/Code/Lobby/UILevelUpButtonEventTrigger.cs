using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class UILevelUpButtonEventTrigger : MonoBehaviour
{
    public Button LevelUPButton;

    public bool IsButtonHold { get; set; }
    private bool startHold = false;
    private const float holdCheckStartTime = 0.8f;

    void Start()
    {
        EventTrigger trigger = GetComponent<EventTrigger>();

        EventTrigger.Entry entry = new EventTrigger.Entry();
        entry.eventID = EventTriggerType.PointerDown;
        entry.callback.AddListener((data) => { OnPointerDownDelegate((PointerEventData)data); });
        trigger.triggers.Add(entry);

        EventTrigger.Entry entryExit = new EventTrigger.Entry();
        entryExit.eventID = EventTriggerType.PointerExit;
        entryExit.callback.AddListener((data) => { OnPointerExitDelegate((PointerEventData)data); });
        trigger.triggers.Add(entryExit);

        EventTrigger.Entry entryUp = new EventTrigger.Entry();
        entryUp.eventID = EventTriggerType.PointerUp;
        entryUp.callback.AddListener((data) => { OnPointerUpDelegate((PointerEventData)data); });
        trigger.triggers.Add(entryUp);

        EventTrigger.Entry entryFocusOut = new EventTrigger.Entry();
        entryFocusOut.eventID = EventTriggerType.Cancel;
        entryFocusOut.callback.AddListener((data) => { OnPointerCancelDelegate((BaseEventData)data); });
        trigger.triggers.Add(entryFocusOut);

        EventTrigger.Entry entryHold = new EventTrigger.Entry();
        entryHold.eventID = EventTriggerType.Drag;
        entryHold.callback.AddListener((data) => { OnPointerHoldDelegate((PointerEventData)data); });
        trigger.triggers.Add(entryHold);

        IsButtonHold = false;
    }

    public virtual void OnPointerDownDelegate(PointerEventData data)
    {
        if (!LevelUPButton.enabled)
        {
            return;
        }

        startHold = true;
        StartCoroutine(CheckHold());
    }

    private IEnumerator CheckHold()
    {
        float holdTimer = 0;
        while (startHold)
        {
            yield return null;

            holdTimer += Time.unscaledDeltaTime;
            if (holdTimer > holdCheckStartTime)
            {
                startHold = false;
                IsButtonHold = true;
                StartCoroutine(OnHoldButton());
            }
        }
    }

    public virtual IEnumerator OnHoldButton()
    {
        yield return null;
    }

    public virtual void OnPointerExitDelegate(PointerEventData data)
    {
        bool isExit = false;
        if (data.pointerEnter == null || data.pointerPress == null)
        {
            isExit = true;
        }
        else if (data.pointerEnter.transform != data.pointerPress.transform &&
            !data.pointerEnter.transform.IsChildOf(data.pointerPress.transform))
        {
            isExit = true;
        }

        if (!isExit)
        {
            return;
        }

        StopAllCoroutines();
        startHold = false;
        IsButtonHold = false;
    }

    public virtual void OnPointerUpDelegate(PointerEventData data)
    {
        StopAllCoroutines();
        startHold = false;
        IsButtonHold = false;
    }

    public virtual void OnPointerCancelDelegate(BaseEventData data)
    {
        StopAllCoroutines();
        startHold = false;
        IsButtonHold = false;
    }

    public virtual void OnPointerHoldDelegate(PointerEventData data)
    {
        bool isExit = data.pointerEnter.transform != data.pointerPress.transform &&
            !data.pointerEnter.transform.IsChildOf(data.pointerPress.transform);

        if (!isExit)
        {
            return;
        }

        StopAllCoroutines();
        startHold = false;
        IsButtonHold = false;
        // Debug.Log( "Hold �� Ÿ�� ���� ����" );
    }
}
