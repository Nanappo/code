using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UITutorial
{
    public GameObject Target;
    public eTutorial NextScenario;

    protected Tutorial Master;
    protected bool isClear = false;

    public virtual void Ready(Tutorial master)
    {
        Master = master;
    }

    public virtual IEnumerator Scenario()
    {
        yield return null;
    }

    public virtual void End()
    {
        Master.Guide.GetComponent<Animation>().Stop();
        Master.Guide.SetActive(false);
        isClear = false;
    }
}
