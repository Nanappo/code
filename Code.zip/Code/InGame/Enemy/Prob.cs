using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Prob : MonoBehaviour
{
    public Animator animator;
    public Transform Parent { get; set; }

    public void SetOriginParent()
    {
        Parent = transform.parent;
    }

    public void SetChangeStageData()
    {
        animator.SetBool("Death", false);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (!collision.CompareTag("Beast")) return;

        animator.SetBool("Death", true);
    }
}
