using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Popup_SplashMessage : UIPopupControl
{
    protected override void Initialize()
    {
    }

    public override void ShowPopup(int data = 0, bool isCheck = false)
    {
        var type = (eSplashMessageType)data;

        switch (type)
        {
            case eSplashMessageType.Proterty:
                mainText.text = CleLocalization.Format("Localization", "1000", null);
                break;
            case eSplashMessageType.Meat:
                mainText.text = CleLocalization.Format("Localization", "1001", null);
                break;
        }
        gameObject.SetActive(true);
    }

    public override void ClosePopup()
    {
        base.ClosePopup();
    }
}
