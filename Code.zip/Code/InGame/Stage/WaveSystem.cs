using Firebase.Analytics;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WaveSystem : AreaSystem
{
    public UIWaveSystem WaveSystemUI { get; set; }

    public void StartWave(float time)
    {
        GameManager.Instance.Battle.BattleUI.FadeInOut.FadeOut(time);

        WaveSystemUI = GameManager.Instance.Lobby.LobbyUI.UIWave;
        WaveSystemUI.Initialize();
    }

    public void ClearWave(float inTime, float outTime, Action action = null)
    {
        action?.Invoke();

        StartCoroutine(WaitCleatWave(inTime, outTime));
    }

    private IEnumerator WaitCleatWave(float inTime, float outTime)
    {
        yield return new WaitForSeconds(2.5f);

        if (GameManager.Instance.Map.mapChanger.AreaData.UnlockNextWave == InGameData.CurrentWave)
        {
            WaveSystemUI.OpenNextWaveUI();
        }

        InGameData.CurrentWave++;
        ChangeWave(inTime, outTime);
        WaveSystemUI.SetCurrentWaveString();
        InGameData.SaveData();
    }

    public void FailWave(float inTime, float outTime, Action action = null)
    {
        //���� ���� ���߰�.
        foreach (var enemy in GameManager.Instance.Battle.EnemyList)
        {
            if (enemy.Value == true)
            {
                enemy.Key.GetComponent<Enemy>().Attack.StopAttack();
            }
        }

        action?.Invoke();
        StartCoroutine(WaitFailWave(inTime, outTime));
        InGameData.CurrentWave = 1;
        GameManager.Instance.Battle.waveSystem.WaveSystemUI.SetWaveUI();
        InGameData.SaveData();
    }

    private IEnumerator WaitFailWave(float inTime, float outTime)
    {
        yield return new WaitUntil(() => GameManager.Instance.Battle.BattleUI.isResurrection);

        ChangeWave(inTime, outTime);
        GameManager.Instance.Battle.BattleUI.isResurrection = false;
    }

    public void ChangeWave(float inTime, float outTime)
    {
        GameManager.Instance.Battle.BattleUI.FadeInOut.FadeInOutFunc(inTime, outTime);
        if (InGameData.LastWave < InGameData.CurrentWave)
        {
            InGameData.LastWave = InGameData.CurrentWave;
            
            if (InGameData.LastWave % 10 == 0)
            {
                GameManager.Instance.Firebase.LogEvent("wave_clear", new Parameter("area", InGameData.CurrentArea), new Parameter("wave", InGameData.CurrentWave));
                Debug.Log($"Event Log : area {InGameData.CurrentArea},  wave {InGameData.CurrentWave}");
            }
        }

        StartCoroutine(ChangeWaveCoroutine());
    }

    private IEnumerator ChangeWaveCoroutine()
    {
        yield return new WaitUntil(() => GameManager.Instance.Battle.BattleUI.isFadeIn);

        //EnvironmentSetting
        GameManager.Instance.Map.mapChanger.SetChangeEnvironment();

        //EnemySetting
        SetEnemy();
        GameManager.Instance.Map.mapChanger.SetEnemySpawnPrefabs();
        GameManager.Instance.Map.mapChanger.SetProbSpawnPrefabs();

        //BeastSetting
        SetBeast();
        GameManager.Instance.Battle.CameraFollow.CameraMove(false);
    }

    private void SetEnemy()
    {
        var enemyList = GameManager.Instance.Battle.EnemyList;
        var probList = GameManager.Instance.Battle.ProbList;

        if (enemyList.Count < 1 || probList.Count < 1) return;

        foreach (var enemy in enemyList)
        {
            var script = enemy.Key.GetComponent<Enemy>();
            script.SetChangeStageData();
            script.transform.SetParent(script.Parent);
        }

        foreach (var prob in probList)
        {
            prob.SetChangeStageData();
            prob.transform.SetParent(prob.Parent);
            prob.gameObject.SetActive(false);
        }
    }

    private void SetBeast()
    {
        var beastDic = GameManager.Instance.Battle.BattleBeast;

        if (beastDic.Count < 1) return;

        foreach (var beast in beastDic)
        {
            if (!beast.Value.gameObject.activeSelf) continue;
            beast.Value.SetChangeStageData();
        }
    }
}
