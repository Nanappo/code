using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AbilitySpecUp : MonoBehaviour
{
    protected void BeastMaxHpUp(Beast beast)
    {
        beast.SelfData.MaxHP = GameManager.Instance.Battle.SetBattleBeastMaxHP(beast.SelfData);
        beast.BeastAttack.GuageBar.SetGuage(beast.SelfData, beast.SelfData.HP);

        GameManager.Instance.Lobby.PopupManager.BeastInfoPopup.beastHP.text =
            GameManager.Instance.PropertyNotation.FormatGameNumber(beast.SelfData.MaxHP);
    }

    protected void BeastAtkSpeedUp(int abilityID, Beast beast)
    {
        beast.SelfData.AtkSpeed = GameManager.Instance.Battle.SetBattleBeastAtkSpeed(beast.SelfData);
    }

    protected void BeastCriRateUp(Beast beast)
    {
        beast.SelfData.CriRate = GameManager.Instance.Battle.SetBattleBeastCriRate(beast.SelfData);
    }

    protected void BeastCriDamageUp(Beast beast)
    {
        beast.SelfData.CriDamage = GameManager.Instance.Battle.SetBattleBeastCriDamage(beast.SelfData);
    }

    protected void BeastSkillUp(Beast beast)
    {
        beast.BeastSkill.SetAtkToStyle(beast.BeastSkill.myStyle);
    }

    protected void BeastCoolTime(int abilityID, Beast beast)
    {
        beast.SelfData.SkillCoolTime = GameManager.Instance.Battle.SetBattleBeastSkillCoolTime(beast.SelfData);
    }
}