using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HPGuageBar : MonoBehaviour
{
    public Slider HPGuage;

    public void SetGuage(BeastData beast, float hp)
    {
        HPGuage.maxValue = beast.MaxHP;
        HPGuage.value = hp;
    }
}
