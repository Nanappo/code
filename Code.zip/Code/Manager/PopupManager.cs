using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PopupManager : MonoBehaviour
{
    public Popup_Rebirth RebirthPopup;
    public Popup_NewMeat NewMeatPopup;
    public Popup_NextArea NextAreaPopup;
    public Popup_SplashMessage SplashMessagePopup;
    public Popup_BeastInfo BeastInfoPopup;
    public Popup_Option OptionPopup;
    public Popup_TeamSetting TeamSettingPopup;
    public Popup_IdleReward IdleRewardPopup;
    public Popup_CommonReward CommonRewardPopup;
    public Popup_NewBeast NewBeastPopup;
    public Popup_Review ReviewPopup;

    public void Initialize()
    {
        OptionSetting();
    }

    private void OptionSetting()
    {
        OptionPopup.bgmSound.value = InGameData.bgmVolume;
        OptionPopup.sfxSound.value = InGameData.sfxVolume;
    }
}
