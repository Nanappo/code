using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectPool : MonoBehaviour
{
    public List<GameObject> PoolList = new List<GameObject>();
    private GameObject PoolObject;

    // ������Ʈ ���� �� �߰�
    public List<GameObject> AddObject(string objName, int index, GameObject prefab = null)
    {
        if (prefab != null) PoolObject = prefab;
        else PoolObject = GetPrefabResource(objName);

        if (PoolObject == null)
            Debug.LogError(objName + " null");

        for (int i = 0; i < index; i++)
        {
            GameObject obj = Instantiate(PoolObject);
            obj.name = obj.name.Replace("(Clone)", "");
            obj.transform.SetParent(transform);
            obj.SetActive(false);

            PoolList.Add(obj);
        }

        return PoolList;
    }

    // ������Ʈ�� ��������
    public GameObject GetObject(string objName, GameObject prefab = null)
    {
        GameObject obj = FindDeActiveObject();

        if (obj == null)
        {
            var list = AddObject(objName, 1, prefab);
            obj = list[0];
        }

        obj.SetActive(true);

        return obj;
    }

    public GameObject GetPrefabResource(string objName)
    {
        var preObj = Resources.Load(objName) as GameObject;

        if (preObj == null) return null;
        else return preObj;
    }

    // ����Ʈ�� ����� ���� ������Ʈ�� ã��
    private GameObject FindDeActiveObject()
    {
        for (int i = 0; i < PoolList.Count; ++i)
        {
            GameObject obj = PoolList[i].gameObject;
            if (obj == null)
                return null;
            if (obj.activeSelf == false)
                return obj;
        }
        return null;
    }
}
