using Firebase.Analytics;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Tutorial : MonoBehaviour
{
    public List<Button> LockButton;
    public List<GameObject> LockScreen;
    public GameObject Guide;
    public Dictionary<eTutorial, UITutorial> TutorialScenario;
    public bool isLockBattleSlot { get; set; }

    private UITutorial Scenario;

    public void Initialize()
    {
        foreach (var lockButton in LockButton)
        {
            lockButton.enabled = false;
        }

        SetTutorialScenario();

        gameObject.SetActive(true);

        var currentTutorial = (eTutorial)InGameData.tutorialScenario;
        if (currentTutorial < eTutorial.MeatInBattleSlot) isLockBattleSlot = true;

        StartTutorial(currentTutorial);
    }

    public void SetTutorialScenario()
    {
        TutorialScenario = new Dictionary<eTutorial, UITutorial>()
        {
            {eTutorial.MeatCreate, new Tutorial_MeatCreate() },
            {eTutorial.MeatMerge, new Tutorial_MeatMerge() },
            {eTutorial.MeatClosePopup, new Tutorial_ClosePopup() },
            {eTutorial.BeastClosePopup, new Tutorial_BeastClosePopup() },
            {eTutorial.MeatInBattleSlot, new Tutorial_MeatInBattleSlot() },
            {eTutorial.ClickStudy, new Tutorial_ClickStudy() },
            {eTutorial.AtkUpgrade, new Tutorial_AtkUpgrade() },
            {eTutorial.CloseStudy, new Tutorial_CloseStudy() },
            {eTutorial.Thunder, new Tutorial_Thunder() },
            {eTutorial.FirstTeamSlot, new Tutorial_FirstTeamSlot() },
            {eTutorial.AbilityHp, new Tutorial_AbilityHp() },
            {eTutorial.BeastInfoClosePopup, new Tutorial_BeastInfoClosePopup() },
            {eTutorial.TeamSettingPopup, new Tutorial_TeamSettingPopup() },
            {eTutorial.InventorySelect, new Tutorial_InventorySelect() },
            {eTutorial.TeamslotAdd, new Tutorial_TeamSlotAdd() },
        };
    }

    public void AgainTutorial()
    {
        SetTutorialScenario();
        gameObject.SetActive(true);
        var currentTutorial = eTutorial.InventorySelect;
        //InGameData.tutorialScenario = (int)currentTutorial;
        StartTutorial(currentTutorial);
    }

    public void StartTutorial(eTutorial step)
    {
        Scenario = TutorialScenario[step];

        Scenario.Ready(this);
        StartCoroutine(PlayTutorial());
    }

    private IEnumerator PlayTutorial()
    {
        yield return null;
        yield return Scenario.Scenario();

        if (Scenario.NextScenario == eTutorial.FirstEnd || Scenario.NextScenario == eTutorial.End)
        {
            foreach (var lockButton in LockButton)
            {
                lockButton.enabled = true;
            }

            gameObject.SetActive(false);
        }
    }

    public void NextTutorial(eTutorial step)
    {
        InGameData.tutorialScenario = (int)step;
        StartCoroutine(WaitNext(step));
    }

    private IEnumerator WaitNext(eTutorial step)
    {
        yield return new WaitForSeconds(0.5f);

        StartTutorial(step);
    }

    public void StopTutorial()
    {
        foreach (var lockButton in LockButton)
        {
            lockButton.enabled = true;
        }

        StopAllCoroutines();
        InGameData.tutorialScenario = (int)eTutorial.End;
        gameObject.SetActive(false);
    }

    public void LogEvent()
    {
        GameManager.Instance.Firebase.LogEvent("tutorial_step", new Parameter("step", InGameData.tutorialScenario));
        Debug.Log($"Event Log : tutorialStep {InGameData.tutorialScenario}");
    }
}
