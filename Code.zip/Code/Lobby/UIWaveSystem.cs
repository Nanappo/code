using DLL_Datatables;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIWaveSystem : MonoBehaviour
{
    public List<Text> waveSliderNumber = new List<Text>();
    public Text stringLevel;
    public Text waveLevel;
    public Slider waveSlider;
    public GameObject areaLock;
    public Image areaImage;
    public Animation areaAni;
    public Button areaNextButton;
    public GameObject Guide;

    private cArea areaData;
    private LobbyUIController LobbyUI;

    public void Initialize()
    {
        areaNextButton.enabled = false;
        LobbyUI = GameManager.Instance.Lobby.LobbyUI;
        SetWaveUI();
        areaNextButton.onClick.AddListener(() =>
        {
            GameManager.Instance.Lobby.PopupManager.NextAreaPopup.ShowPopup();
        });

        if (GameManager.Instance.Map.mapChanger.AreaData.UnlockNextWave <= InGameData.CurrentWave)
        {
            areaNextButton.enabled = true;
            OpenNextWaveUI();
        }

        GameManager.Instance.Lobby.LobbyUI.OnLanguageEvent += SetLanguageReload;
    }

    private void SetLanguageReload()
    {
        SetPlayLevelToString(areaData.PlayLv);
    }

    public void SetWaveUI()
    {
        areaData = GameManager.Instance.Map.mapChanger.AreaData;
        var spriteID = areaData.AreaID + 10;
        areaImage.sprite = LobbyUI.GetSprite(LobbyUI.BilinearIcon, spriteID.ToString());

        SetPlayLevelToString(areaData.PlayLv);
        SetCurrentWaveString();
        SetWaveSliderText();
    }

    private void SetPlayLevelToString(int playLv)
    {
        switch (playLv)
        {
            case 1:
                stringLevel.text = CleLocalization.Format("Localization", "10", null);
                break;
            case 2:
                stringLevel.text = CleLocalization.Format("Localization", "11", null);
                break;
        }
    }

    public void SetCurrentWaveString()
    {
        //if (GameManager.Instance.Battle.BattleUI.isResurrection)
        //{
        //    SetResetWaveString();
        //    return;
        //}

        waveLevel.text = InGameData.CurrentWave.ToString();
        waveSlider.value = InGameData.CurrentWave;
    }

    public void SetResetWaveString()
    {
        waveLevel.text = "1";
        waveSlider.value = 1;
    }

    private void SetWaveSliderText()
    {
        waveSlider.minValue = 0;
        waveSlider.maxValue = areaData.UnlockNextWave;

        var count = 0;
        var minValue = waveSlider.minValue;
        while (minValue <= waveSlider.maxValue)
        {
            waveSliderNumber[count++].text = minValue.ToString();
            minValue += waveSlider.maxValue / 5;
        }
    }

    public void OpenNextWaveUI()
    {
        areaLock.gameObject.SetActive(false);
        areaNextButton.enabled = true;
        areaAni.Play();
        Guide.SetActive(true);
    }

    public void CloseNextWaveUI()
    {
        areaLock.gameObject.SetActive(true);
        areaNextButton.enabled = false;
        areaAni.Stop();
        Guide.SetActive(false);
    }
}
