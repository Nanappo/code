using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BeastState_Die : BeastState
{
    private Beast beast;

    public BeastState_Die(Beast _beast)
    {
        beast = _beast;
    }

    private void ActiveOff()
    {
        beast.gameObject.SetActive(false);
    }

    public void Enter()
    {
        beast.isDoing = true;
        beast.isAni = true;
        beast.animator.SetBool("Death", true);
        Debug.Log("DieEnter");
    }

    public void Doing()
    {
        if (!beast.isAni)
        {
            beast.isDoing = false;
            beast.isAni = true;
            beast.animator.SetBool("Death", false);
            ActiveOff();

            //��Ʋ ������ �󸶳� ���Ҵ��� üũ �� �� �׾�����, ���̺� ���� ����.
            var dieBeast = GameManager.Instance.Battle.BattleBeastCheck();
            if (dieBeast == GameManager.Instance.Battle.BattleBeast.Count)
            {
                GameManager.Instance.Battle.waveSystem.FailWave(1f, 4f, () =>
                {
                    GameManager.Instance.Lobby.PopupManager.RebirthPopup.ShowPopup();
                });
            }
        }
    }

    public void Exit()
    {
        Debug.Log("DieExit");
    }
}
