using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyData : MonoBehaviour
{
    public Animator animator;
    public eEnemySpawnType EnemyType;
    public GameObject FirePoint;
    public ParticleSystem FireParticle;
    public GameObject FirePrefab;
    public SpriteRenderer EnemySprite;
    public float HP;
    public float AttackPower;
    public float AttackSpeed;
    public float MagazineCapacity;
    public float CoolTime;
    public float ShotSpeed;
    public float MissileSpeedForward;

    public float FinalHP { get; set; }
}
