using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tutorial_AbilityHp : UITutorial
{
    private Popup_BeastInfo Popup;
    private int beastID;
    private int hpIndex;

    public override void Ready(Tutorial master)
    {
        base.Ready(master);

        Popup = GameManager.Instance.Lobby.PopupManager.BeastInfoPopup;
        beastID = GameManager.Instance.Lobby.LobbyMeat.BattleMeatLaneSlots[0].BeastBattleData.BeastID;
        for (int i = 0; i < InGameData.BeastAbility[beastID].Count; i++)
        {
            if (InGameData.BeastAbility[beastID][i].abilityID == (int)eAbilityID.HP)
            {
                hpIndex = i;
                break;
            }
        }

        Target = Popup.beastAbilityItems[0].LevelUp.gameObject;
        if (Target != null)
        {
            Master.Guide.transform.position = Target.transform.position;
        }

        Master.LockScreen[7].SetActive(true);
        NextScenario = eTutorial.BeastInfoClosePopup;
    }

    public override IEnumerator Scenario()
    {
        Master.Guide.SetActive(true);
        Master.Guide.GetComponent<Animation>().Play("UI_Tuto_Idle");

        while (!isClear)
        {
            yield return null;
            if (InGameData.BeastAbility[beastID][hpIndex].abilityLevel == 1)
            {
                isClear = true;
            }
        }

        End();
    }

    public override void End()
    {
        base.End();
        Master.LockScreen[7].SetActive(false);
        Master.LogEvent();
        Master.NextTutorial(NextScenario);
        InGameData.tutorialScenario = (int)eTutorial.FirstTeamSlot;
    }
}
