using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tutorial_ClickStudy : UITutorial
{
    private BottomButtonControl Bottom;
    private UIBottomButton studyButton;

    public override void Ready(Tutorial master)
    {
        base.Ready(master);

        Bottom = GameManager.Instance.Lobby.LobbyUI.BottomControl;
        foreach(var button in Bottom.BottomButton)
        {
            if (button.mytype == eBottomButtonType.Study)
            {
                Target = button.gameObject;
                studyButton = button;
            }
        }

        if (Target != null)
        {
            var pos = Target.transform.position;
            pos.y += 0.3f;
            Master.Guide.transform.position = pos;
        }

        Master.LockScreen[3].SetActive(true);
        NextScenario = eTutorial.AtkUpgrade;
    }

    public override IEnumerator Scenario()
    {
        Master.Guide.SetActive(true);
        Master.Guide.GetComponent<Animation>().Play("UI_Tuto_Idle");

        while (!isClear)
        {
            yield return null;
            if (studyButton.selectObj.activeSelf==true)
            {
                isClear = true;
            }
        }

        End();
    }

    public override void End()
    {
        base.End();
        studyButton.Button.enabled = false;
        Master.LockScreen[3].SetActive(false);
        Master.LogEvent();
        Master.NextTutorial(NextScenario);
    }
}
