using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public Transform target;

    public bool isCameraZoom { get; set; }

    private Camera cam;
    private float offsetX;
    private float posY;
    private float smoothTime = 0.3f;
    private Vector3 velocity = Vector3.zero;
    private float zoomVelocity = 0f;
    private float zoomSize;
    private bool isEnemy;
    //private float time = 0f;

    public void Initialize()
    {
        //target = SetTargetTransform();
        cam = GetComponent<Camera>();
    }

    public Transform SetTargetTransform()
    {
        float beastspeed = 0;
        Beast beast = null;

        foreach (var speed in GameManager.Instance.Battle.BattleBeast)
        {
            if ((beastspeed < speed.Value.SelfData.MoveSpeed) && speed.Value.gameObject.activeSelf)
            {
                beastspeed = speed.Value.SelfData.MoveSpeed;
                beast = speed.Value;
            }
        }

        SetOffsetX(beast);
        return beast != null ? beast.transform : null;
    }

    public Transform ChangeTarget()
    {
        float posX = float.MinValue;
        Beast beast = null;

        foreach (var speed in GameManager.Instance.Battle.BattleBeast)
        {
            if (speed.Value.BeastAttack.isDied) continue;
            if (posX < speed.Value.transform.position.x)
            {
                posX = speed.Value.transform.position.x;
                beast = speed.Value;
            }
        }

        SetOffsetX(beast);
        return beast != null ? beast.transform : null;
    }

    private void SetOffsetX(Beast beast)
    {
        if (beast == null) return;

        int type = beast.SelfData.Type;
        switch (type)
        {
            case 1:
                //offsetX = isEnemy == true ? 0.8f : 0f;
                offsetX = 0.5f;
                posY = isEnemy == true ? 9.8f : 9f;
                zoomSize = isEnemy == true ? 4.8f : 4f;
                break;
            case 2:
            case 3:
                offsetX = 1.5f;
                posY = isEnemy == true ? 9.8f : 9f;
                zoomSize = isEnemy == true ? 4.8f : 4f;
                break;
        }
    }

    //�ٰŸ� ������ �����϶��� �ٲ��ְ� ����.
    public void CameraMove(bool enemy)
    {
        if (target == null) return;
        var beast = target.GetComponent<Beast>();
        //if (beast.SelfData.Type != 1) return;

        if (enemy) isEnemy = true;
        else isEnemy = false;
    }

    private void LateUpdate()
    {
        if (!GameManager.Instance.isLoading) return;

        target = ChangeTarget();
        if (target != null)
        {
            var targetPos = new Vector3(target.position.x + offsetX, posY, -10f);
            transform.position = Vector3.SmoothDamp(transform.position, targetPos, ref velocity, smoothTime);
            cam.orthographicSize = Mathf.SmoothDamp(cam.orthographicSize, zoomSize, ref zoomVelocity, smoothTime);
        }

        //if (!isCameraZoom)
        //{
        //    time += Time.deltaTime;
        //    if (time > 1f)
        //    {
        //        isCameraZoom = true;
        //        time = 0f;
        //        GameManager.Instance.Battle.CameraFollow.CameraMove(false);
        //    }
        //}
    }
}
