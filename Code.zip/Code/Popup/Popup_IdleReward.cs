using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Popup_IdleReward : UIPopupControl
{
    public Text timeText;
    public Text coinText;
    public Button rewardButton;
    public Button adsRewardButton;
    public GameObject noReward;
    public GameObject reward;

    private int diaReward = 0;
    private int coinReward = 0;

    protected override void Initialize()
    {
        base.Initialize();

        rewardButton.onClick.AddListener(() =>
        {
            GetReward();
        });
    }

    public override void ShowPopup(int slotID = 0, bool isBattle = false)
    {
        OnCheck += ClosePopup;
        base.ShowPopup();

        var rewardTime = GameManager.Instance.GetIdleRewardTime();
        diaReward = SetIdleDiaReward();
        coinReward = diaReward;

        if (rewardTime < 1)
        {
            reward.SetActive(false);
            noReward.SetActive(true);

            mainText.text = diaReward.ToString();
            coinText.text = coinReward.ToString();
            timeText.text = CleLocalization.Format("Localization", "115", 0, 0);
        }
        else
        {
            reward.SetActive(true);
            noReward.SetActive(false);

            int hour = rewardTime / 60;
            int min = rewardTime % 60;
            mainText.text = diaReward.ToString();
            coinText.text = coinReward.ToString();
            timeText.text = CleLocalization.Format("Localization", "115", hour, min);
        }
    }

    public override void ClosePopup()
    {
        base.ClosePopup();
    }

    private int SetIdleDiaReward()
    {
        var spec = TableManager.Instance.Beast2_DataTableTable.GetStudyAttribute((int)eStudyID.IdleRewardUp).SpecValue;
        var time = GameManager.Instance.GetIdleRewardTime();
        //var reward = (1 + 1 * (spec * GameManager.Instance.InGameStudy[(int)eStudyID.IdleRewardUp].Value) / 100) * time;
        //MVP��
        var reward = (100 + 100 * (spec * GameManager.Instance.InGameStudy[(int)eStudyID.IdleRewardUp].Value) / 100) * time;

        return (int)reward;
    }

    private void GetReward()
    {
        GameManager.Instance.InGameDia.Value += diaReward;
        GameManager.Instance.InGameCoin.Value += coinReward;
        GameManager.Instance.Lobby.LobbyUI.isIdleReward = true;
        InGameData.RewardStartTime = DateTime.UtcNow;

        GameManager.Instance.Lobby.PopupManager.CommonRewardPopup.ShowPopup(diaReward);
        ClosePopup();
    }
}
