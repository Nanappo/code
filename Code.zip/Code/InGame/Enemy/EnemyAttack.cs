using System;
using System.Collections;
using System.Linq;
using UnityEngine;

public class EnemyAttack : Attack
{
    public bool isDied { get; set; }
    public int coinCount { get; private set; }

    private GameObject MissilePrefab;
    private Enemy Enemy;
    private Action AttackAct;
    private Action CoolTimeAct;
    private Transform Target;

    public void Initialize(GameObject prefab, Enemy enemy)
    {
        MissilePrefab = prefab;
        Enemy = enemy;
        SetTypeData(Enemy.SelfData.EnemyType);
    }

    private void SetTypeData(eEnemySpawnType type)
    {
        switch (type)
        {
            case eEnemySpawnType.Enemy_Shot:
            case eEnemySpawnType.Enemy_Missile:
            case eEnemySpawnType.Enemy_Fly:
                coinCount = 10;
                break;
            case eEnemySpawnType.Enemy_Barrier:
                coinCount = 30;
                break;
        }
    }

    public override GameObject MakeProjectile(int index, GameObject prefab = null, string prefabName = "")
    {
        //if (prefab == null || Enemy.SelfData.FirePoint == null) return null;

        //var pre = base.MakeProjectile(parent, prefab);
        //pre.transform.position = Enemy.SelfData.FirePoint.transform.position;
        //return pre;

        var obj = base.MakeProjectile(index, prefab);
        obj.transform.position = Enemy.SelfData.FirePoint.transform.position;
        obj.transform.rotation = Quaternion.identity;
        return obj;
    }

    public Transform FindTarget()
    {
        float posX = float.MinValue;
        Transform beast = null;

        foreach (var target in GameManager.Instance.Battle.BattleBeast)
        {
            if (target.Value.transform.position.x > Enemy.transform.position.x) continue;

            if ((posX < target.Value.transform.position.x) && !target.Value.isDie)
            {
                posX = target.Value.transform.position.x;
                beast = target.Value.transform;
            }
        }

        return beast;
    }

    public void Fire(eFiretype type)
    {
        switch (type)
        {
            case eFiretype.Shot:
                AttackAct = ShotAttack;
                break;
            case eFiretype.Missile:
                AttackAct = MissileAttack;
                break;
        }

        CoolTimeAct = () => StartCoroutine(WaitAttack(Enemy.SelfData.AttackSpeed, Enemy.SelfData.MagazineCapacity, Enemy.SelfData.CoolTime, AttackAct));
        StartCoroutine(WaitAttack(Enemy.SelfData.AttackSpeed, Enemy.SelfData.MagazineCapacity, Enemy.SelfData.CoolTime, AttackAct));
    }

    private void ShotAttack()
    {
        Target = FindTarget();
        if (Target == null) return;

        var projectile = MakeProjectile(20, MissilePrefab);
        if (projectile == null) return;

        var script = projectile.GetComponent<EnemyProjectile>();
        var damage = SetEnemyDamage();
        script.SetDamage(damage);
        script.ProjectileParticle.SetActive(true);
        script.ExplosionParticle.SetActive(false);
        script.ActiveOff();
        Enemy.SelfData.FireParticle.Play();

        BeelineAttack(projectile, Vector2.left, Enemy.SelfData.ShotSpeed);
    }

    private void MissileAttack()
    {
        var projectile = MakeProjectile(20, MissilePrefab);
        if (projectile == null) return;

        var script = projectile.GetComponent<EnemyProjectile>();
        var damage = SetEnemyDamage();
        script.SetDamage(damage);
        script.ProjectileParticle.SetActive(true);
        script.ExplosionParticle.SetActive(false);
        script.ActiveOff();
        Enemy.SelfData.FireParticle.Play();

        CurveAttack(projectile, Vector2.left, Enemy.SelfData.MissileSpeedForward);
    }

    public override void BeelineAttack(GameObject prefab, Vector2 dir, float force)
    {
        var rb = prefab.GetComponent<Rigidbody2D>();
        rb.isKinematic = false;

        Vector2 direction = (Target.position - Enemy.transform.position);
        var target = Target.gameObject.GetComponent<Beast>();
        if (target.SelfData.Type == 3)
        {
            //Fly���� ������ ���� �������� �� �ȸ¾Ƽ� ������ �÷������.
            if (direction.y < 0.3f)
            {
                direction.y = 0.3f;
            }
        }
        direction.Normalize();

        rb.velocity = direction * force;
    }

    public override void CurveAttack(GameObject prefab, Vector2 dir, float forwardForce, float upForce = 0)
    {
        var rb = prefab.GetComponent<Rigidbody2D>();
        rb.isKinematic = false;

        var randomForce = UnityEngine.Random.Range(1f, 5f);
        Vector2 forceDir = dir * forwardForce + Vector2.up * randomForce;
        rb.AddForce(forceDir, ForceMode2D.Impulse);
    }

    public override void OnAttack(float coolTime, Action action)
    {
        base.OnAttack(coolTime, action);
    }

    public void AfterTakingDamage(float damage, bool isCritical)
    {
        if (isDied) return;

        Enemy.SelfData.animator.SetTrigger("Damaged");
        Enemy.SelfData.FinalHP = HitToDamage(Enemy.SelfData.FinalHP, damage);
        OnDamageText(isCritical, damage);

        if (Enemy.SelfData.FinalHP == 0)
        {
            if (Enemy.SelfData.EnemyType == eEnemySpawnType.Enemy_Barrier)
            {
                var owner = this.Enemy;
                foreach (var enemy in GameManager.Instance.Battle.EnemyList.ToList())
                {
                    var script = enemy.Key.GetComponent<Enemy>();
                    if (script.Attack.isDied)
                    {
                        continue;
                    }
                    if (script.mySection == owner.mySection)
                    {
                        script.Attack.isDied = true;
                        script.SelfData.animator.SetBool("Death", true);
                        GameManager.Instance.Battle.EnemyList[enemy.Key] = false;
                        script.Attack.StopAttack();
                        GameManager.Instance.Battle.BattleUI.ShowCoinEffect(script.gameObject, script.Attack.coinCount);
                    }
                }

                var sectionValue = Enum.GetValues(typeof(eSpawnSection)).Cast<eSpawnSection>().Last();
                if (Enemy.mySection == sectionValue)
                {
                    //�������̺�� �̵�.
                    GameManager.Instance.Battle.waveSystem.ClearWave(1f, 4f, () =>
                    {
                        foreach (var beast in GameManager.Instance.Battle.BattleBeast)
                        {
                            if (!beast.Value.isSkill) continue;

                            beast.Value.animator.ResetTrigger("Skill_A");
                            beast.Value.BeastSkill.SkillProjectile?.SetActive(false);
                            beast.Value.animator.Play("Beast_Idle", 0, 0f);
                            beast.Value.SetCurrentStage(eBeastState.Battle_Idle);
                        }
                    });
                }
                var gold = GetGoldToEnemyDied() * 10;
                var isUp = isGoldDoubleUpReward();
                gold = isUp == true ? gold * 2 : gold;
                GameManager.Instance.InGameGold.Value += gold;
            }
            else
            {
                isDied = true;
                Enemy.SelfData.animator.SetBool("Death", true);
                GameManager.Instance.Battle.EnemyList[Enemy.gameObject] = false;
                StopAttack();
                GameManager.Instance.Battle.BattleUI.ShowCoinEffect(Enemy.gameObject, coinCount);
                var gold = GetGoldToEnemyDied();
                var isUp = isGoldDoubleUpReward();
                gold = isUp == true ? gold * 2 : gold;
                GameManager.Instance.InGameGold.Value += gold;
            }

            GameManager.Instance.Battle.BeastFindToTarget();
        }
    }

    private IEnumerator WaitAttack(float attackSpeed, float magazineCapacity, float coolTime, Action action)
    {
        for (int i = 0; i < magazineCapacity; i++)
        {
            action?.Invoke();
            yield return new WaitForSeconds(attackSpeed);
        }

        OnAttack(coolTime, CoolTimeAct);
    }

    public override void StopAttack()
    {
        base.StopAttack();
    }

    public void OnActive()
    {
        isDied = false;
        Enemy.SelfData.animator.SetBool("Death", false);
    }

    private double GetGoldToEnemyDied()
    {
        var areaData = GameManager.Instance.Map.mapChanger.AreaData;
        var studyID = (int)eStudyID.AmountGold;
        var spec = TableManager.Instance.Beast2_DataTableTable.GetStudyAttribute(studyID).SpecValue;
        //var gold = Math.Pow(10, areaData.Order) * Mathf.Pow(areaData.PlayLv, 2) * InGameData.CurrentWave * (1 + GameManager.Instance.InGameStudy[studyID].Value * spec / 100);
        //MVP��
        var gold = Math.Pow(100, areaData.Order) * Mathf.Pow(areaData.PlayLv, 2) * InGameData.CurrentWave * (1 + GameManager.Instance.InGameStudy[studyID].Value * spec / 100);
        return gold;
    }

    private bool isGoldDoubleUpReward()
    {
        var studyID = (int)eStudyID.GoldDoubleUp;
        var spec = TableManager.Instance.Beast2_DataTableTable.GetStudyAttribute(studyID).SpecValue;
        var value = spec * GameManager.Instance.InGameStudy[studyID].Value;
        var result = UnityEngine.Random.Range(0, 100f) < value;
        return result;
    }

    private float SetEnemyDamage()
    {
        var areaData = GameManager.Instance.Map.mapChanger.AreaData;
        var damage = (Enemy.SelfData.AttackPower * areaData.Order) * Mathf.Pow(areaData.PlayLv, 2) * InGameData.CurrentWave;
        return damage;
    }

    private GameObject CreateDamageText()
    {
        var damagePrefabName = GameManager.Instance.PrefabName[ePrefabName.EnemyDamage];
        var damagePath = string.Format("Prefabs/UI/{0}", damagePrefabName);
        var damageList = ObjectPoolManager.Instance.GetPool(damagePrefabName, 1, damagePath);
        var damageText = damageList.GetObject(damagePath);
        return damageText;
    }

    private void OnDamageText(bool isCritical, float damage)
    {
        var pos = Enemy.SelfData.EnemyType == eEnemySpawnType.Enemy_Barrier ? new Vector3(0, 0.4f, 0) : Vector3.zero;
        var text = CreateDamageText();
        text.transform.SetParent(Enemy.transform);
        text.transform.localPosition = pos;
        text.transform.localRotation = Quaternion.identity;
        text.transform.localScale = Vector3.one;

        var script = text.GetComponent<UIEnemyDamage>();
        script.SetText(isCritical, damage);
    }
}
