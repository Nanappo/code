using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BeastState_Attack : Attack, BeastState
{
    public GameObject Projectile;
    public GameObject FirePoint;

    public int BuffAtk { get; set; }            //Skill������� ���ݷ� ������ ���� ���� ���ݷ°� ������ ó��.
    public float beelineAttackForce { get; private set; }
    public float curveAttackForce { get; private set; }
    public float curveAttackUpForce { get; private set; }
    public HPGuageBar GuageBar { get; set; }
    public bool isDied { get; set; }

    private Beast beast;
    private Action<GameObject> ProjectileType;
    private bool isAttack = false;
    private GameObject attackTarget;

    public void Init()
    {
        beast = GetComponent<Beast>();
        beast.Target = FindTarget();
        beelineAttackForce = 5f;
        curveAttackForce = 3f;
        curveAttackUpForce = 1f;
        SetAtkToBuffAtk();
        SetTypeData(beast.SelfData.Type);
        attackTarget = beast.Target;

        if (beast.SelfData.HP <= 0) isDied = true;
    }

    public void SetAtkToBuffAtk()
    {
        BuffAtk = beast.SelfData.Atk;
    }

    public void SetTypeData(int type)
    {
        switch (type)
        {
            case 1:
                beast.BasicRadius = 0.5f;
                ProjectileType = (obj) => BeelineAttack(obj, Vector2.right, beelineAttackForce);
                break;
            case 2:
                beast.BasicRadius = 2.5f;
                ProjectileType = (obj) => BeelineAttack(obj, Vector2.right, beelineAttackForce);
                break;
            case 3:
                beast.BasicRadius = 2.5f;
                beast.transform.position += new Vector3(0f, 1.3f, 0f);
                beast.Shadow.transform.localPosition -= new Vector3(0f, 0.7f, 0f);
                ProjectileType = (obj) => CurveAttack(obj, Vector2.right, curveAttackForce, curveAttackUpForce);
                break;
        }
    }

    public GameObject FindTarget()
    {
        float posX = float.MaxValue;
        GameObject enemy = null;

        foreach (var target in GameManager.Instance.Battle.EnemyList)
        {
            var enemyScript = target.Key.GetComponent<Enemy>();
            if (enemyScript == null || enemyScript.SelfData.EnemyType == eEnemySpawnType.Enemy_Fly) continue;

            if ((posX > target.Key.transform.position.x) && target.Value == true)
            {
                if (enemyScript.SelfData.EnemyType == eEnemySpawnType.Enemy_Barrier)
                {
                    posX = target.Key.transform.position.x;
                    enemy = target.Key;
                }
                else
                {
                    if (!CheckYPos(beast.transform.position, target.Key.transform.position)) continue;

                    posX = target.Key.transform.position.x;
                    enemy = target.Key;
                }
            }
        }

        return enemy;
    }

    private bool CheckYPos(Vector2 selfPos, Vector2 targetPos)
    {
        var yDiff = Mathf.Abs(selfPos.y - targetPos.y);
        return beast.SelfData.Type == 3 ? yDiff <= 1.7f : yDiff <= 0.4f;
    }

    public override GameObject MakeProjectile(int index, GameObject prefab = null, string prefabName = "")
    {
        if (prefab == null || FirePoint == null) return null;

        var pre = base.MakeProjectile(index, prefab);
        pre.transform.position = FirePoint.transform.position;
        return pre;
    }

    private bool IsCriticalHit()
    {
        var rate = beast.SelfData.CriRate;
        var randomValue = UnityEngine.Random.Range(0, 100);
        return randomValue < rate;
    }

    //Attack Animation�� ������ �Լ�
    public void OnBeastAttack()
    {
        var isCritical = IsCriticalHit();
        var damage = isCritical ? beast.SelfData.CriDamage : BuffAtk;
        var projectile = MakeProjectile(20, Projectile);
        var script = projectile.GetComponent<BeastProjectile>();
        script.SetData(beast);
        script.SetDamage(damage, isCritical);
        script.ActiveOff();

        ProjectileType(projectile);
    }

    //Attack Animation ���� ��
    public void AttackEnd()
    {
        if (isDied) return;

        isAttack = true;

        if (attackTarget != beast.Target)
        {
            attackTarget = beast.Target;
            OnTargetChange();
        }

        if (beast.isSkill)
        {
            if (beast.BeastSkill.myStyle == 1)
            {
                beast.SetCurrentStage(eBeastState.Battle_Idle);
            }
            else
            {
                beast.SetCurrentStage(eBeastState.Battle_Skill);
            }
        }
    }

    private void PlayAttackAnimatiion()
    {
        beast.animator.SetTrigger("Attack_1");
    }

    public override float HitToDamage(float hp, float damage)
    {
        return base.HitToDamage(hp, damage);
    }

    public void AfterTakingDamage(float damage)
    {
        if (isDied) return;

        beast.SelfData.HP = HitToDamage(beast.SelfData.HP, damage);
        GuageBar.SetGuage(beast.SelfData, beast.SelfData.HP);

        if (beast.SelfData.HP == 0)
        {
            isDied = true;
            StopAttack();
            beast.animator.SetBool("IsMove", false);
            if (beast.isSkill)
            {
                beast.SetCurrentStage(eBeastState.Battle_Idle);
            }
            else
            {
                beast.SetCurrentStage(eBeastState.Battle_Die);
            }
        }
    }

    public override void OnAttack(float atkSpeed, Action action)
    {
        StartCoroutine(OnAtkSpeed(atkSpeed, action));
    }

    private IEnumerator OnAtkSpeed(float atkSpeed, Action action)
    {
        float waitTime = atkSpeed;
        float time = 0f;

        while (time < waitTime)
        {
            time += Time.deltaTime;
            yield return null;
        }

        action?.Invoke();
    }

    public void OnTargetChange()
    {
        StopAttack();
        beast.SetCurrentStage(eBeastState.Battle_Idle);
    }

    public void OnActive()
    {
        isDied = false;
        beast.SelfData.HP = beast.SelfData.MaxHP;
        GuageBar.SetGuage(beast.SelfData, beast.SelfData.HP);
        beast.SetStartPos();
        beast.SetCurrentStage(eBeastState.Battle_Idle);
    }

    public void ResetDataToWave()
    {
        beast.Target = FindTarget();
    }

    //�״¾ִϳ����� �̺�Ʈ�� �ٿ������.
    public void AnimationEnd()
    {
        Debug.Log("DieAniEnd");
        beast.isAni = false;
    }

    public void Enter()
    {
        beast.isDoing = true;
        PlayAttackAnimatiion();
    }

    public void Doing()
    {
        if (isAttack)
        {
            isAttack = false;
            OnAttack(beast.SelfData.AtkSpeed, PlayAttackAnimatiion);
        }
    }

    public void Exit()
    {
        beast.isDoing = false;
        isAttack = false;
        StopAttack();
    }
}
