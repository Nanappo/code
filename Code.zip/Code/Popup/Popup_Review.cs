using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Popup_Review : UIPopupControl
{
    public Button reviewButton;

    private string androidURL;

    protected override void Initialize()
    {
        base.Initialize();

        reviewButton.onClick.AddListener(() =>
        {
            OnReviewButton();
        });
    }

    public override void ShowPopup(int level = 0, bool isCheck = false)
    {
        OnCheck += ClosePopup;
        base.ShowPopup();
    }

    public override void ClosePopup()
    {
        base.ClosePopup();
    }

    private void OnReviewButton()
    {
        InGameData.IsReview = true;
        InGameData.MeatCoin += 1000;

        foreach (var button in GameManager.Instance.Lobby.LobbyButton.groups)
        {
            if (button.Type == eMeatButtonType.Charge)
            {
                var script = button.Button.gameObject.GetComponent<UILobbySlotButtonText>();
                script.SetMainText(InGameData.MeatCoin.ToString());
            }
        }

        GameManager.Instance.Lobby.LobbyUI.ReviewButton.gameObject.SetActive(false);
        androidURL = "https://play.google.com/store/apps/details?id=com.cle.worldbeastwar2";
        Application.OpenURL(androidURL);
        ClosePopup();
    }
}
